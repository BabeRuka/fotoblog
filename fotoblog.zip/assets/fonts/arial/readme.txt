UFONTS.COM Readme file
GET MORE FONTS  AT http://www.ufonts.com 


Installing TrueType Fonts in Windows

   1. Extract the font to a folder or desktop on your computer.

   2. Choose Start > Settings > Control Panel

      Note: In Windows XP, choose Start > Control Panel
       
   3. Double-click the Fonts folder.
       
   4. Choose File > Install New Font.
       
   5. Locate the font you want to install.
             
   6. Select the fonts to install. To select more than one font, hold down the CTRL key and click each font.
       
   7. To copy the fonts to the Fonts folder, make sure the Copy fonts to the Fonts folder check box is selected.

      Note: If installing fonts from a floppy disk or a CD-ROM, you should make sure this check box is selected. Otherwise, to use the fonts in your applications, you must always keep the disk in the disk drive.
       
   8. Click OK to install the fonts.
