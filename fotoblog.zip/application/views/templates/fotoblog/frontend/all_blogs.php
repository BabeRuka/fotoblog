<?php
$url = $this->config->item('base_url');
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
  <?php if (count($blog_content) > 0) {  ?>
    <?php foreach ($blog_content as $k => $v) {  ?>
    <div class="col-md-12 well">
      <div><?php echo '<h2>'. $v['blog_pagetitle'].'</h2>'; ?></div>
      <div><img src="<?php echo $this->config->item('base_url').'/assets/images/articles/'. $v['blog_articles_image'].'.jpg'; ?>" align="left" border="2"  class="img-thumbnail my-pic" /></div>
      <div style="margin-bottom:2%; margin-left:2%"><?php echo  $v['blog_description']; ?></div>
      <div class="btn btn-default"><a href="<?php echo $this->config->item('base_url').'blog/index/'. $v['blog_id'].''; ?>"  class="readmore" >click here to visit <?php echo  $v['blog_fname'].' '. $v['blog_lname'].''; ?>'s Blog</a></strong></div>
    </div>
    <?php } }?>
  </div>
</div>
