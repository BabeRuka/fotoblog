<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<section class="front-div margin-bottom-1">
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
    <div class="col-md-12 well">
      <?php if (count($article) > 0) {  ?>
      <?php foreach ($article as $k=>$v) {; ?>
      <h3 class="text-center page-header"><?php echo $v['blog_articles_pagetitle'];  ?></h3>
      <h4><a href="<?php echo $this->config->item('base_url'); ?>blog/profile/<?php echo $v['blog_id']; ?>"><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></a></h4>
      <p class="text-primary">Posted on <strong  id="h3"><?php echo $v['blog_article_date']; ?></strong></p>
      <p><?php echo stripslashes(html_entity_decode($v['blog_articles_description'])); ?></p>
      <?php } ?>
      
      
        <div class="col-lg-12 col-md-12">
          <h4 class="page-header"><strong>Other Posts </strong></h4>
          <div class="fix-padding-two" >
              <div >
                <?php  if (count($some_articles) > 0) {  ?>
                <?php foreach ($some_articles as $k=>$v) { ?>
                <div class="row front-div page-header">
                  <div class="col-md-2" >
                    <?php if ($v['blog_articles_image']){ ?>
                    <img src="<?php echo $this->config->item('base_url').'assets/images/articles/'.$v['blog_articles_image'].''; ?>" align="left" border="2"  class="img-thumbnail footer-pic image-shadow"  />
                    <?php }else{ ?>
                    <img src="<?php echo $this->config->item('base_url').'assets/images/64X64.gif'; ?>" align="left" border="2"  class="img my-pic image-shadow"  />
                    <?php } ?>
                  </div>
                  <div class="col-md-10">
				  <?php echo '<h4><strong>'.$v['blog_articles_pagetitle'].'</strong></h4>'; ?> 
				  <?php echo strip_tags(substr(html_entity_decode($v['blog_articles_shortdesc']), 0,100)); ?>...
                  </div>
                  <small class="text-uppercase readmore-col"><a href="<?php echo $this->config->item('base_url').'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore <span class="glyphicon glyphicon-circle-arrow-right"></span></a></small>

                </div>
                <?php } ?>
                <?php }  ?>
                <div class="clear-fix" > </div>
              </div>
            </div>
        </div>
      
      
      <!-- start comments -->
      <div class="fix-padding-two">
      <?php if (count($my_blog_comments) > 0) {; ?>
      <div class="row">
        <div class="col-sm-12">
          <h4>Comments</h4>
        </div>
      </div>
      <div class="row">
        <?php foreach ($my_blog_comments as $k=>$v) {; ?>
        <div class="col-sm-1">
          <div class="thumbnail"> <img class="img-responsive user-photo" src="<?php echo $this->config->item('base_url').'assets/images/'; ?>avatar.png"> </div>
        </div>
        <div class="col-sm-5">
          <div class="panel panel-default">
            <div class="panel-heading"> <strong><?php echo $v['blog_comment_name']; ?></strong> <span class="text-muted">Comment on <?php echo $v['blog_comment_date']; ?></span> </div>
            <div class="panel-body"> <?php echo $v['blog_comment_comment']; ?> </div>
          </div>
        </div>
        <?php } ?>
      </div>
      <?php } ?>
      <div  class="row"><?php echo $message; ?></div>
      <div class="row">
        
        <form method="post" name="form1" action="">
        
          <p>Name:</p>
          <div>
            <input name="blog_comment_name" type="text" class="form-control" value="" size="32">
          </div>
          <p>Email:</p>
          <div>
            <input name="blog_comment_email" type="text" class="form-control" value="" size="32">
          </div>
          <p>Comment:</p>
          <div>
            <textarea name="blog_comment_comment" cols="50" rows="5" class="form-control"></textarea>
          </div>
          <p class="margin-top-2">
            <input type="submit" class="btn btn-info" value="Make Comment">
          </p>
          <input type="hidden" name="blog_comment_id" value="">
          <input type="hidden" name="blog_articles_id" value="<?php echo $article_id; ?>">
          <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>">
          <input type="hidden" name="blog_comment_date" value="">
          <input type="hidden" name="blog_comment_status" value="Pending">
          <input type="hidden" name="comment_insert" value="form1">
        </form>
      </div>
      </div>
      <!-- end comments -->
      <?php }  ?> 
      <!-- col-md-12 --></div>
    <!-- row --></div>
  <!-- col-md-8--></div>
