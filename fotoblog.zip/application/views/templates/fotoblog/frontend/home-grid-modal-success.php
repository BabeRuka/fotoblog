<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<section>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <?php foreach ($photos as $row){ ?>
        <!-- first row -->
        <div class="col-md-2 pull-left"> <a href="<?php echo $this->config->item('base_url'); ?>modal/browse/<?php echo $row['blog_gal_pagename']; ?>/<?php echo$row['blog_gal_id']; ?>/<?php echo $row['blog_tbn_id']; ?>" data-target="#galleryModal" data-toggle="modal"  title="<?php echo $row['blog_gal_name']; ?> "> <img src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_tbn_image_tbn']; ?>" data-toggle="tooltip" data-placement="bottom"  title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery"   alt="<?php echo $row['blog_gal_name']; ?>"/> </a> 
          <!--end col-lg-12--></div>
        <?php } ?>
        
        <!-- end first row -->
        <div class="clearfix"> </div>
        
        <!--end col-lg-12--></div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>

<!-- Large modal -->

<div class="modal" id="galleryModal" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="false">&times;</button>
      </div>
      <div class="modal-body">


<?php foreach ($gallery as $row){ ?>
<?php $blog_gal_pagename = $row['blog_gal_pagename']; ?>
<?php $blog_gal_id = $row['blog_gal_id']; ?>
<?php $blog_gal_name = ucwords($row['blog_gal_name']); ?>
<?php } ?>

<div class="container-full">
  <div class="row">
    <div class="col-md-12">
      <div class="row bkgrd-white">
        <div class="col-md-8 full-image"> 
          
          <!-- start carousel carousel-in-modal -->
          <div id="galleryModalCarousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#galleryModalCarousel" data-slide-to="0" class="active"></li>
              <?php 
				$start = 0;
				foreach ($other_photos as $row){ 
				$start ++;
				?>
              <li data-target="#galleryModalCarousel" data-slide-to="<?php echo $start; ?>"></li>
              <?php } ?>
            </ol>
            <!-- carousel-inner -->
            <div class="carousel-inner">
              <div class="item active"> <img id="<?php echo $photo_id; ?>" class="img-responsive center-block img-polaroid my-pic" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $photo; ?>"  /> </div>
              <?php foreach ($other_photos as $row){ ?>
              <div class="item"> <img id="<?php echo $row['blog_tbn_id']; ?>" class="img-responsive" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_tbn_image']; ?>" alt="..."> </div>
              <?php } ?>
            </div>
            <!-- end carousel-inner --> 
            
            <!-- Controls --> 
            <a class="left carousel-control" href="#galleryModalCarousel" role="button" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span> </a> <a class="right carousel-control" href="#galleryModalCarousel" role="button" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span> </a> <!-- end Controls --> 
            
          </div>
          <!-- end carousel carousel-in-modal --> 
          
        </div>
        <div class="col-md-4 fix-padding-two">
          <h5 class="text-primary text-uppercase"><strong><?php echo $blog_gal_name; ?> Gallery</strong></h5>
          <p><?php echo $photo_caption; ?></p>
          
          <div><strong><?php echo $success;?></strong></div>
          
          <div class="panel-group" id="accordion">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h5 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"><span class="glyphicon glyphicon-comment"></span> Comment</a> </h5>
              </div>
              <div id="collapseOne" class="panel-collapse collapse">
                <div class="panel-body"> 
                  
                  <!--make a comment-->
                  <div class="table-responsive">
                    <?php if ($success){ ?>
                    
                    <div id="success_span"> </div>
                    <?php } ?>
                    <form method="post" name="comment_form" data-async data-target="#galleryModal" onSubmit="return(ajax_send())" action="<?php echo $this->config->item('base_url')."modal/post_data/".$blog_gal_pagename."/".$blog_gal_id."/". $photo_id.""; ?>" >
                      <div>Name:</div>
                      <span id="name_span"></span>
                      <div>
                        <input name="blog_comment_name" type="text" required class="form-control" value="" size="32">
                      </div>
                      <div>Email:</div>
                      <span id="email_span"></span>
                      <div>
                        <input name="blog_comment_email" type="email" required class="form-control" value="" size="32">
                      </div>
                      <div valign="top">Comment:</div>
                      <span id="comment_span"></span>
                      <div>
                        <textarea name="blog_comment_comment" cols="50" rows="5" required class="form-control"></textarea>
                      </div>
                      <div>&nbsp;</div>
                      <div>
                        <input type="submit" class="btn btn-default" value="Make Comment">
                      </div>
                      <input type="hidden" name="blog_comment_id" value="">
                      <input type="hidden" name="blog_gal_pagename" value="<?php echo $blog_gal_pagename; ?>">
                      <input type="hidden" name="blog_gal_id" value="<?php echo $blog_gal_id; ?>">
                      <input type="hidden" name="photo_id" value="<?php echo $photo_id; ?>">
                      <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>">
                      <input type="hidden" name="blog_comment_date" value="">
                      <input type="hidden" name="blog_comment_status" value="Pending">
                      <input type="hidden" name="blog_comment_type" value="photo_gallery">
                      <input type="hidden" name="comment_insert" value="comment_form">
                    </form>
                  </div>
                  <!--make a comment--> 
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end first row -->
      <div class="clearfix"> </div>
      
      <!--end col-lg-12--></div>
    <!--end row--></div>
  <!--end row--></div>




      </div>
      <div class="modal-footer"> </div>
    </div>
  </div>
</div>
