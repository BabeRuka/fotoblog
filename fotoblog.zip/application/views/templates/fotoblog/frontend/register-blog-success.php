<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<section class="front-div margin-bottom-1">
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
    <div class="alert alert-success"> <strong>Success!</strong>Your Registeration Process was successfully Completed!</div>
    <div class="col-md-12 well"> </div>
  </div>
</div>
