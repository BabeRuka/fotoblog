<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="loader"></div>
<section id="myDiv">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <?php if ($photo){ ?>
        <div class="row my-pic">
          <div class="col-md-12"> <img class="img-responsive center-block img-polaroid" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $photo; ?>"  /></a>
            <p align="center" class="center-block"><?php echo $photo_caption; ?></p>
          </div>
        </div>
        <?php } ?>
       <?php if (count($photos) > 0){ ?>
      <?php foreach ($photos as $row){ ?>
        <!-- first row -->
        <!-- http://localhost/photoblog/modal/browse/kids/17/264 -->
        <div class="col-md-2 pull-left"> <a href="<?php echo $this->config->item('base_url'); ?>out/photo/<?php echo $row['blog_gal_pagename']; ?>/<?php echo$row['blog_gal_id']; ?>/<?php echo $row['blog_tbn_id']; ?>"  data-toggle="modal"  title="<?php echo $row['blog_gal_name']; ?> "> <img src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_tbn_image_tbn']; ?>" data-toggle="tooltip" data-placement="bottom"  title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery"   alt="<?php echo $row['blog_gal_name']; ?>"/> </a> 
          <!--end col-lg-12--></div>
        <?php } ?>
         <?php }else{ ?>
        	<div class="col-md-12"> 
            <h4><?php echo ucwords($this->uri->segment(3)); ?> Gallery Results</h4>
            <p>OPPS! The <?php echo strtoupper($this->uri->segment(3)); ?> gallery has no photos</p>
            </div>
        <?php } ?>
        <!-- end first row -->
        <div class="clearfix"> </div>
        
        <!--end col-lg-12--></div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>

<!-- Large modal -->

