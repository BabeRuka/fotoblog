<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php if ($this->show_footer_widgets =='Show Footer Widgets'){ ?>

<div class="section footer-black">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="col-lg-3  col-md-3  pull-left">
          <div >
            <h3 class="push-down-five">About</h3><hr style="margin-right: 90%;">
            <p><?php echo substr(html_entity_decode($this->about_data), 0, 500); ?></p>
          </div>
          <h3 class="">Search <?php echo site_name; ?> </h3>
          <div class="col-md-12 pull-left fix-left-hd ">
            <form action="<?php echo $this->config->item('base_url'); ?>search/index" method="post" class="navbar-form navbar-left" role="search">
              <div class="form-group">
                <input name="description" type="text"  class="form-control" id="description"  required="required"   />
              </div>
              <input type="submit" class="btn btn-info" value="Search">
            </form>
          </div>
        </div>
        <?php if ($this->show_blog_posts=='Show Blog Posts'){ ?>
        <div class="col-lg-2 col-lg-offset-1 col-md-3 col-md-offset-1 thumbnail-posts">
          <h3 class="push-down-five">latest posts </h3><hr style="margin-right: 90%;">
          <div class="container">
            <div class="row push-down-five">
              <div class="col-md-12">
                <?php  if (count($this->latest_blog_posts) > 0) {  ?>
                <?php foreach ($this->latest_blog_posts as $k=>$v) {; ?>
                <div class="row push-down-three"> <?php echo '<h4>'.$v['blog_articles_pagetitle'].'</h4>'; ?>
                  <div class="col-md-12" style="margin-right:2%;">
                    <?php if ($v['blog_articles_image']){ ?>
                    <img src="<?php echo $this->config->item('base_url').'assets/images/articles/'.$v['blog_articles_image'].''; ?>" class="img-thumbnail my-pic"  />
                    <?php }else{ ?>
                    <img src="<?php echo $this->config->item('base_url').'assets/images/64X64.gif'; ?>" class="img-thumbnail my-pic"  />
                    <?php } ?>
                  </div>
                  <div class="col-md-12" style="padding-top:10px;"> <a href="<?php echo $this->config->item('base_url').'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> "> <?php echo strip_tags(substr(html_entity_decode($v['blog_articles_description']), 0,50)); ?>...</a></div>
                </div>
                <?php } ?>
                <?php }  ?>
                <div class="clear-fix" > </div>
              </div>
            </div>
          </div>
        </div>
        <?php } ?>
        <div class="col-lg-2 col-lg-offset-1 col-md-2 col-md-offset-1">
          <h3 class="fix-left-hd push-down-five">Galleries </h3><hr style="margin-right: 90%;">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12 push-down-five">
                <div class="row">
                  <?php foreach ($this->latest_galleries as $row){ ?>
                  
                  <!-- first div -->
                  <div> 
                  <a href="<?php echo $this->config->item('base_url'); ?>out/gallery/<?php echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>" > 
                  <img class="img-responsive pull-left" style="height:33%; width:33%" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_gal_image_tbn']; ?>" alt="<?php echo $row['blog_gal_name']; ?>" title="View <?php echo ucwords($row['blog_gal_name']); ?> 
				  <?php echo site_name; ?> Gallery" data-toggle="tooltip" data-placement="bottom"/> </a> 
                   <!-- end first div --></div>
                  <?php } ?>
                  
                  
                  <div class="clearfix"> </div>
                  
                  <!--end col-lg-12--></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-2  col-lg-offset-1 col-md-2 col-md-offset-1">
          <h3 class="push-down-five">contacts</h3><hr style="margin-right: 90%;">
          <address class="">
          <?php 
                foreach($this->contacts_data as $key => $value) {
                    echo '<strong class="contacts">'.$value['setting_name'].'</strong>'; echo ' : '; echo $value['setting_value']; echo '<br />';
                }	  
              ?>
          </address>
        </div>
      </div>
    </div>
  </div>
</div>
<?php 
	$class='';
} else{
	$class='well footer-well';
}
?>
<footer class="text-center footer-info <?php echo $class; ?>">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <p>Copyright &copy; <?php echo site_name; ?>. All rights reserved.</p>
      </div>
    </div>
  </div>
</footer>
