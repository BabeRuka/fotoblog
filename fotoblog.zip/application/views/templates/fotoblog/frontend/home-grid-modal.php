<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<section >
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <?php if (count($photos) > 0){ ?>
        <?php foreach ($photos as $row){ ?>
        <!-- first row -->
        <div class="col-md-2 pull-left"> <a href="<?php echo $this->config->item('base_url'); ?>modal/browse/<?php echo $row['blog_gal_pagename']; ?>/<?php echo$row['blog_gal_id']; ?>/<?php echo $row['blog_tbn_id']; ?>"  data-toggle="modal"  title="<?php echo $row['blog_gal_name']; ?> "> <img src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_tbn_image_tbn']; ?>" data-toggle="tooltip" data-placement="bottom"  title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery"   alt="<?php echo $row['blog_gal_name']; ?>"/> </a> 
          <!--end col-lg-12--></div>
        <?php } ?>
        <?php }else{ ?>
        	<p>the gallery <?php echo strtoupper($this->uri->segment(3)); ?> has no photos. Please upload photos</p>
        <?php } ?>
        <!-- end first row -->
        <div class="clearfix"> </div>
        
        <!--end col-lg-12--></div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>

<!-- Large modal -->

<?php foreach ($gallery as $row){ ?>
<?php $blog_gal_pagename = $row['blog_gal_pagename']; ?>
<?php $blog_gal_id = $row['blog_gal_id']; ?>
<?php $blog_gal_name = ucwords($row['blog_gal_name']); ?>
<?php } ?>
<div class="modal fade" id="galleryModal" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="false">&times;</button>
      </div>
      <div class="modal-body">
        <div class="container-full">
          <div class="row">
            <div class="col-md-12">
              <div class="row bkgrd-white">
                <div class="col-md-8 full-image"> 
                  
                  <!-- start carousel carousel-in-modal -->
                  <div id="galleryModalCarousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                      <li data-target="#galleryModalCarousel" data-slide-to="0" class="active"></li>
                      <?php 
						$start = 0;
						foreach ($other_photos as $row){ 
						$start ++;
						?>
                      <li id="<?php echo $row['blog_tbn_id']; ?>" data-target="#galleryModalCarousel" data-slide-to="<?php echo $start; ?>"></li>
                      <?php } ?>
                    </ol>
                    <!-- carousel-inner -->
                    <div class="carousel-inner">
                      <div class="item active"> 
                      <?php
					  	$photo = explode('.',$photo);
					    $photo = $photo[0].'_cropped_700_600.'.$photo[1];
					  ?>
                      <img id="<?php echo $photo_id; ?>" class="img-responsive center-block img-polaroid my-pic" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $photo; ?>"  /> 
                      </div>
                      <?php foreach ($other_photos as $row){ ?>
                       <?php
					  	$photo = explode('.',$row['blog_tbn_image']);
					    $photo = $photo[0].'_cropped_700_600.'.$photo[1];
					  ?>
                     <div class="item"> 
                      <img id="<?php echo $row['blog_tbn_id']; ?>" class="img-responsive" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $photo; ?>" alt="..."> 
                      </div>
                      <?php /*?><div class="item"> <img id="<?php echo $row['blog_tbn_id']; ?>" class="img-responsive" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php $img = explode('.', $row['blog_tbn_image']); $img = $img[0].'_cropped_700_600.'.$img[1].'';  echo $img; ?>" alt="..."> </div><?php */?>

                      <?php } ?>
                    </div>
                    <!-- end carousel-inner --> 
                    
                    <!-- Controls --> 
                    <a class="left carousel-control" id="carouselControl" href="#galleryModalCarousel" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" id="carouselControl"></span>
                    </a> 
                    <a class="right carousel-control" id="carouselControl" href="#galleryModalCarousel" role="button" data-slide="next"> 
                        <span class="glyphicon glyphicon-chevron-right" id="carouselControl"></span> 
                    </a> <!-- end Controls --> 
                    
                  </div>
                  <!-- end carousel carousel-in-modal --> 
                  
                </div>
                <div class="col-md-4 fix-padding-two ">
                  <div class="scrol-div fix-left-two">
                    <h5 class="text-primary text-uppercase"><strong><?php echo $blog_gal_name; ?> Gallery</strong></h5>
                    <?php if ($success !== ''){ ?>
                    <div><strong><?php echo $success;?></strong></div>
                    <p><?php echo 'Your comment '.$this->input->post('blog_comment_comment').' was successfully posted. It will be made available once the admin approves it.';?></strong></p>
                    <?php } ?>
                    <div class="comment-well">
                    		<a href="#accordion"> <span class="glyphicon glyphicon-comment fix-left-five"></span>Make a Comment </a></div>
                    <!--comments-->
                    
                    <?php foreach ($my_blog_comments as $k=>$v) {; ?>
                    <div class="row fix-padding-five">
                      <div class="col-sm-12 fix-padding-five-left-right">
                        <div class="col-sm-2"> <img src="<?php echo $this->config->item('base_url').'assets/images/'; ?>avatar.png" width="32" height="32" class="img-responsive tbnail"> </div>
                        <!-- /thumbnail -->
                        
                        <div class="col-sm-10">
                          <p><small> <strong><?php echo $v['blog_comment_name']; ?></strong> <span class="text-muted"><?php echo $v['blog_comment_date']; ?></span> </small></p>
                          <div> <img src="<?php echo $v['blog_comment_data']; ?>" class="img-thumbnail" alt="<?php echo $v['blog_comment_comment']; ?>" data-toggle="tooltip" data-placement="bottom"  title="Comment by <?php echo ucwords($v['blog_comment_name']); ?>" /> </div> 
                        <small> <?php echo $v['blog_comment_comment']; ?> </small> </div>
                        <!-- col-sm-8 pull-right --> 
                      </div>
                      <!-- col-sm-12 --> 
                    </div>
                    <!-- /row -->
                    <?php } ?>
                    <!--comments-->
                    
                    <!--start panel-group accordion--><div class="panel-group" id="accordion">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                          <h5 class="panel-title"> 
                          <small>
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                              <span class="glyphicon glyphicon-comment fix-left-five"></span>Comment
                          </a>
                          </small> 
                          </h5>
                        </div>
                        <div id="collapseOne" class="panel-collapse collapse">
                          <div class="panel-body"> 
                            
                            <!--make a comment-->
                            <div class="table-responsive">
                              <div id="success_span"> </div>
                              <form method="post" name="comment_form"  action="<?php echo $this->config->item('base_url')."modal/browse/".$blog_gal_pagename."/".$blog_gal_id."/". $photo_id.""; ?>" >
                                <div><small>Name:</small></div>
                                <span id="name_span"></span>
                                <div>
                                  <input name="blog_comment_name" type="text" required class="form-control" value="" size="32">
                                </div>
                                <div><small>Email:</small></div>
                                <span id="email_span"></span>
                                <div>
                                  <input name="blog_comment_email" type="email" required class="form-control" value="" size="32">
                                </div>
                                <div valign="top"><small>Comment:</small></div>
                                <span id="comment_span"></span>
                                <div>
                                  <textarea name="blog_comment_comment" cols="50" rows="5" required class="form-control"></textarea>
                                </div>
                                <div>&nbsp;</div>
                                <div>
                                  <input type="submit" class="btn btn-default" value="Make Comment">
                                </div>
                                <input type="hidden" name="blog_comment_id" value="">
                                <input type="hidden" name="blog_gal_pagename" value="<?php echo $blog_gal_pagename; ?>">
                                <input type="hidden" name="blog_gal_id" value="<?php echo $blog_gal_id; ?>">
                                <input type="hidden" name="photo_id" value="<?php echo $photo_id; ?>">
                                <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>">
                                <input type="hidden" name="blog_comment_data" id="blog_comment_data" value="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $photo; ?>">
                                <input type="hidden" name="blog_comment_date" value="">
                                <input type="hidden" name="blog_comment_status" value="Pending">
                                <input type="hidden" name="blog_comment_type" value="photo_gallery">
                                <input type="hidden" name="comment_insert" value="comment_form">
                              </form>
                            </div>
                            <!--make a comment--> 
                            
                          </div>
                        </div>
                      </div>
                    <!--start panel-group accordion--></div>
                  </div>
                  <!--end --></div>
              </div>
              <!-- end first row -->
              <div class="clearfix"> </div>
              
              <!--end col-lg-12--></div>
            <!--end row--></div>
          <!--end row--></div>
      </div>
      <div class="modal-footer"> </div>
    </div>
  </div>
</div>
