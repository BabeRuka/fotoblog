<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (strlen(strstr($_SERVER['HTTP_USER_AGENT'], 'Firefox')) > 0) {
    $collumns = '7';
}else if (strlen(strstr($_SERVER['HTTP_USER_AGENT'], 'Edge')) > 0) {
    $collumns = '7';
}else{
    $collumns = '8';
}
?>
<section class="front-div margin-bottom-1">

<div class="container">
<div class="row">


<div class="col-md-8">
  <div class="row">
  <?php if (count($my_blog) > 0) {  ?>
    <?php foreach ($my_blog as $k => $v) {  ?>
    <div class="col-md-12">
      <?php if ($v['blog_articles_image']){ ?><img src="<?php echo $this->config->item('base_url').'assets/images/articles/'.$v['blog_articles_image'].''; ?>" align="left" border="2"  class="img-thumbnail my-pic"  /><?php } ?>
    </div>
    <div class="col-md-12 well image-shadow">
      <h4><strong><?php echo $v['blog_articles_pagetitle']; ?></strong></h4>
      <div><?php echo strip_tags(substr(html_entity_decode($v['blog_articles_shortdesc']), 0,600)); ?></div>
      <div class="front-div">
      <div class="btn btn-xs pull-right text-uppercase readmore-col">
      <a href="<?php echo $this->config->item('base_url').'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore <span class="glyphicon glyphicon-circle-arrow-right"></span></a>
      </div>
      </div>
    </div>
    <?php } }?>
  </div>
</div>

