<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<section class="front-div margin-bottom-1">
  <div class="container">
    <div class="row "> 
      <!--start left-->
      <div class="col-md-5 well">
        <div><strong><?php echo $message; ?></strong></div>
        <?php echo form_open(''.$url.'login/index'); ?>
        <div class="margin-down-two">
          <h5>Email Address</h5>
          <?php //echo $email_error; ?>
          <?php echo form_error('blog_email'); ?>
          <input type="text" name="blog_email" class="form-control" value="<?php echo set_value('blog_email'); ?>" size="50" />
        </div>
        <div class="margin-down-two">
          <h5>Password</h5>
          <?php echo form_error('blog_password'); ?>
          <input type="password" name="blog_password" class="form-control" value="<?php echo set_value('blog_password'); ?>" size="50" />
        </div>
        <div style="margin-top:2%; margin-bottom:2%;"> <a href="<?php echo $this->config->item('base_url'); ?>password/index">Click here to Reset your Password</a> </div>
        <div class="margin-down-two">
          <input type="submit" value="Submit"  class="btn btn-info"  />
        </div>
        </form>
      </div>
