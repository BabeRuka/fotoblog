<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (strlen(strstr($_SERVER['HTTP_USER_AGENT'], 'Firefox')) > 0) {
    $collumns = '6';
}else if (strlen(strstr($_SERVER['HTTP_USER_AGENT'], 'Edge')) > 0) {
    $collumns = '6';
}else{
    $collumns = '7';
}
?>
<section class="front-div">
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
  <?php if (count($blog_content) > 0) {  ?>
    <?php foreach ($blog_content as $k => $v) {  ?>
        <?php 
               $image = explode('.',$v['blog_profile_pic']);
               $image = $image[0].'_cropped_700_600.'.$image[1];
         ?>
    <div class="col-md-12">
      <div class="row well">
      <div class="col-md-4 pull-left fix-right-two">
      <img src="<?php echo $this->config->item('base_url'); ?>assets/images/<?php echo $image; ?>" title="<?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?>"   alt="<?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?>" class="img-thumbnail my-pic image-shadow"   />
</div>
      <div class="col-md-7 pull-left ">
	  <?php echo '<h4><strong>'. $v['blog_pagetitle'].'</h4></strong>'; ?>
	  <?php echo strip_tags(substr(html_entity_decode($v['blog_description']), 0,500));  ?>
      
      <div class="margin-down-five">
      <small class="pull-right text-uppercase readmore-col">
          <a href="<?php echo $this->config->item('base_url').'blog/profile/'. $v['blog_id'].''; ?>"  class="readmore"> Visit <?php echo  $v['blog_fname'].' '. $v['blog_lname'].''; ?>'s Profile <span class="glyphicon glyphicon-circle-arrow-right"></span></a>
      </small>
      </div>
      
      </div></div>
    </div>
    <?php } }?>
  </div>
</div>
