<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="loader" ></div>
<section id="myDiv">
  <div class="container" style="width:100%">
    <div class="row">
      <div  class="col-md-12" style="width:100%">
        <?php foreach ($galleries as $row){ ?>
        
        <?php 
             $image = explode('.',$row['blog_gal_image']);
             $image = $image[0].'_cropped_700_600.'.$image[1];
        ?>
        
        <!-- first row -->
        <div class="col-md-3"> 
        <a href="<?php echo $this->config->item('base_url'); ?>out/gallery/<?php echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>" > 
        <img class="img-responsive" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $image; ?>" data-toggle="tooltip" data-placement="bottom" title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery" alt="<?php echo $row['blog_gal_name']; ?>"/> </a> 
          <!--end col-lg-12--></div>
        <?php } ?>
        
        <!-- end first row -->
        <div class="clearfix"> </div>
        
        <!--end col-lg-12--></div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>
