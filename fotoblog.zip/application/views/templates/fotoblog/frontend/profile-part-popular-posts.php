<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php if ($this->agent->is_mobile()){ ?>



<div class="col-lg-12 col-md-12 well image-shadow thumbnail-posts">
  <?php  if (count($some_articles) > 0) {  ?>
  <h4><strong>Blog Posts by <?php echo $blog_fname; ?> <?php echo $blog_lname; ?></strong></h4>
  <div class="fix-padding-two" >
    <div >
      <?php foreach ($some_articles as $k=>$v) { ?>
      <div class="row front-div page-header">
        <div class="col-sm-12" >
          <?php if ($v['blog_articles_image']){ ?>
          <img src="<?php echo $this->config->item('base_url').'assets/images/articles/'.$v['blog_articles_image'].''; ?>" align="left" border="2"  class="img-thumbnail footer-pic image-shadow"  />
          <?php }else{ ?>
          <img src="<?php echo $this->config->item('base_url').'assets/images/64X64.gif'; ?>" align="left" border="2"  class="img my-pic image-shadow"  />
          <?php } ?>
        </div>
        <div class="col-sm-12 fix-padding-two"> <?php echo '<h4><strong>'.$v['blog_articles_pagetitle'].'</strong></h4>'; ?> <?php echo strip_tags(substr(html_entity_decode($v['blog_articles_shortdesc']), 0,100)); ?>... </div>
        <small class="text-uppercase readmore-col"><a href="<?php echo $this->config->item('base_url').'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore <span class="glyphicon glyphicon-circle-arrow-right"></span></a></small> </div>
      <?php } ?>
      <div class="clear-fix" > </div>
    </div>
  </div>
  <?php }  ?>
</div>


<?php }else{ ?>

<div class="col-lg-12 col-md-12 well image-shadow thumbnail-posts">
  <?php  if (count($some_articles) > 0) {  ?>
  <h4><strong>Blog Posts by <?php echo $blog_fname; ?> <?php echo $blog_lname; ?></strong></h4>
  <div class="fix-padding-two" >
    <div >
      <?php foreach ($some_articles as $k=>$v) { ?>
      <div class="row front-div page-header">
        <div class="col-md-2" >
          <?php if ($v['blog_articles_image']){ ?>
          <img src="<?php echo $this->config->item('base_url').'assets/images/articles/'.$v['blog_articles_image'].''; ?>" align="left" border="2"  class="img-thumbnail footer-pic image-shadow"  />
          <?php }else{ ?>
          <img src="<?php echo $this->config->item('base_url').'assets/images/64X64.gif'; ?>" align="left" border="2"  class="img my-pic image-shadow"  />
          <?php } ?>
        </div>
        <div class="col-md-10"> <?php echo '<h4><strong>'.$v['blog_articles_pagetitle'].'</strong></h4>'; ?> <?php echo strip_tags(substr(html_entity_decode($v['blog_articles_shortdesc']), 0,100)); ?>... </div>
        <small class="text-uppercase readmore-col"><a href="<?php echo $this->config->item('base_url').'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore <span class="glyphicon glyphicon-circle-arrow-right"></span></a></small> </div>
      <?php } ?>
      </
      <div class="clear-fix" > </div>
    </div>
  </div>
  <?php }  ?>
</div>

<?php } ?>
