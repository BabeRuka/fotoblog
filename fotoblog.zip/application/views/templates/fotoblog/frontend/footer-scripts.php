<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php $this->load->view(default_frontend_dir.'footer-data.php'); ?>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="<?php echo $this->config->item('base_url'); ?>assets/js/jquery-1.11.3.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo $this->config->item('base_url'); ?>assets/js/bootstrap.js"></script> 
<script type="text/javascript">
	$(window).load(function() {
		$(".loader").fadeOut("slow");
	})
	$(document).ready(function(){
		 var url = window.location.href;
        $('.nav a[href="'+url+'"]').parent().addClass('active');

		$('#galleryModal').modal('show');
		$('#galleryModal').on('hidden.bs.modal', function () {
			  $(this).removeData('bs.modal');
		});
		jQuery('[data-dismiss="modal"]').on('click', function(){
			 jQuery('.modal').hide();
			 jQuery('.modal-backdrop').hide();
		});
		$(this).find('.modal-body').css({
              width:'auto', //probably not needed
              height:'auto', //probably not needed 
              'max-height':'90%'
       });
		 $("#galleryModalCarousel").carousel({
			 interval : false
		 });
	});
	//find the active carousal
	$("#galleryModal").on('slide.bs.carousel', function(evt) {
	  var activeIndex =  $(this).find('.active').index();
	  var activeImage = $('.active');
	  var currentImage;
	  //get the current image
	  currentImage = activeImage.next().find('img').attr('src');
	  //pass the current image into the blog_comment_data field in the form 
	  $("#blog_comment_data").val(currentImage);
	  console.log(activeIndex);
	  console.log(currentImage);
	});
	
	var myVar;
	function pageLoader() {
    	myVar = setTimeout(showPage, 1000);
	}
	function showPage() {
		if (document.getElementById("loader")){
		  document.getElementById("loader").style.display = "none";
		  document.getElementById("myDiv").style.display = "block";
		}
	}
</script>
</body></html>