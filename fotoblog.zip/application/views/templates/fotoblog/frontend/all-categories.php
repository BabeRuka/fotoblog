<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
$blog=$this->uri->segment(3);
?>

<section class="front-div margin-bottom-1">
<div class="container">
  <div class="row">
    <div class="col-md-8">
      <div class="row">
        <div class="col-md-12">
          <?php if ($this->uri->segment(2) == 'category') { ?>
          <div class="col-md-12 well">
            <?php if ( !is_int($this->uri->segment(3)) ) {  
		echo '<h4>Category Results for '.str_replace('-', ' ', $this->uri->segment(4)).'</h4>'; 
	}else{
		if( $this->uri->segment(3) == '0'  ){
			echo '<h4>Category Results for '.str_replace('-', ' ', $this->uri->segment(4)).'</h4>'; 
		}else{
			echo '<h4>Category Results for '.str_replace('-', ' ', $this->uri->segment(3)).'</h4>'; 
		}
	}
	?>
          </div>
          <?php if (count($category_articles) > 0) {  ?>
          <?php foreach ($category_articles as $k => $v) {  ?>
          <?php 
               $image = explode('.',$v['blog_articles_image']);
               $image = $image[0].'_cropped_700_600.'.$image[1];
         ?>
          <div class="col-md-12 well image-shadow thumbnail-posts">
            <div class="col-md-4 pull-left fix-right-two image-shadow">
              <div> <img src="<?php echo $url.'assets/images/articles/'.$v['blog_articles_image'].''; ?>"  align="left" border="2"  class="img-thumbnail my-pic" /> </div>
            </div>
            <div class="col-md-7 pull-left "> <?php echo '<h4><strong>'. $v['blog_articles_pagetitle'].'</h4></strong>'; ?> <?php echo strip_tags(substr(html_entity_decode($v['blog_articles_description']), 0,500));  ?>
              <div class="margin-down-five"> <small class="pull-right text-uppercase readmore-col"> <a href="<?php echo ''.$url.'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore</a> </small> </div>
            </div>
          </div>
          <?php } }?>
          <?php  } ?>
        </div>
      </div>
    </div>
  </div>
</div>
