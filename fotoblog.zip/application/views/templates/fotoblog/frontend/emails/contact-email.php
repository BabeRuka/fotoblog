<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php
	foreach ($contact_details as $row){
		if ($row['setting_name']=='Address'){
			$address = $row['setting_value'];
		}
		if ($row['setting_name']=='Surburb'){
			$surburb = $row['setting_value'];
		}
		if ($row['setting_name']=='City'){
			$city = $row['setting_value'];
		}
		if ($row['setting_name']=='State (Pronvince)'){
			$state = $row['setting_value'];
		}
		if ($row['setting_name']=='Cellphone'){
			$cellphone = $row['setting_value'];
		}
		if ($row['setting_name']=='Telephone'){
			$telephone = $row['setting_value'];
		}
		if ($row['setting_name']=='Google Maps'){
			$map = $row['setting_value'];
		}
		if ($row['setting_name']=='Email'){
			$email = $row['setting_value'];
		}
	}	
		$map = explode("&quot;",$map);
			foreach ($map as $key => $value){
				if ($key == 1){
					$map_src = $value;
				}
		}

?>
<html>
<head>
<title><?php echo $this->config->item('base_url'); ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div align="left"></div>
<table width="615" border="0" cellpadding="0" cellspacing="0" bgcolor="#191919" align="center">
  <tr bgcolor="#576168">
    <td width="30" height="30"></td>
    <td width="551"></td>
    <td width="34"></td>
  </tr>
  <tr bgcolor="#576168">
    <td height="428"></td>
    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="27" height="25"></td>
          <td width="495"></td>
          <td width="29"></td>
        </tr>
        <tr>
          <td height="375"></td>
          <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="495" height="375" valign="top" bgcolor="#FFFFFF"><h1 class="text-center"><?php echo site_name; ?></h1>
                  <div class="well">
                    <div class="col-sm-12 col-lg-12 col-md-12 pull-left">
                      <p>Dear <?php echo $name; ?></p>
                      <p>Thank you for your email</p>
                      <p>This is an automated email that confirms we have received your email and one of our consultants will get back to you as soon as possible.</p>
                      <p><a href="#"> <span class="glyphicon glyphicon-user"></span> </a> <strong>Name:</strong> <?php echo $name; ?></p>
                      <p><a href="#"> <span class="glyphicon glyphicon-inbox"></span> </a> <strong>Email:</strong> <?php echo $email; ?></p>
                      <p><a href="#"> <span class="glyphicon glyphicon-phone-alt"></span> </a> <strong>Cell Phone / Phone:</strong> <?php echo $cellphone; ?></p>
                      <p><a href="#"> <span class="glyphicon glyphicon-comment"></span> </a> <strong>Message</strong>:</p>
                      <p><?php echo $message; ?> </p>
                    </div>
                    <div class="col-sm-12 col-lg-12 col-md-12 pull-left">
                      <p> The <?php echo site_name; ?> Team</p>
                      <h5> <a href="#"> <span class="glyphicon glyphicon-home"></span> </a> <strong><?php echo site_name; ?></strong></h5>
                      <h5> <a href="#"> <span class="glyphicon glyphicon-envelope"></span> </a> <?php echo $address; ?> <?php echo $surburb; ?></h5>
                      <h5><?php echo $city; ?> <?php echo $state; ?></h5>
                      <h5> <a href="#"> <span class="glyphicon glyphicon-phone-alt"></span> </a> <?php echo $cellphone; ?></h5>
                      <h5> <a href="#"> <span class="glyphicon glyphicon-phone-alt"></span> </a> <?php echo $telephone; ?></h5>
                      <h5><a href="#"> <span class="glyphicon glyphicon-inbox"></span> </a> <a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></h5>
                    </div>
                  </div></td>
              </tr>
            </table></td>
          <td></td>
        </tr>
        <tr>
          <td height="28"></td>
          <td></td>
          <td></td>
        </tr>
      </table></td>
    <td></td>
  </tr>
  <tr bgcolor="#576168">
    <td height="31"></td>
    <td></td>
    <td></td>
  </tr>
</table>
</body>
</html>