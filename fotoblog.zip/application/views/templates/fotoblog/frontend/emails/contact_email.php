<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php
	foreach ($contact_details as $row){
		if ($row['setting_name']=='Address'){
			$address = $row['setting_value'];
		}
		if ($row['setting_name']=='Surburb'){
			$surburb = $row['setting_value'];
		}
		if ($row['setting_name']=='City'){
			$city = $row['setting_value'];
		}
		if ($row['setting_name']=='State (Pronvince)'){
			$state = $row['setting_value'];
		}
		if ($row['setting_name']=='Cellphone'){
			$cellphone = $row['setting_value'];
		}
		if ($row['setting_name']=='Telephone'){
			$telephone = $row['setting_value'];
		}
		if ($row['setting_name']=='Google Maps'){
			$map = $row['setting_value'];
		}
		if ($row['setting_name']=='Email'){
			$email = $row['setting_value'];
		}
	}	
		$map = explode("&quot;",$map);
			foreach ($map as $key => $value){
				if ($key == 1){
					$map_src = $value;
				}
		}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $this->config->item('base_url'); ?></title>

<!-- Bootstrap -->
<link href="<?php echo $this->config->item('base_url'); ?>assets/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo $this->config->item('base_url'); ?>assets/css/style.css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="container-email">
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <h1 class="text-center"><?php echo site_name; ?></h1>
    </div>
  </div>
  <hr>
</div>
<div class="container-email">
  <div class="row">
    <div class="col-md-12">
      <div class="well">
      <div class="col-sm-12 col-lg-12 col-md-12 pull-left">
        <p>Dear <?php echo $name; ?></p>
        <p>Thank you for your email</p>
        <p>This is an automated email that confirms we have received your email and one of our consultants will get back to you as soon as possible.</p>
        <p><a href="#"> <span class="glyphicon glyphicon-user"></span> </a> <strong>Name:</strong> <?php echo $name; ?></p>
        <p><a href="#"> <span class="glyphicon glyphicon-inbox"></span> </a> <strong>Email:</strong> <?php echo $email; ?></p>
        <p><a href="#"> <span class="glyphicon glyphicon-phone-alt"></span> </a> <strong>Cell Phone / Phone:</strong> <?php echo $cellphone; ?></p>
        <p><a href="#"> <span class="glyphicon glyphicon-comment"></span> </a> <strong>Message</strong>:</p>
         <p><?php echo $message; ?> </p>
        </div>
        <div class="col-sm-12 col-lg-12 col-md-12 pull-left">
        <p> The <?php echo site_name; ?> Team</p>
          <h5> <a href="#"> <span class="glyphicon glyphicon-home"></span> </a> <strong><?php echo site_name; ?></strong></h5>
          <h5> <a href="#"> <span class="glyphicon glyphicon-envelope"></span> </a> <?php echo $address; ?> <?php echo $surburb; ?></h5>
          <h5><?php echo $city; ?> <?php echo $state; ?></h5>
          <h5> <a href="#"> <span class="glyphicon glyphicon-phone-alt"></span> </a> <?php echo $cellphone; ?></h5>
          <h5> <a href="#"> <span class="glyphicon glyphicon-phone-alt"></span> </a> <?php echo $telephone; ?></h5>
          <h5><a href="#"> <span class="glyphicon glyphicon-inbox"></span> </a> <a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></h5>
        </div>
      </div>
    </div>
  </div>
  <div class="row"></div>
  <div class="row">
    <div class="text-center col-md-6 col-md-offset-3">
      <h4>Footer </h4>
      <p>Copyright &copy; <?php echo date('Y'); ?>. All Rights Reserved &middot; <a href="<?php echo $this->config->item('base_url'); ?>" ><?php echo site_name; ?></a></p>
    </div>
  </div>
  <hr>
</div>
</body> 
</html>
