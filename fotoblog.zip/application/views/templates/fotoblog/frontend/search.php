<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
$blog=$this->uri->segment(3);
?>

<section class="front-div margin-bottom-1 myDiv">
<div class="container">
<div class="row">
<div class="col-xs-8  well left"> 
  
  <!--search galleries-->
  <?php if  (count($search_galleries) > 0) { ?>
  <?php echo '<div class="btn btn-success" >Gallery Search Results for: <strong>'.$keyword.'</strong></div>'; ?>
  <div class="col-12 front-div">
    <?php foreach ($search_galleries as $row){ ?>
    
    <!-- first row -->
    <div class="col-md-3"> 
    <a href="<?php echo $this->config->item('base_url'); ?>out/gallery/<?php echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>" > <img src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_gal_image_tbn']; ?>" data-toggle="tooltip" data-placement="bottom" title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery"   alt="<?php echo $row['blog_gal_name']; ?>"/> </a> 
      <!--end col-lg-12--></div>
    <?php } ?>
    <!--end col-lg-12--></div>
  <?php }else{ ?>
  <div class="col-12 front-div">
    <h3 class="btn btn-warning">Article Search results for <?php echo '<strong>'.$keyword.'</strong>'; ?></h3>
    <p>Sorry the search for <?php echo '<strong>'.$keyword.'</strong>'; ?> retruned no results in Galleries. </p>
  </div>
  <?php } ?>
  <!-- end search galleries-->
  
  <!--start articles search -->
  <div class="clear-fix push-down-five" style="clear:both" ></div>
  <?php if  (count($detailed_search_articles) > 0) { ?>
  <?php echo '<div class="btn btn-success" >Search Results for: <strong>'.$keyword.'</strong></div>'; ?>
  <?php foreach ($detailed_search_articles as $k=>$v) {; ?>
  <div class="col-12 front-div">
    <h3 class="page-header"><?php echo str_replace($keyword, '<span style="background-color:yellow; padding:2px;">'.$keyword.'</span>', $v['blog_articles_pagetitle']); ?></h3>
    <p>Posted on <strong  id="h3"><?php echo $v['blog_article_date']; ?></strong> by <strong  id="h3"><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></strong> in <strong> <?php echo $v['blog_articles_catergory']; ?></strong></p>
    <p><?php echo  str_replace($keyword, '<span style="background-color:yellow; padding:2px;">'.$keyword.'</span>', substr(strip_tags(html_entity_decode($v['blog_articles_description'])),0,500)); ?>...<small class="text-uppercase readmore-col"><a href="<?php echo $this->config->item('base_url'); ?>out/index/<?php echo $v['blog_id']; ?>/<?php echo $v['blog_articles_id']; ?>"> View More <span class="glyphicon glyphicon-circle-arrow-right"></span></a></small></p>
  </div>
  <?php } ?>
  <?php }else{ ?>
  <div class="col-12 front-div">
    <h3 class="btn btn-warning">Article Search results for <?php echo '<strong>'.$keyword.'</strong>'; ?></h3>
    <p>Sorry the search for <?php echo '<strong>'.$keyword.'</strong>'; ?> retruned no results in blog posts. </p>
  </div>
  <?php } ?>
  <!--end articles search -->

</div>
