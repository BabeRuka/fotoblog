<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>
<section class="front-div margin-bottom-1">
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
  <div class="col-md-12 well">
<div><strong>Please Fill in Your Personal Details Below:</strong></div>
<?php echo form_open(''.$url.'register/index'); ?>

<div class="margin-down-two"><h5>Username</h5>
<?php echo form_error('blog_username'); ?>
<input name="blog_username" type="text" required class="form-control" value="<?php echo set_value('blog_username'); ?>" size="50" /></div>

<div class="margin-down-two"><h5>Password</h5>
<?php echo form_error('blog_password'); ?>
<input name="blog_password" type="password" required class="form-control" value="<?php echo set_value('blog_password'); ?>" size="50" /></div>

<div class="margin-down-two"><h5>Password Confirm</h5>
<?php echo form_error('blog_password_confirm'); ?>
<input name="blog_password_confirm" type="password" required class="form-control" value="<?php echo set_value('blog_password_confirm'); ?>" size="50" /></div>

<div class="margin-down-two"><h5>First Name</h5>
<?php echo form_error('blog_fname'); ?>
<input name="blog_fname" type="text" required class="form-control" value="<?php echo set_value('blog_fname'); ?>" size="50" /></div>

<div class="margin-down-two"><h5>Last Name</h5>
<?php echo form_error('blog_lname'); ?>
<input name="blog_lname" type="text" required class="form-control" value="<?php echo set_value('blog_lname'); ?>" size="50" /></div>

<div class="margin-down-two"><h5>Email Address</h5>
<?php echo form_error('blog_email'); ?>
<input name="blog_email" type="text" required class="form-control" value="<?php echo set_value('blog_email'); ?>" size="50" /></div>

<div class="margin-down-two"><h5>The Name of Your Page</h5>
<?php echo form_error('blog_pagetitle'); ?>
<input name="blog_pagetitle" type="text" required class="form-control" value="<?php echo set_value('blog_pagetitle'); ?>" size="50" /></div>

<div class="margin-down-two"><h5>A Short Description of Your Blog</h5>
<?php echo form_error('blog_description'); ?>
<textarea name="blog_description" rows="10"  class="form-control" value="<?php echo set_value('blog_description'); ?>" ></textarea></div>


<div class="margin-down-two"><input type="submit" class="btn btn-info" value="Submit" /></div>

<input type="hidden" name="blog_id" value="" />
<input type="hidden" name="blog_level" value="Yet to be Administered" />
<input type="hidden" name="blog_activicationkey" value="<?php $activationKey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand(); ?>" />

</form>
</div>
</div>
</div>