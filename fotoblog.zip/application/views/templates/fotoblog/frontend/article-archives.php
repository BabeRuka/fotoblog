<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
  <?php if (count($my_archives) > 0) {  ?>
    
    <?php
		if ($this->uri->segment(5) == 1 ) { $month = 'January';  }
		else if ($this->uri->segment(5) == 2 ) { $month = 'February';  }
		else if($this->uri->segment(5) == 3 ) { $month = 'March';  }
		else if($this->uri->segment(5) == 4 ) { $month = 'April';  }
		else if($this->uri->segment(5) == 5 ) { $month = 'May';  }
		else if($this->uri->segment(5) == 6 ) { $month = 'June';  }
		else if($this->uri->segment(5) == 7 ) { $month = 'July';  }
		else if($this->uri->segment(5) == 8 ) { $month = 'August';  }
		else if($this->uri->segment(5) == 9 ) { $month = 'September';  }
		else if($this->uri->segment(5) == 10 ) { $month = 'October';  }
		else if($this->uri->segment(5) == 11 ) { $month = 'November';  }
		else if($this->uri->segment(5) == 12 ) { $month = 'December';  }

		?>
    <?php echo '<h1>Archive Results for '.$month.' '.$this->uri->segment(4).'</h1>'; ?>
    <?php foreach ($archived_articles as $k=>$v) {; ?>
    <div class="col-md-12 well"> <?php echo '<h3>'.$v['blog_articles_pagetitle'].'</h3>'; ?>
      <?php if ($v['blog_articles_image']){ ?>
      <div><img src="<?php echo $url.'assets/images/articles/'.$v['blog_articles_image'].''; ?>" align="left" border="2"  class="img-thumbnail my-pic" /></div>
      <?php } ?>
      <div><?php echo strip_tags(substr($v['blog_articles_shortdesc'], 0,600)).''; ?>
        <div style="margin-top:2%;">
          <div class="btn btn-default"><a href="<?php echo $url.'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore</a></div>
          <div class="btn btn-default"><?php echo  $v['blog_article_hits'].''; ?> Hits</div>
        </div>
      </div>
    </div>
    <?php } ?>
    <?php }  ?>
  </div>
</div>
</div></div>