<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
$blog=$this->uri->segment(3);
?>
<section class="front-div margin-bottom-1">
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
  
      <div class="col-md-12 well image-shadow">
        <?php if (count($this->profile) > 0) {  ?>
        <?php foreach ($this->profile as $k=>$v) {; ?>
        <div class="col-sm-12 col-sm-12 text-center front-div">
          <?php 
		  	$paths = $v['blog_profile_pic']; 
			$paths = explode ('.', $paths);
			$one = $paths[0];
			$two = end($paths); 
			$three = '.'.$two;
		    $profile_pic = str_replace(''.$three.'', '', $v['blog_profile_pic']); 
			$blog_fname = $v['blog_fname'];
			$blog_lname = $v['blog_lname']; 
		  ?>
          <img class="img-circle img-thumbnail" alt="<?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?>"  src="<?php echo $this->config->item('base_url'); ?>assets/images/<?php echo $profile_pic.'_cropped_300_300.'.$two; ?>" data-holder-rendered="true"> </div>
        <h3 class="text-center page-header""><?php echo $v['blog_pagetitle'];  ?></h3>
        <blockquote>
          <?php 
	  $blog_description=$v['blog_description'] ; 
	  $blog_description = strip_tags(preg_replace('/<[^>]*>/','',str_replace(array("&nbsp;","\n","\r"),"",html_entity_decode($blog_description,ENT_QUOTES,'UTF-8'))));
	  echo $blog_description; 
  ?>
          <h4><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></h4>
        </blockquote>
        <?php } } ?>
      </div>
  
 <div class="col-md-12 well">
 <?php if (count($my_page) > 0) {  ?>
<?php foreach ($my_page as $k=>$v) {; ?>
  <?php echo '<h3>'.$v['blog_content_pagetitle'].'</h3>

<div>'.html_entity_decode($v['blog_content_description']).'</div>
<div style="margin-top:2%; margin-bottom:2%; ">
</div>'; 
?>
  <?php } ?>  
  <?php } ?>
</div>
</div>
</div>

