<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php if ($this->agent->is_mobile()) {
}
$link = $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
//echo $link; echo 'link'; echo ' '; echo $_SERVER['SERVER_NAME'].'gallery/index'
?>
<?php if ($link == $_SERVER['SERVER_NAME'].'/gallery/index'){ ?>
<body onload="pageLoader()">
<?php }else{ ?>
<body onload="pageLoader()">
<?php } ?>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
    <div  class="header">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <div class="logo pull-left">
          <div id="logo">
            <?php if ( $this->show_image_logo=='Show Image Logo'  ){  ?>
            <img src="<?php echo $this->config->item('base_url'); ?>assets/images/settings/<?php echo $this->site_logo; ?>" alt="<?php echo site_name; ?>"/>
            <?php }else{ ?>
            <span class="glyphicon glyphicon-camera"></span> <?php echo site_name; ?>
            <?php }?>
            <!-- logo --></div>
          <!-- logo pull-left --></div>
      </div>
     <div id="navbar" class="collapse navbar-collapse"> 
        <div class="menu pull-left">
         <ul class="nav navbar-nav">
            <?php if ($this->default_homepage=='Show Full Homepage'){  ?>
            <li><a href="<?php echo $this->config->item('base_url'); ?>gallery/web">Home <span class="sr-only">(current)</span></a></li>
            <?php }else if($this->default_homepage=='Hide Full Homepage'){ ?>
            <li><a href="<?php echo $this->config->item('base_url'); ?>gallery/index">Home <span class="sr-only">(current)</span></a></li>
            <?php }else{ ?>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true">Homepage <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="<?php echo $this->config->item('base_url'); ?>gallery/web">Full Homepage <span class="sr-only">(current)</span></a></li>
                <li role="separator" class="divider"></li>
                <li><a href="<?php echo $this->config->item('base_url'); ?>gallery/index">Gallery Homepage<span class="sr-only">(current)</span></a></li>
              </ul>
            </li>
            <?php } ?>
            <?php if ($this->about_data){ ?>
            <li><a href="<?php echo $this->config->item('base_url'); ?>page/about">About</a></li>
            <?php } ?>
            <?php if ( ($this->show_blog_posts=='Show Blog Posts') && ($this->show_blog=='Show Blog' ) ){  ?>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true">Blog <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="<?php echo $this->config->item('base_url'); ?>blogs/index">Blogs</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="<?php echo $this->config->item('base_url'); ?>blog/all">Blog Posts</a></li>
              </ul>
            </li>
            <?php } ?>
            <?php if(count($this->blog_pages) > 0) { ?>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Pages<span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">
                <?php foreach ($this->blog_pages as $k=>$v){ ?>
                <?php echo '<li><a href="'.$this->config->item('base_url').'page/index/'. $v['blog_id'].'/'. $v['blog_content_id'].'">'. ''.'
	  '.$v['blog_content_pagetitle'].'</a></li>';  ?>
                <?php }  ?>
              </ul>
            </li>
            <?php }  ?>
            <?php if($this->register_link=='Show Register Link') { ?>
            <li><a href="<?php echo $this->config->item('base_url'); ?>register/index">Register</a></li>
            <?php } ?>
            <li><a href="<?php echo $this->config->item('base_url'); ?>contact/index">Contact</a></li>
            <?php if ($this->session->userdata('blog_id')){ ?>
            <li><a href="<?php echo $this->config->item('base_url'); ?>dashboard/index">Admin Home <span class="sr-only">(current)</span></a></li>
            <li><a href="<?php echo $this->config->item('base_url'); ?>logout/index" id="MenuBarItemSubmenu"><span class="glyphicon glyphicon-log-out"></span></a></li>
            <?php }else{ ?>
            <li><a href="<?php echo $this->config->item('base_url'); ?>login/index">Login<span class="sr-only">(current)</span></a></li>
            <?php }?>
          </ul>
        </div>
        <div class="pull-right">
          <ul class="social">
            <li><a href="#"><img src="<?php echo $this->config->item('base_url'); ?>assets/images/facebook.png" alt=""/></a></li>
            <li><a href="#"><img src="<?php echo $this->config->item('base_url'); ?>assets/images/twitter.png" alt=""/></a></li>
            <li><a href="#"><img src="<?php echo $this->config->item('base_url'); ?>assets/images/instagram.png" alt=""/></a></li>
            <li><a href="#"><img src="<?php echo $this->config->item('base_url'); ?>assets/images/vimeo.png" alt=""/></a></li>
            <li><a href="#"><img src="<?php echo $this->config->item('base_url'); ?>assets/images/gmail.png" alt=""/></a></li>
          </ul>
          <div> 
            <!-- right --> </div>
          <!-- menu --> </div>
      </div>
      <!--/.nav-collapse --> 
    </div>
    <!--/.header --> 
  </div>
</nav>
