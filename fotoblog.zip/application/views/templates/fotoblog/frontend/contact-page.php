<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php
	foreach ($contact_details as $row){
		if ($row['setting_name']=='Address'){
			$address = $row['setting_value'];
		}
		if ($row['setting_name']=='Surburb'){
			$surburb = $row['setting_value'];
		}
		if ($row['setting_name']=='City'){
			$city = $row['setting_value'];
		}
		if ($row['setting_name']=='State (Pronvince)'){
			$state = $row['setting_value'];
		}
		if ($row['setting_name']=='Cellphone'){
			$cellphone = $row['setting_value'];
		}
		if ($row['setting_name']=='Telephone'){
			$telephone = $row['setting_value'];
		}
		if ($row['setting_name']=='Google Maps'){
			$map = $row['setting_value'];
		}
		if ($row['setting_name']=='Email'){
			$email = $row['setting_value'];
		}
	}	
		$map = explode("&quot;",$map);
			foreach ($map as $key => $value){
				if ($key == 1){
					$map_src = $value;
				}
		}

?>

<section class="front-div margin-bottom-1 myDiv">
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
  <?php echo $success; ?>
    <div class="col-md-12 well">
      <iframe src="<?php echo $map_src; ?>" frameborder="0" style="border:0" allowfullscreen> </iframe>
    </div>
    
    <div class="col-md-8 pull-left">
  <h4><strong>Contact Form</strong></h4>
  <form method="post" name="form1" action="<?php echo $this->config->item('base_url'); ?>contact/index">
    <div class="margin-down-two"><h5>Names</h5>
      <input name="user_name" type="text" required class="form-control"  >
    </div>
    <div class="margin-down-two"><h5>Email</h5>
      <input name="user_email" type="email" required class="form-control" >
    </div>
    <div class="margin-down-two"><h5>Cell Phone</h5>
      <input name="user_cell" type="tel" required class="form-control" >
    </div>
    <div class="margin-down-two"><h5>Message</h5>
      <textarea  name="user_msg" cols="10" rows="10" required  class="form-control"></textarea>
    </div>
    <div class="margin-down-two">
      <input type="submit" class="btn btn-info" value="Send">
    </div>
    <input type="hidden" name="contact_us" value="form1">
  </form>
  </div>
  <div class="col-sm-12 col-lg-3 col-md-3 pull-right">
  <h5>
  <a href="#"> <span class="glyphicon glyphicon-home"></span> </a>
  <strong><?php echo site_name; ?></strong></h5>
  <h5>
   <a href="#"> <span class="glyphicon glyphicon-envelope"></span> </a>
  <?php echo $address; ?> <?php echo $surburb; ?></h5>
  <h5><?php echo $city; ?> <?php echo $state; ?></h5>
  <h5>
  <a href="#"> <span class="glyphicon glyphicon-phone-alt"></span> </a>
  <?php echo $cellphone; ?></h5>
  <h5>
  <a href="#"> <span class="glyphicon glyphicon-phone-alt"></span> </a>
  <?php echo $telephone; ?></h5>
  <h5><a href="#"> <span class="glyphicon glyphicon-inbox"></span> </a>
  <a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></h5>
</div>

  </div>
</div>
