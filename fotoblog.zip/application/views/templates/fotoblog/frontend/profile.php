<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<section class="front-div margin-bottom-1">
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
    <div class="col-md-12 well image-shadow">
      <?php if (count($profile) > 0) {  ?>
      <?php foreach ($profile as $k=>$v) {; ?>
      <div class="col-sm-12 col-sm-12 text-center front-div">
        <?php 
		  	$paths = $v['blog_profile_pic']; 
			$paths = explode ('.', $paths);
			$one = $paths[0];
			$two = end($paths); 
			$three = '.'.$two;
		    $profile_pic = str_replace(''.$three.'', '', $v['blog_profile_pic']); 
			$blog_fname = $v['blog_fname'];
			$blog_lname = $v['blog_lname']; 
		  ?>
        <img class="img-circle img-thumbnail" alt="<?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?>"  src="<?php echo $this->config->item('base_url'); ?>assets/images/<?php echo $profile_pic.'_cropped_300_300.'.$two; ?>" data-holder-rendered="true"> </div>
      <h3 class="text-center page-header"><?php echo $v['blog_pagetitle'];  ?></h3>
      <blockquote>
        <?php 
	  $blog_description=$v['blog_description'] ; 
	  $blog_description = strip_tags(preg_replace('/<[^>]*>/','',str_replace(array("&nbsp;","\n","\r"),"",html_entity_decode($blog_description,ENT_QUOTES,'UTF-8'))));
	  echo $blog_description; 
  ?>
        <h4><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></h4>
      </blockquote>
      <?php } } ?>
    </div>
    
    <?php if ($this->agent->is_mobile()) { ?>
    <div class="col-lg-12 col-md-12 well image-shadow thumbnail-posts">
      <?php  if (count($some_articles) > 0) {  ?>
      <h4><strong>Blog Posts by <?php echo $blog_fname; ?> <?php echo $blog_lname; ?></strong></h4>
      <div class="fix-padding-two" >
        <div >
          <?php foreach ($some_articles as $k=>$v) { ?>
          <div class="row front-div page-header">
          <div class="class="margin-down-two""><?php echo '<h4><strong>'.$v['blog_articles_pagetitle'].'</strong></h4>'; ?> </div>
            <div class="col-md-12" >
              <?php if ($v['blog_articles_image']){ ?>
              <img src="<?php echo $this->config->item('base_url').'assets/images/articles/'.$v['blog_articles_image']; ?>" class="img-thumbnail footer-pic image-shadow"  />
              <?php }else{ ?>
              <img src="<?php echo $this->config->item('base_url').'assets/images/64X64.gif'; ?>" align="left" border="2"  class="img my-pic image-shadow"  />
              <?php } ?>
            </div>
            <div class="col-md-12 margin-down-two"> <?php echo strip_tags(substr(html_entity_decode($v['blog_articles_shortdesc']), 0,100)); ?>... </div>
            <small class="text-uppercase readmore-col"><a href="<?php echo $this->config->item('base_url').'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore <span class="glyphicon glyphicon-circle-arrow-right"></span></a></small> </div>
          <?php } ?>
          <div class="clear-fix" > </div>
        </div>
      </div>
      <?php }  ?>
    </div>
    <?php }else{ ?>
    
    
<div class="col-lg-12 col-md-12 well image-shadow thumbnail-posts">
  <?php  if (count($some_articles) > 0) {  ?>
  <h4><strong>Blog Posts by <?php echo $blog_fname; ?> <?php echo $blog_lname; ?></strong></h4>
  <div class="fix-padding-two" >
    <div >
      <?php foreach ($some_articles as $k=>$v) { ?>
      <div class="row front-div page-header">
        <div class="col-md-2" >
          <?php if ($v['blog_articles_image']){ ?>
          <img src="<?php echo $this->config->item('base_url').'assets/images/articles/'.$v['blog_articles_image']; ?>" class="img-thumbnail footer-pic image-shadow"  />
          <?php }else{ ?>
          <img src="<?php echo $this->config->item('base_url').'assets/images/64X64.gif'; ?>" align="left" border="2"  class="img my-pic image-shadow"  />
          <?php } ?>
        </div>
        <div class="col-md-10"> <?php echo '<h4><strong>'.$v['blog_articles_pagetitle'].'</strong></h4>'; ?> <?php echo strip_tags(substr(html_entity_decode($v['blog_articles_shortdesc']), 0,100)); ?>... </div>
        <small class="text-uppercase readmore-col"><a href="<?php echo $this->config->item('base_url').'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore <span class="glyphicon glyphicon-circle-arrow-right"></span></a></small> </div>
      <?php } ?>
      <div class="clear-fix" > </div>
    </div>
  </div>
  <?php }  ?>
</div>
    
    
    <?php } ?>
    
    <?php  if (count($galleries) > 0) {  ?>
    <div  class="col-md-12 nopadding" style="margin-bottom:20px;">
      <h4><strong>Photo Galleries by <?php echo $blog_fname; ?> <?php echo $blog_lname; ?></strong></h4>
      <?php foreach ($galleries as $row){ ?>
      <?php 
             $image = explode('.',$row['blog_gal_image']);
             $image = $image[0].'_cropped_700_600.'.$image[1];
        ?>
      
      <!-- first row -->
      <div class="col-md-3 pull-left image-shadow nopadding"> <a href="<?php echo $this->config->item('base_url'); ?>gallery/browse/<?php echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>"> <img src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $image; ?>" data-toggle="tooltip" data-placement="bottom" title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery" class="img-responsive img-thumbnail-no-padding" alt="<?php echo $row['blog_gal_name']; ?>"/></a> <?php echo '<div class="col-title">
		<h3><strong>'.$row['blog_gal_name'].'</strong></h3>
		<h5>'.$row['blog_gal_date'].'</h5>
		</div>'; ?> 
        
        <!--end col-lg-12--></div>
      <?php } ?>
      
      <!--end row--></div>
    <?php  }  ?>
  </div>
</div>
