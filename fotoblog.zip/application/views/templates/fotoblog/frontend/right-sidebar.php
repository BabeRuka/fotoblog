<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<div class="col-sm-3 well pull-right margin-bottom-5" style="margin-bottom: 3% !important;">
  <h4 class="page-header" style=""><strong>Search <?php echo site_name; ?></strong> </h4>
  <div class="nopadding">
    <div class="input-append">
      <form action="<?php echo $this->config->item('base_url'); ?>search/index" method="post" role="search">
        <input name="description" type="text"  class="span2 form-control sidebar-search pull-left" id="appendedInputButtons"  required="required"   />
        <input type="submit" class="btn btn-info " value="Search">
      </form>
    </div>
  </div>
  <h4 class="page-header" style=""><strong>Latest Galleries</strong> </h4>
  <div class="container right-sidebar">
    <div class="row">
      <?php foreach ($this->latest_galleries as $row){ ?>
      
      <!-- first row -->
      <div> 
      <a href="<?php echo $this->config->item('base_url'); ?>out/gallery/<?php echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>" > 
      <img class="img-responsive pull-left" style="height:33%; width:33%" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_gal_image_tbn']; ?>" alt="<?php echo $row['blog_gal_name']; ?>" title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery" data-toggle="tooltip" data-placement="bottom"/> </a> 
        <!--end col-lg-12--></div>
      <?php } ?>
      
      <!-- end first row -->
      <div class="clearfix"> </div>
      
      <!--end col-lg-12--></div>
    <!--end col-lg-12--></div>
  <h4 class="page-header" style=""><strong>Latest Photos</strong> </h4>
  <div class="container right-sidebar">
    <div class="row">
      <?php foreach ($this->latest_photos as $row){ ?>
      <div> 
      <a href="<?php echo $this->config->item('base_url'); ?>out/photo/<?php echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>/<?php echo $row['blog_tbn_id']; ?>"> 
      <img class="img-responsive pull-left" style="height:33%; width:33%" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_tbn_image_tbn']; ?>" alt="<?php echo $row['blog_gal_name']; ?>" title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery" data-toggle="tooltip" data-placement="bottom"  /> 
      </a> 
      </div>
      <?php } ?>
      
      <!-- end first row -->
      <div class="clearfix"> </div>
      
      <!--end col-lg-12--></div>
    <!--end col-lg-12--></div>
  <?php if ($this->show_blog_posts=='Show Blog Posts'){ ?>
  <h4 class="page-header"><strong>Arcives</strong></h4>
  <ul class="list-group image-shadow">
    <?php foreach ($archived_articles as $k=>$v) {;  ?>
    <?php
		if ($v['MonthPublished'] == 1 ) { $month = 'January';  }
		else if ($v['MonthPublished'] == 2 ) { $month = 'February';  }
		else if ($v['MonthPublished'] == 3 ) { $month = 'March';  }
		else if ($v['MonthPublished'] == 4 ) { $month = 'April';  }
		else if ($v['MonthPublished'] == 5 ) { $month = 'May';  }
		else if ($v['MonthPublished'] == 6 ) { $month = 'June';  }
		else if ($v['MonthPublished'] == 7 ) { $month = 'July';  }
		else if ($v['MonthPublished'] == 8 ) { $month = 'August';  }
		else if ($v['MonthPublished'] == 9 ) { $month = 'September';  }
		else if ($v['MonthPublished'] == 10 ) { $month = 'October';  }
		else if ($v['MonthPublished'] == 11 ) { $month = 'November';  }
		else if ($v['MonthPublished'] == 12 ) { $month = 'December';  }
		?>
    <li class="list-group-item"><a href="<?php echo $url; echo 'all_archives/article/'; echo $v['YearPublished']; ?>/<?php echo $v['MonthPublished']; ?>" alt="<?php echo $v['ArticlesPublished']; ?> Articles Published for the month of <?php echo $v['MonthPublished']; ?>" title="<?php echo $v['ArticlesPublished']; ?> Articles Published for the month of <?php echo $month; ?>" ><?php echo $v['FullDate']; ?><span class="badge pull-right"><?php echo $v['ArticlesPublished']; ?> Articles</span></a></li>
    <?php } ?>
  </ul>
  <?php } ?>
  <?php if ($this->show_blog_posts=='Show Blog Posts'){ ?>
  <!-- categories -->
  
  <h4 class="page-header"><strong>Popular Categories</strong></h4>
  <ul class="list-group image-shadow">
    <?php 
	  foreach ($grouped_categories as $k=>$v) {; 
		 if ( $this->uri->segment(3) ) {
			$link = $url.'categories/category/'.$this->uri->segment(3).'/'.$v['blog_category_name']; 
		}else{
			$blog_id=$this->uri->segment(3,0);
			$link = $url.'categories/category/'.$blog_id.'/'.$v['blog_category_name']; 
		}
	    //echo '<h1>'.$this->uri->segment(3).' A PHP Error was encountered</h1>'; 
	   ?>
    <li class="list-group-item"> <a href="<?php echo $link; ?>" alt="<?php echo $v['TotalArticles']; ?> Articles in the <?php echo $v['blog_category_name']; ?> Categories" title="<?php echo $v['TotalArticles']; ?> Articles in the <?php echo $v['blog_category_name']; ?> Categories" ><?php echo $v['blog_category_name']; ?> <span class="badge pull-right"><?php echo $v['TotalArticles']; ?> Articles</span></a></li>
    <?php } ?>
  </ul>
  <?php } ?>
  <!-- end categories --> 
</div>
</div>
</div>

<!--end section-->
</section>
