<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (strlen(strstr($_SERVER['HTTP_USER_AGENT'], 'Firefox')) > 0) {
    $collumns = '7';
    $row_width = '94%';
}else if (strlen(strstr($_SERVER['HTTP_USER_AGENT'], 'Edge')) > 0) {
    $collumns = '7';
    $row_width = '94%';
}else{
    $collumns = '8';
    $row_width = '98%';
}
//active_slideshow($page, $type)
?> 
<?php if ($this->show_homepage_slide=='Show Homepage Slide'){ ?>
<?php if (count($slideshow) > 0){ ?>
<section>
  <div class="container">
    <div class="row">
      <div class="col-md-12"> 
        
        <!-- Carousel
    ================================================== -->
        <div id="homepageCarousel" class="carousel slide image-shadow" data-ride="carousel"> 
          <!-- Indicators -->
          <ol class="carousel-indicators">
           <li data-target="#homepageCarousel" data-slide-to="0" class="active"></li>
           <?php 
		   		$start = 0;
				foreach ($slideshow as $row){
				$start ++;
			?>
            <li id="<?php echo $row['slide_image_id']; ?>" data-target="#homepageCarousel" data-slide-to="<?php echo $start; ?>"></li>
          	<?php } ?>
          </ol>
          <div class="carousel-inner" role="listbox">

             <div class="item active"> 
             <?php
			 	$photo = explode('.',$one_slideshow);
			    $photo = $photo[0].'_cropped_900_600.'.$photo[1];
			  ?>
             <img class="img-responsive center-block img-polaroid my-pic" src="<?php echo $this->config->item('base_url'); ?>uploads/slideshows/<?php echo $photo; ?>"  /> 
             <!--caption-->
              <div class="container">
              
                    <div class="carousel-caption">
                      <h1><?php echo $slide_name; ?> <?php if($row['slide_image_name']){ echo '::'; echo $slide_image_name; } ?></h1>
                      <?php if($slide_image_caption){ ?><p><?php echo $slide_image_caption; ?></p><?php } ?>
                    </div>
              
              </div>             
             <!--caption-->
             </div>
             <?php foreach ($slideshow as $row){ ?>
             <?php
			 	$photo = explode('.',$row['slide_images_image']);
			    $photo = $photo[0].'_cropped_900_600.'.$photo[1];
			  ?>
             <div class="item"> 
             <img class="img-responsive" src="<?php echo $this->config->item('base_url'); ?>uploads/slideshows/<?php echo $photo; ?>" alt="..."> 
             <!--caption-->
              <div class="container">
              
                    <div class="carousel-caption">
                      <h1><?php echo $row['slide_name']; ?> <?php if($row['slide_image_name']){  echo '::';  echo $row['slide_image_name']; } ?></h1>
                     <?php if($row['slide_image_caption']){ ?> <p><?php echo $row['slide_image_caption']; ?></p> <?php } ?>
                    </div>
              
              </div>             
             <!--caption-->
             
             </div>
             <?php } ?>
            
          </div>
          <a class="left carousel-control" href="" role="button" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="right carousel-control" href="" role="button" data-slide="next"> <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
        <!-- /.carousel --> 
        
        <!--end col-lg-12--></div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>
<?php } ?>
<?php } ?> 
<!--Galleries-->
<section>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h3 class="text-uppercase">Latest  Galleries</h3><hr style="margin-right: 95%; border-top: 2px solid #000">
        <?php foreach ($galleries as $row){ ?>
        <?php 
             $image = explode('.',$row['blog_gal_image']);
             $image = $image[0].'_cropped_700_600.'.$image[1];
        ?>
        
        <!-- first row -->
        <div class="col-md-3 pull-left img-zoom"> 
        <a href="<?php echo $this->config->item('base_url'); ?>out/gallery/<?php echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>"> 
        <img src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $image; ?>" data-toggle="tooltip" data-placement="bottom" title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery" class="img-responsive img-thumbnail-no-padding" alt="<?php echo $row['blog_gal_name']; ?>"/>
        </a> 
		<?php echo '<div class="col-title">
		<h3><strong>'.$row['blog_gal_name'].'</strong></h3>
		<h5>'.$row['blog_gal_date'].'</h5>
		</div>'; ?> 
          
          <!--end col-lg-12--></div>
        <?php } ?>
        
        <!-- end first row -->
        <div class="clearfix"> </div>
        
        <!--end col-lg-12--></div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>
<!--Galleries--> 

<!--Galleries-->
<section>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h3 class="text-uppercase">Latest Gallery Photos</h3><hr style="margin-right: 95%; border-top: 2px solid #000">
        <?php foreach ($latest_photos as $row){ ?>
        <!-- first row -->

        <?php 
             $image = explode('.',$row['blog_tbn_image']);
             $image = $image[0].'_cropped_700_600.'.$image[1];
        ?>
        
        <!-- first row -->
        <div class="col-md-3 pull-left img-zoom"> 
        <a href="<?php echo $this->config->item('base_url'); ?>out/photo/<?php echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>/<?php echo $row['blog_tbn_id']; ?>"> 
        <img src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $image; ?>" data-toggle="tooltip" data-placement="bottom" title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery" class="img-responsive img-thumbnail-no-padding" alt="<?php echo $row['blog_gal_name']; ?>"/>
        </a> 
		<?php echo '<div class="col-title">
		<h3><strong>'.$row['blog_gal_name'].'</strong></h3>
		<h5>'.$row['blog_gal_date'].'</h5>
		</div>'; ?> 



          <!--end col-lg-12--></div>

        <?php } ?>
        
        <!-- end first row -->
        <div class="clearfix"> </div>
        
        <!--end col-lg-12--></div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>
<!--Galleries--> 

<!--articles-->

<section >
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h3 class="text-uppercase">Latest Blog Posts</h3><hr style="margin-right: 95%; border-top: 2px solid #000">
        <?php $c = 0 ; ?>
        <?php if (count($my_blog) > 0) {  ?>
        <?php /* loop through the data */ ?>
        <?php foreach ($my_blog as $k=>$v) {; ?>
        <?php 
               $image = explode('.',$v['blog_articles_image']);
               $image = $image[0].'_cropped_700_600.'.$image[1];
         ?>
        <?php if ($v['blog_articles_image']){ ?>
        <div class="col-md-3 pull-left img-zoom"> <img src="<?php echo $this->config->item('base_url').'assets/images/articles/'. $image.''; ?>" title="<?php echo $v['blog_articles_pagetitle']; ?>"  border="2"  class="img-responsive img-thumbnail-no-padding" data-toggle="tooltip" data-placement="bottom"  /> <?php echo '<div class="col-title">
					<h3><strong>'.$v['blog_articles_pagetitle'].'</strong></h3>
					<h5>'.$v['blog_article_date'].'</h5>
					</div>'; ?> </div>
        <?php }else{ ?>
        <div class="col-md-3 pull-left img-zoom"> <img src="<?php echo $this->config->item('base_url').'assets/images/300X200.gif'; ?>" title="<?php echo $v['blog_articles_pagetitle']; ?>"  border="2"  class="img-responsive img-thumbnail-no-padding" data-toggle="tooltip" data-placement="bottom"  /> <?php echo '<div class="col-title">
					<h3><strong>'.$v['blog_articles_pagetitle'].'</strong></h3>
					<h5>'.$v['blog_article_date'].'</h5>
					</div>'; ?> </div>
        <?php } ?>
        <?php } ?>
        <?php /* end loop through the data */ ?>
        <?php }  ?>
      </div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>

<?php if ($this->show_blog_posts=='Show Blog Posts'){ ?>
<!-- Blogs -->
<section>
  <div class="container">
    <div class="row" style="width:<?php echo $row_width; ?>">
      <div class="col-md-12">
        <h3 class="text-uppercase">Selected Blogs</h3><hr style="margin-right: 95%; border-top: 2px solid #000">
        <?php foreach ($all_blogs as $row){ ?>
        <?php 
               $image = explode('.',$row['blog_profile_pic']);
               $image = $image[0].'_cropped_700_600.'.$image[1];
         ?>
        <!-- first row -->
        <div class="col-md-3 pull-left img-zoom"> 
        <a href="<?php echo $this->config->item('base_url'); ?>blog/index/<?php echo $row['blog_id']; ?>">
        <img src="<?php echo $this->config->item('base_url'); ?>assets/images/<?php echo $image; ?>" title="<?php echo $row['blog_fname']; ?> <?php echo $row['blog_lname']; ?>"   alt="<?php echo $row['blog_fname']; ?> <?php echo $row['blog_lname']; ?>" class="img-responsive img-thumbnail-no-padding" />
        </a> 
        
		<?php echo '<div class="col-title">
					<h3><a href="'.$this->config->item('base_url').'blog/index/'.$row['blog_id'].'">'.$row['blog_pagetitle'].'</a></h3>
					<h5><strong>'.$row['blog_fname'].' '.$row['blog_lname'].'</strong></h5>
		</div>'; ?>        
        
          <!--end col-lg-12--></div>
        <?php } ?>
        
        <!-- end first row -->
        <div class="clearfix"> </div>
        
        <!--end col-lg-12--></div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>
<!-- Blogs -->
<?php } ?>