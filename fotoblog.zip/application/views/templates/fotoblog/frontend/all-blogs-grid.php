<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (strlen(strstr($_SERVER['HTTP_USER_AGENT'], 'Firefox')) > 0) {
    $collumns = '6';
}else if (strlen(strstr($_SERVER['HTTP_USER_AGENT'], 'Edge')) > 0) {
    $collumns = '6';
}else{
    $collumns = '7';
}
?>
<section class="front-div margin-bottom-1 myDiv">
<div class="container">
<div class="row">
<div class="col-md-8">
  <?php $c = 0 ; ?>
  <?php if (count($my_blog) > 0) {  ?>
  <?php foreach ($my_blog as $k=>$v) {; ?>
   <?php $c++; ?>

     	
     <div class="row-fluid">
     	 <?php if ($c % 2 !== 0) { ?>
         	 	<div class="col-md-5 pull-left">
				<?php if ($v['blog_articles_image']){ ?>
                <?php 
                    $image = explode('.',$v['blog_articles_image']);
                    $image = $image[0].'_cropped_700_600.'.$image[1];
                ?><!--left-->
                     <div class="col-md-12">
                     <img src="<?php echo $this->config->item('base_url').'assets/images/articles/'. $image.''; ?>" title="<?php echo $v['blog_articles_pagetitle']; ?>" border="2"  class="img-thumbnail my-pic center-block image-shadow"  />
                     </div>
                <?php }else{ ?>
                	<div class="col-md-12">
                    <img src="<?php echo $this->config->item('base_url').'assets/images/700X600.gif'; ?>" title="<?php echo $v['blog_articles_pagetitle']; ?>"  border="2" class="img-thumbnail my-pic center-block image-shadow"  />
                    </div>
                <?php } ?>         
             	<div class="col-md-12  well ">
                <?php echo '<h4><strong>'.$v['blog_articles_pagetitle'].'</strong></h4>'; ?>
                <h5 class="text-primary">Posted on <strong><?php echo $v['blog_article_date']; ?></strong></h5>
                <?php echo strip_tags(substr(html_entity_decode($v['blog_articles_shortdesc']), 0,500)); ?> ...
                
                  <div class="front-div">
                    <div class="btn btn-xs pull-right text-uppercase readmore-col"><a href="<?php echo $this->config->item('base_url').'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore <span class="glyphicon glyphicon-circle-arrow-right"></span></a></div>
                  </div>
                
                </div>
             </div>
         	 <!--left-->
         <?php } else { ?>
         	 <!--right-->
         	 	<div class="col-md-5 pull-right">
				<?php if ($v['blog_articles_image']){ ?>
                <?php 
                    $image = explode('.',$v['blog_articles_image']);
                    $image = $image[0].'_cropped_700_600.'.$image[1];
                ?><!--left-->
                     <div class="col-md-12">
                     <img src="<?php echo $this->config->item('base_url').'assets/images/articles/'. $image.''; ?>" title="<?php echo $v['blog_articles_pagetitle']; ?>" border="2"  class="img-thumbnail my-pic center-block image-shadow"  />
                     </div>
                <?php }else{ ?>
                	<div class="col-md-12">
                    <img src="<?php echo $this->config->item('base_url').'assets/images/700X600.gif'; ?>" title="<?php echo $v['blog_articles_pagetitle']; ?>"  border="2" class="img-thumbnail my-pic center-block image-shadow"  />
                    </div>
                <?php } ?>         
             	<div class="col-md-12  well ">
                
                <?php echo '<h4><strong>'.$v['blog_articles_pagetitle'].'</strong></h4>'; ?>
                <h5 class="text-primary">Posted on <strong><?php echo $v['blog_article_date']; ?></strong></h5>
                <?php echo strip_tags(substr(html_entity_decode($v['blog_articles_shortdesc']), 0,500)); ?> ...
                
                  <div class="front-div">
                    <div class="btn btn-xs pull-right text-uppercase readmore-col"><a href="<?php echo $this->config->item('base_url').'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore <span class="glyphicon glyphicon-circle-arrow-right"></span></a></div>
                  </div>
                
                </div>
             </div>
          	 <!--right-->
        <?php }?>

    </div>
 
  <?php } ?>
  <?php }  ?>
</div>
