<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php foreach ($my_blog_comments as $k=>$v) {; ?>

<div class="row ">
  <div class="col-sm-12 fix-padding-five-left-right">
    <!-- /thumbnail --><div class="col-sm-2"> <img src="<?php echo $this->config->item('base_url').'assets/images/'; ?>avatar.png" width="32" height="32" class="img-responsive tbnail"> </div><!-- /thumbnail -->
    
    
    <div class="col-sm-10 pull-right">
      <p><small> <strong><?php echo $v['blog_comment_name']; ?></strong> <span class="text-muted"><?php echo $v['blog_comment_date']; ?></span> </small></p>
      <small> <?php echo $v['blog_comment_comment']; ?> </small> </div>
    <!-- col-sm-10 pull-right --> 
  </div>
  <!-- col-sm-12 --> 
</div>
<!-- /row -->
<?php } ?>
<!--comments--> 
