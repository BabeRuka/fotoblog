<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<section class="front-div margin-bottom-1">
<div class="container">
<div class="row">
<div class="col-md-8 well">
  <div class="col-md-6 ">
  <h4>Reset Password</h4>
    <div align="center"><strong><?php if ($message) { echo $message; }  ?></strong></div>
    <?php echo form_open(''.$url.'password/reset'); ?>
    <div class="margin-down-two">
      <h5>Email Address</h5>
      <?php //echo $email_error; ?>
      <?php echo form_error('blog_email'); ?>
      <input name="blog_email" type="email" required class="form-control" value="<?php echo set_value('blog_email'); ?>" size="50" />
    </div>
    <div class="margin-down-two">
      <input type="submit" value="Submit" class="btn btn-info"/>
    </div>
    </form>
  </div>
</div>
