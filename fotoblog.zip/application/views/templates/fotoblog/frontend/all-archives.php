<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>
<section class="front-div margin-bottom-1">
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
    <?php if (count($archives) > 0) {  ?>
    <?php
		if ($this->uri->segment(4)) {
			if ($this->uri->segment(4) == 1 ) { $month = 'January';  }
			else if ($this->uri->segment(4) == 2 ) { $month = 'February';  }
			else if($this->uri->segment(4) == 3 ) { $month = 'March';  }
			else if($this->uri->segment(4) == 4 ) { $month = 'April';  }
			else if($this->uri->segment(4) == 5 ) { $month = 'May';  }
			else if($this->uri->segment(4) == 6 ) { $month = 'June';  }
			else if($this->uri->segment(4) == 7 ) { $month = 'July';  }
			else if($this->uri->segment(4) == 8 ) { $month = 'August';  }
			else if($this->uri->segment(4) == 9 ) { $month = 'September';  }
			else if($this->uri->segment(4) == 10 ) { $month = 'October';  }
			else if($this->uri->segment(4) == 11 ) { $month = 'November';  }
			else if($this->uri->segment(4) == 12 ) { $month = 'December';  }
		
		?>
    <div class="col-md-12 well"><?php echo '<strong><h4>Archive Results for '.$month.' '.$this->uri->segment(3).'</h4></strong>'; ?></div>
    <?php foreach ($archives as $k => $v) {  ?>
    <?php 
               $image = explode('.',$v['blog_articles_image']);
               $image = $image[0].'_cropped_700_600.'.$image[1];
         ?>
    <div class="col-md-12 well image-shadow thumbnail-posts">
      <div class="col-md-4 pull-left fix-right-two image-shadow">
        <div> <img src="<?php echo $url.'assets/images/articles/'.$v['blog_articles_image'].''; ?>"  align="left" border="2"  class="img-thumbnail my-pic" /> </div>
      </div>
      <div class="col-md-7 pull-left "> <?php echo '<h4><strong>'. $v['blog_articles_pagetitle'].'</h4></strong>'; ?> <?php echo strip_tags(substr(html_entity_decode($v['blog_articles_description']), 0,500));  ?>
        <div class="margin-down-five"> <small class="pull-right text-uppercase readmore-col"> <a href="<?php echo ''.$url.'out/index/'.$v['blog_id'].'/'.$v['blog_articles_id'].''; ?> ">Readmore</a> </small> </div>
      </div>
    </div>
    <?php } }?>
    <?php }  ?>
  </div>
</div>
