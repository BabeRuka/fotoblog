<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
$blog=$this->uri->segment(3);
?>
<section class="front-div">
<div class="container">
<div class="row">
<div class="col-md-8">
  <div class="row">
 <div class="col-md-12 well">
 <?php if (count($about_page) > 0) {  ?>
<?php foreach ($about_page as $k=>$v) {; ?>
  <?php echo '<h3>'.$v['blog_content_pagetitle'].'</h3>

<div>'.html_entity_decode($v['blog_content_description']).'</div>
<div style="margin-top:2%; margin-bottom:2%; ">
</div>'; 
?>
  <?php } ?>  
  <?php } ?>
</div>
</div>
</div>

