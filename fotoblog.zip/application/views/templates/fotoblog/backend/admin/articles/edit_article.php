<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
foreach ($article_details as $k=>$v){
		$blog_id= $v['blog_id'];
		$blog_category_id = $v['blog_category_id'];
		$blog_articles_id = $v['blog_articles_id'];
		$blog_articles_page = $v['blog_articles_page'];
		$blog_articles_pagetitle = $v['blog_articles_pagetitle'];
		$blog_category_name = $v['blog_category_name'];
		$blog_articles_level= $v['blog_articles_level'];
		$blog_articles_catergory = $v['blog_articles_catergory'];
		$blog_username= $v['blog_username'];
		$blog_articles_shortdesc= $v['blog_articles_shortdesc'];
		$blog_fname= $v['blog_fname'];
		$blog_lname= $v['blog_lname'];
		$blog_email= $v['blog_email'];
		$blog_level= $v['blog_level'];
		$blog_articles_description = $v['blog_articles_description'];
		$blog_articles_shortdesc = $v['blog_articles_shortdesc'];
}
$category_name = '';
foreach ($article_cats as $k=>$v){
		$category_name .= ','.$v['blog_category_name'];
}
?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Articles <span class="divider">/</span></li>
      <li class="active">Edit Article </li>
    </ul>
  </div>
   <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">
    <div class="row">
      <div class="col-md-7 well">
        <div align="center"><strong><?php echo $success; ?></strong></div>
        <div class="table-responsive">
          <table class="table table-striped">
            <tr>
              <td align="center" valign="middle"><div align="center" style="font-weight: bold">Author</div></td>
              <td align="center" valign="middle"><div align="center" style="font-weight: bold">Title</div></td>
              <td align="center" valign="middle">Featured Image</td>
              <td><div align="center" style="font-weight: bold">Article Status</div></td>
              <td><div align="center" style="font-weight: bold">Published Date</div></td>
              <td colspan="2"><div align="center" style="font-weight: bold">Actions</div></td>
            </tr>
            <?php foreach ($all_articles as $row_Articles){ ?>
            <tr >
              <td align="center" valign="middle"><a href="#"><?php echo $row_Articles['blog_fname']; ?> <?php echo $row_Articles['blog_lname']; ?></a></td>
              <td align="center" valign="middle"><a href="#"><?php echo $row_Articles['blog_articles_pagetitle']; ?></a></td>
              <td align="center" valign="middle"><a href="#">
                <?php if ($row_Articles['blog_articles_image']){ ?>
                <a href="<?php echo $this->config->item('base_url'); ?>featured/index/<?php echo $row_Articles['blog_articles_id']; ?>"> <img src="<?php echo $this->config->item('base_url'); ?>assets/images/articles/<?php echo $row_Articles['blog_articles_image']; ?>" alt="Upload a Featured Image" title="Upload a Featured Image" alt="Upload a Featured Image" width="50" height="50" /> </a>
                <?php }else{ ?>
                <div class="btn btn-default btn-xs"> <a href="<?php echo $this->config->item('base_url'); ?>featured/index/<?php echo $row_Articles['blog_articles_id']; ?>">Upload Featured Image</a></div>
                <?php } ?>
                </a></td>
              <td><a href="#"><?php echo $row_Articles['blog_articles_level']; ?></a></td>
              <td><a href="#"><?php echo $row_Articles['blog_article_date']; ?></a></td>
              <td></td>
              <td>
              <a href="<?php echo $base_url; ?>admin/articles/edit/<?php echo $row_Articles['blog_articles_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Edit <?php echo $row_Articles['blog_articles_pagetitle']; ?>" ><span class="glyphicon glyphicon-edit"></a></span></div>
              <a href="<?php echo $base_url; ?>admin/articles/delete/<?php echo $row_Articles['blog_articles_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Delete <?php echo $row_Articles['blog_articles_pagetitle']; ?>" onclick="return confirm('Are you sure you want to delete?')"><span class="glyphicon glyphicon-remove-sign"></a></span></div></td>
            </tr>
            <?php }  ?>
          </table>
        </div>
      </div>
      <!-- start right-->
      <div class="col-md-4 well pull-right">
        <h4><strong>Edit <?php echo $blog_articles_pagetitle; ?> </strong></h4>
        <form method="post" name="form1" action="<?php echo $base_url; ?>admin/articles/edit">
          <div>Pagetitle of Article:</div>
          <div>
            <input type="text" class="form-control" name="blog_articles_pagetitle" value="<?php echo $blog_articles_pagetitle; ?>" size="32">
          </div>
          <div>Article Catergory:</div>
          <div>
            <input name="blog_articles_catergory" type="text" disabled class="form-control" value="<?php echo $category_name; ?>" size="32" readonly>
          </div>
          <div>Add New Article Catergory:<br /><small>if you have multiple categories please seperate them using a comma e.g. category,category one, category two e.t.c</small></div>
          <div>
            <input type="text" class="form-control" name="blog_category_name" value="" size="32">
          </div>
          <div>Article Status:</div>
          <div>
            <select class="form-control"  name="blog_articles_level" >
              <option value='Approved' <?php if ($blog_articles_level == 'Approved') {echo "selected='selected'";} ?>>Approved</option>
              <option value='Not Approved' <?php if ($blog_articles_level == 'Not Approved') {echo "selected='selected'";} ?>>Not Approved</option>
              <option value='Yet to be Administered' <?php if ($blog_articles_level == 'Yet to be Administered') {echo "selected='selected'";} ?>>Yet to be Administered</option>
            </select>
          </div>
          <div>A Shortdescription of your Article:</div>
          <div>
            <textarea  class="form-control"  name="blog_articles_shortdesc" cols="70" rows="10"><?php echo $blog_articles_shortdesc; ?></textarea>
          </div>
          <div>Article:</div>
          <div>
            <textarea  class="form-control"  name="blog_articles_description" cols="70" rows="50"><?php echo $blog_articles_description; ?></textarea>
          </div>
          <div>
            <input type="submit" class="btn btn-primary" value="Edit Article">
          </div>
          <input type="hidden" name="blog_category_id" value="<?php echo $blog_category_id; ?>">
          <input type="hidden" name="blog_articles_id" value="<?php echo $blog_articles_id; ?>">
          <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>">
          <input type="hidden" name="MM_update" value="form1">
        </form>
        <!-- end col-md-8 well--></div>
      <!-- end right-->
      
      <div class="clearfix"> </div>
    </div>
  </div>
</section>
