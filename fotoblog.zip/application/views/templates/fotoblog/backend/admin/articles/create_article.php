<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>


<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>
   <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">

<form action="<?php echo $base_url; ?>admin/articles/create" method="post" name="form1" id="form1">
  <table align="center" class="tablecontent1">
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Blog Name:</td>
      <td>
      <select class="form-control"  name="blog_id" >
		  <?php foreach ($blog_content as $k=>$v){ ?>
                    <option value='<?php echo $v['blog_id']; ?>'><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></option>
          <?php } ?>
      </select>      
      </td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Article Title:</td>
      <td><input type="text" class="form-control" name="article_title" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="middle">Article Shortdescription:</td>
      <td><textarea  class="form-control"  name="article_shortdescription" cols="70" rows="10"></textarea>      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="middle">Article Description:</td>
      <td><textarea  class="form-control"  name="article_description" cols="70" rows="70"></textarea>      </td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Article Catergory:</td>
      <td>
      <select class="form-control"  name="article_catergory" >
      <?php foreach ($categories as $k=>$v){ ?>
      			<option value='<?php echo $v['blog_category_id']; ?>'><?php echo $v['blog_category_name']; ?></option>
      <?php } ?>
      </select>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="middle">Article Tags: To enter multiple tags seperate each tag with a comma
      <p>&nbsp;</p></td>
      <td align="left" valign="top"><input name="article_tags" type="text" value="" class="form-control"  size="90" /></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">&nbsp;</td>
      <td><input type="submit" value="Insert record" class="btn btn-default" /></td>
    </tr>
  </table>
  <input type="hidden" name="article_id" value="" />
  <input type="hidden" name="article_pubdate" value="" />
  <input type="hidden" name="article_insert" value="form1" />
</form>

</div>
