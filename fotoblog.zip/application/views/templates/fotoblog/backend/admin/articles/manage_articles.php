<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Articles  <span class="divider">/</span></li>
      <li class="active">Manage Articles  </li>
    </ul>
  </div>
   <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">
    <div class="row">
      <div class="col-md-7 well">
        <div align="center"><strong><?php echo $success; ?></strong></div>
        <div class="table-responsive">
          <?php if (count($all_articles) > 0){ ?>
          <table class="table table-striped">
            <tr>
              <td><div align="center" style="font-weight: bold">Author</div></td>
              <td><div align="center" style="font-weight: bold">Title</div></td>
              <td>Featured Image</td>
              <td><div align="center" style="font-weight: bold">Article Status</div></td>
              <td><div align="center" style="font-weight: bold">Published Date</div></td>
              <td colspan="2"><div align="center" style="font-weight: bold">Actions</div></td>
            </tr>
            <?php foreach ($all_articles as $row_Articles){ ?>
            <tr >
              <td><?php echo $row_Articles['blog_fname']; ?> <?php echo $row_Articles['blog_lname']; ?></td>
              <td><?php echo $row_Articles['blog_articles_pagetitle']; ?></td>
              <td>
                <?php if ($row_Articles['blog_articles_image']){ ?>
                <a href="<?php echo $this->config->item('base_url'); ?>featured/index/<?php echo $row_Articles['blog_articles_id']; ?>"> <img src="<?php echo $this->config->item('base_url'); ?>assets/images/articles/<?php echo $row_Articles['blog_articles_image']; ?>" alt="Upload a Featured Image" title="Upload a Featured Image" alt="Upload a Featured Image" width="50" height="50" /> </a>
                <?php }else{ ?>
                <div class="btn btn-default btn-xs"> <a href="<?php echo $this->config->item('base_url'); ?>featured/index/<?php echo $row_Articles['blog_articles_id']; ?>">Upload Featured Image</a></div>
                <?php } ?>
                </a></td>
              <td><?php echo $row_Articles['blog_articles_level']; ?></td>
              <td><?php echo $row_Articles['blog_article_date']; ?></td>
              <td></td>
              <td>
              <a href="<?php echo $base_url; ?>admin/articles/edit/<?php echo $row_Articles['blog_articles_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Edit <?php echo $row_Articles['blog_articles_pagetitle']; ?>" ><span class="glyphicon glyphicon-edit"></a></span></div>
              <a href="<?php echo $base_url; ?>admin/articles/delete/<?php echo $row_Articles['blog_articles_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Delete <?php echo $row_Articles['blog_articles_pagetitle']; ?>" onclick="return confirm('Are you sure you want to delete?')"><span class="glyphicon glyphicon-remove-sign"></a></span></div></td>
              </td>
            </tr>
            <?php }  ?>
          </table>
          <?php }else{ ?>
              <p>There are no articles</p>
          <?php }  ?>
        </div>
      </div>
      <!-- start right-->
      <div class="col-md-4 well pull-right">
        <h4><strong>Create Article </strong></h4>
        <form action="<?php echo $base_url; ?>admin/articles/create" method="post" name="form1" id="form1">
          <div>Blog Name:</div>
          <div>
            <select class="form-control"  name="blog_id" >
              <option value='<?php echo $this->session->userdata('blog_id'); ?>'><?php echo $this->session->userdata('blog_fname'); ?> <?php echo $this->session->userdata('blog_lname'); ?></option>
            </select>
          </div>
          <div>Article Title:</div>
          <div>
            <input type="text" class="form-control" name="article_title" value="" size="32" />
          </div>
          <div>Article Shortdescription:</div>
          <div>
            <textarea  class="form-control"  name="article_shortdescription" cols="70" rows="10"></textarea>
          </div>
          <div>
          Article Description:
          </td>
          <div>
            <textarea  class="form-control"  name="article_description" cols="70" rows="70"></textarea>
          </div>
          <div>
          Article Catergory:
          </td>
          <div>
            <select class="form-control"  name="article_catergory" >
              <?php foreach ($categories as $k=>$v){ ?>
              <option value='<?php echo $v['blog_category_id']; ?>'><?php echo $v['blog_category_name']; ?></option>
              <?php } ?>
            </select>
          </div>
          <div>Article Tags: To enter multiple tags seperate each tag with a comma
            <p>&nbsp;</p>
          </div>
          <div>
            <input name="article_tags" type="text" value="" class="form-control"  size="90" />
          </div>
          <div>
            <input type="submit" value="Add Article" class="btn btn-primary" />
          </div>
          <input type="hidden" name="article_id" value="" />
          <input type="hidden" name="article_pubdate" value="" />
          <input type="hidden" name="article_insert" value="form1" />
        </form>
        <!-- end col-md-8 well--></div>
      <!-- end right-->
      
      <div class="clearfix"> </div>
    </div>
  </div>
</section>
