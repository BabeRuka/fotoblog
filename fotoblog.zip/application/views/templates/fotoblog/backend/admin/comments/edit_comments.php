<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
foreach ($comments as $k=>$v){
		$blog_comment_id= $v['blog_comment_id'];
		$blog_articles_id = $v['blog_articles_id'];
		$blog_id = $v['blog_id'];
		$blog_comment_date = $v['blog_comment_date'];
		$blog_comment_name = $v['blog_comment_name'];
		$blog_comment_email = $v['blog_comment_email'];
		$blog_comment_comment = $v['blog_comment_comment']; 
		$blog_comment_status = $v['blog_comment_status']; 

}
?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Comments <span class="divider">/</span></li>
      <li class="active">Manage Comments </li>
    </ul>
  </div>
     <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">
    <div class="row">
      <div class="col-md-7 well">
        <div align="center"><strong><?php echo $success; ?></strong></div>
        <div class="table-responsive">
          <table class="table table-striped">
            <tr >
              <td><div align="center" style="font-weight: bold">Comment</div></td>
              <td><div align="center" style="font-weight: bold">Status</div></td>
              <td><span style="font-weight: bold">Actions</span></td>
            </tr>
            <?php foreach($all_comments as $comment) { ?>
            <tr >
              <td><?php echo $comment['blog_comment_comment']; ?><br />
                <strong>Posted on <?php echo  $comment['blog_comment_date']; ?> by <?php echo $comment['blog_comment_name']; ?></strong></td>
              <td><?php echo  $comment['blog_comment_status']; ?></td>
              <td>
                <a href="<?php echo $base_url.'admin/comments/edit/'.$comment['blog_comment_id'].''; ?>" data-toggle="tooltip" data-placement="bottom" title=" Manage <?php echo $comment['blog_comment_name']; ?>"><span class="glyphicon glyphicon-cog"></a>
              <a href="<?php echo $base_url; ?>admin/comments/delete/<?php echo $comment['blog_comment_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Delete <?php echo $comment['blog_comment_name']; ?>"  onclick="return confirm('Are you sure you want to delete?')"  ><span class="glyphicon glyphicon-remove-sign"></a></span></a></td>
            </tr>
            <?php } ?>
          </table>
        </div>
      </div>
      <!-- start right-->
      <div class="col-md-4 well pull-right">
        <h4><strong>Manage Comment</strong></h4>
        <form action="" method="post" name="form1" id="form1">
          <div>Name of Article Page:</div>
          <div>
            <textarea name="blog_articles_page" disabled="disabled" readonly class="form-control" type="text">  <?php echo $blog_comment_comment; ?></textarea>
          </div>
          <div>Comment Status:<br />
            <span style="font-size: x-small; font-weight: bold; font-style: italic">If you approve of the comment then choose<br />
            Addressed Otherwise Leave it on Pending</span></div>
          <div>
            <select class="form-control"  name="blog_comment_status">
              <option value="Addressed" <?php if ($blog_comment_status == "Addressed") { echo 'selected= "SELECTED"'; } ?>>Addressed</option>
              <option value="Being Addressed"  <?php if ($blog_comment_status == "Being Addressed") { echo 'selected= "SELECTED"'; } ?>>Being Addressed</option>
              <option value="Pending"  <?php if ($blog_comment_status == "Pending") { echo 'selected= "SELECTED"'; } ?>>Pending</option>
            </select>
          </div>
          <div>
            <input type="submit" value="Update record" class="btn btn-primary" />
          </div>
          <input type="hidden" name="update_comment" value="form1" />
          <input type="hidden" name="blog_comment_id" value="<?php echo $blog_comment_id; ?>" />
        </form>
        
        <!-- end col-md-8 well--></div>
      <!-- end right-->
      
      <div class="clearfix"> </div>
    </div>
  </div>
</section>
