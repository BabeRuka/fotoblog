<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home </a> <span class="divider">/</span></li>
      <li><a href="#">Slideshows </a> <span class="divider">/</span></li>
      <li class="active">Edit</li>
    </ul>
  </div>
     <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">
    <div class="row"> 
      <!--start left-->
      <div class="col-md-7 well">
        <?php if ( count($slideshows) > 0 ) { ?>
        <div class="table-responsive">
          <table class="table table-striped">
            <tr>
              <td><div align="center" style="font-weight: bold">
                  <div align="center">Slideshow Name</div>
                </div></td>
              <td>Slideshow Page</td>
              <td>Slideshow Status</td>
              <td><div align="center" style="font-weight: bold">
                  <div align="center">Featured Image</div>
                </div></td>
              <td><div align="center" style="font-weight: bold">
                  <div align="center">Actions</div>
                </div></td>
            </tr>
            <?php foreach($slideshows as $row) { ?>
            <tr>
              <td align="center" valign="middle"><?php echo $row['slide_name']; ?></td>
              <td align="center" valign="middle"><?php echo strtoupper($row['slide_type']); ?></td>
                <td align="center" valign="middle"><?php
					if ($row['slide_status'] == '1'){
						$slide_status = 'Active';
					}else{
						$slide_status = 'Not Active';
					}
					echo $slide_status; 
				 ?></td>
              <td align="center" valign="middle"><img class="img-thumbnail my-pic" src="<?php echo $this->config->item('base_url').'uploads/slideshows/'; echo $row['slide_image_tbn']; ?>" width="100" alt=""/></td>
              <td align="center" valign="middle"><a href="<?php echo $this->config->item('base_url').'admin/slideshow/'; echo $row['slide_pagename']; ?>/<?php echo $row['slide_id']; ?>"><span class="glyphicon glyphicon-plus-sign"></span></a> <a href="<?php echo $this->config->item('base_url').'admin/slideshow/edit/'; echo $row['slide_pagename']; ?>/<?php echo $row['slide_id']; ?>"><span class="glyphicon glyphicon-edit"></span></a> <a onclick="return confirm('Are you sure you want to delete?')" href="<?php echo $this->config->item('base_url').'admin/slideshow/delete/'; echo $row['slide_pagename']; ?>/<?php echo $row['slide_id']; ?>"><span class="glyphicon glyphicon-remove-sign"></span></a></td>
            </tr>
            <?php } ?>
          </table>
          <!--end--></div>
        <?php if ( $photos ){ ?>
        <div class="col-md-12 pull-left">
          <h4>Photos in <?php echo $slideshow_name; ?> Slideshow</h4>
          <div class="row margin-div">
            <div class="col-md-12">
              <?php if (count($photos) > 0) { foreach ($photos as $row){ ?>
              <!-- first row -->
              <div class="col-md-4"> <a href=""> <img class="img-thumbnail" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['slide_images_image_tbn']; ?>" title="View <?php echo ucwords($row['slide_name']); ?> <?php echo site_name; ?> Slideshow"   alt="<?php echo $row['slide_name']; ?>" width="200" height="133" /></a>
                <div class="btn btn-mini btn-default" type="button"> <a href="<?php echo $this->config->item('base_url').'admin/slideshow/edit/'; echo $row['slide_pagename']; ?>/<?php echo $row['slide_id']; ?>/<?php echo $row['slide_image_id']; ?>">Edit <span class="glyphicon glyphicon-plus-sign"></span></a> </div>
                <div class="btn btn-mini btn-default" type="button"> <a onclick="return confirm('Are you sure you want to delete?')" href="<?php echo $this->config->item('base_url').'admin/slideshow/delete/'; echo $row['slide_pagename']; ?>/<?php echo $row['slide_id']; ?>">Delete</a> </div>
                
                <!--end col-lg-12--></div>
              <?php } } ?>
              <!-- end first row -->
              <div class="clearfix"> </div>
              
              <!--end col-lg-12--></div>
            <!--end row--></div>
        </div>
        <?php } ?>
        <?php } else {  ?>
        <div class="span4">You havent created any Slideshow yet</div>
        <?php } ?>
      </div>
      <!--end left-->
      <div class="col-md-4 well pull-right">
        <?php
		foreach ($slideshow as $row){
			$slide_id = $row['slide_id'];
			$blog_id = $row['blog_id'];
			$slide_name = $row['slide_name'];
			$slide_pagename = $row['slide_pagename'];
			$slide_description = $row['slide_description'];
			$slide_image_tbn = $row['slide_image_tbn'];
			$slide_type = $row['slide_type']; 
			if ($row['slide_status'] == '1'){
				$slide_status = 'Active';
			}else{
				$slide_status = 'Not Active';
			}
		}	  
	  
	  ?>
        <?php if ($error){ echo $error; } ?>
        <?php if ($success){ echo $success; } ?>
        <?php echo form_open_multipart('upload/edit_slideshow');?>
        <h4>Edit <?php echo ucwords($slide_name);  ?> Slideshow</h4>
        <div class="margin-down-three"> <img class="img-thumbnail my-pic" src="<?php echo $this->config->item('base_url').'uploads/slideshows/'; echo $slide_image_tbn; ?>"  alt=""/> </div>
        <div class="margin-down-three">
          <h5>Slideshow Name</h5>
          <input type="text" class="form-control" name="gall" value="<?php echo $slide_name; ?>" />
        </div>
        <div class="margin-down-three">
          <h5>Slideshow Description</h5>
          <textarea rows="3"  class="form-control"  name="desc"><?php echo $slide_description; ?></textarea>
        </div>
        <div class="margin-down-three">
          <h5>Slideshow Page</h5>
          <?php if ($this->session->userdata('blog_catergory') == 'Super Administrator') {	?>
          <select name="slide_type" id="slide_type" required class="form-control">
            <option value="blog" <?php if ($slide_type == 'blog') { echo 'selected="selected" ';	} ?> ><?php echo strtoupper('Blog'); ?></option>
            <option value="homepage" <?php if ($slide_type == 'homepage') { echo 'selected="selected" ';	} ?> ><?php echo strtoupper('Homepage'); ?></option>
            <option value="gallery" <?php if ($slide_type == 'gallery') { echo 'selected="selected" ';	} ?> ><?php echo strtoupper('Gallery'); ?></option>
          </select>
          <?php }else {	?>
          <input name="slide_type" type="text" disabled class="form-control" value="<?php echo $slide_type; ?>" />
          <?php }	?>
        </div>
        <div class="margin-down-three">
          <h5>Slideshow Status</h5>
          <select name="slide_status" id="slide_status" required class="form-control">
            <option value="1" <?php if ($slide_status == 'Active') { echo 'selected="selected" ';	} ?> >Active</option>
            <option value="0" <?php if ($slide_status == 'Not Active') { echo 'selected="selected" ';	} ?> >Not Active</option>
          </select>
        </div>
        <div class="margin-down-three">
          <h5>Change Feature Photo</h5>
          <input name="userfile" type="file" size="20" />
        </div>
        <div class="margin-down-three">
          <input type="submit" class="btn btn-primary" value="Edit Slideshow" />
          <input type="hidden" name="edit_slideshow" value="Edit Slideshow" />
          <input type="hidden" name="slide_name" value="<?php echo $slide_pagename ; ?>" />
          <input type="hidden" name="slide_id" value="<?php echo $slide_id ; ?>" />
          <input type="hidden" name="blog_id" value="<?php echo $blog_id ; ?>" />
        </div>
        </form>
      </div>
      <?php if ($this->uri->segment(6)) { ?>
      <div class="col-md-4 well pull-right">
        <h4>Edit Photo</h4>
        <?php echo form_open_multipart('upload/photos');?>
        <?php
			foreach ($slideshow_images as $row) {
				$slide_images_image_tbn = $row['slide_images_image_tbn'];
				$slide_image_caption = $row['slide_image_caption'];
				$blog_tbn_desc = $row['blog_tbn_desc'];
				$slide_image_name = $row['slide_image_name'];
				$slide_image_id = $row['slide_image_id'];
			}
		?>
        <div> <img class="img-thumbnail my-pic" src="<?php echo $this->config->item('base_url').'uploads/'; echo $slide_images_image_tbn; ?>"  alt=""/> </div>
        <div>
          <h5>Slideshow Name</h5>
          <input name="photo_gall" type="text" class="form-control" value="<?php echo $slide_name; ?>" readonly />
        </div>
        <div>
          <h5>Photo Name</h5>
          <input type="text" class="form-control" name="photo_name"  value="<?php echo $slide_image_caption; ?>"  />
        </div>
        <div>
          <h5>Photo Description</h5>
          <textarea rows="2"  class="form-control"  name="photo_desc"> <?php echo $blog_tbn_desc; ?> </textarea>
        </div>
        <div style="margin-top:1%">
          <input type="submit" class="btn btn-primary" value="Add Photo" />
          <input type="hidden" name="edit_photo" value="<?php echo $slide_image_id; ?>" />
          <input type="hidden" name="gal_pagename" value="<?php echo $slide_pagename; ?>" />
          <input type="hidden" name="gal_id" value="<?php echo $slide_id ; ?>" />
        </div>
        </form>
      </div>
      <!--end left-->
      
      <?php } ?>
    </div>
    <!--end left--> 
    
    <!--end row--> </div>
  
  <!--end adm-container-->
  </div>
  <!--end section--></section>
