<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
   <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">
<div align="center"><strong><?php //echo $success; ?></strong></div> 

<form action="<?php echo $base_url; ?>admin/actions" method="post" name="form2" id="form2">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Name:</td>
      <td><input name="blog_fname" type="text" id="blog_fname" value="<?php echo htmlentities($row_Admin['blog_fname'], ENT_COMPAT, ''); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Password:</td>
      <td><input name="blog_password" type="password" id="blog_password" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Level:</td>
      <td><select class="form-control"  name="blog_level " id="blog_level">
          <option value="Website Admin" <?php if (!(strcmp("Website Admin", htmlentities($row_Admin['blog_level'], ENT_COMPAT, '')))) {echo "SELECTED";} ?>>Website Admin</option>          <option value="Website Admin" <?php if (!(strcmp("Website Admin", htmlentities($row_Admin['blog_level'], ENT_COMPAT, '')))) {echo "SELECTED";} ?>>Website Admin</option>
          <option value="Website User" <?php if (!(strcmp("Website User", htmlentities($row_Admin['blog_level'], ENT_COMPAT, '')))) {echo "SELECTED";} ?>>Website User</option>
          <option value="NA" <?php if (!(strcmp("NA", htmlentities($row_Admin['blog_level'], ENT_COMPAT, '')))) {echo "SELECTED";} ?>>NA</option>
        </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Update record"  class="btn btn-default" /></td>
    </tr>
  </table>
  <input type="hidden" name="id" value="<?php echo $row_Admin['blog_id']; ?>" />
  <input type="hidden" name="MM_update" value="form2" />
  <input type="hidden" name="id" value="<?php echo $row_Admin['blog_id']; ?>" />
</form>
<!--end-->
</div>
