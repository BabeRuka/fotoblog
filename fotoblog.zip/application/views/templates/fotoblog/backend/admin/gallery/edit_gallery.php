<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<section class="admin">
  <div class="admin-div">
   
<ul class="breadcrumb">
  <li><a href="#">Admin Home </a> <span class="divider">/</span></li>
  <li><a href="#">Galleries </a> <span class="divider">/</span></li>
  <li class="active">Edit</li>
</ul>   
   
  </div>
     <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">
    <div class="row"> 
      <!--start left-->
      <div class="col-md-7 well">
      
      <?php if ( count($galleries) > 0 ) { ?>
      
      
      <div class="table-responsive">
      <table class="table table-striped">
        <tr>
          <td><div align="center" style="font-weight: bold">
              <div align="center">Gallery Name</div>
            </div></td>
          <td><div align="center" style="font-weight: bold">
              <div align="center">Featured Image</div>
            </div></td>
          <td><div align="center" style="font-weight: bold">
              <div align="center">Actions</div>
            </div></td>
         
        </tr>
        <?php foreach($galleries as $row) { ?>
        <tr>
          <td align="center" valign="middle"><?php echo $row['blog_gal_name']; ?></td>
          <td align="center" valign="middle"><img class="img-thumbnail my-pic" src="<?php echo $this->config->item('base_url').'uploads/'; echo $row['blog_gal_image_tbn']; ?>" width="100" alt=""/> </td>
          <td align="center" valign="middle"> 
          <a href="<?php echo $this->config->item('base_url').'admin/galleries/'; echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>"><span class="glyphicon glyphicon-plus-sign"></span></a> 
          <a href="<?php echo $this->config->item('base_url').'admin/galleries/edit/'; echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>
          <a onclick="return confirm('Are you sure you want to delete?')" href="<?php echo $this->config->item('base_url').'admin/galleries/delete/'; echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>"><span class="glyphicon glyphicon-remove-sign"></span></a> 
          </td>
         </tr>
        <?php } ?>
      </table>
      <!--end--></div>
      
      <?php if ( $photos ){ ?>
      <div class="col-md-12 pull-left">
      	<h4>Photos in <?php echo $gallery_name; ?> Gallery</h4>
        <div class="row margin-div">
          <div class="col-md-12">
            <?php if (count($photos) > 0) { foreach ($photos as $row){ ?>
            <!-- first row -->
            <div class="col-md-4"> <a href=""> 
            <img class="img-thumbnail" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_tbn_image_tbn']; ?>" title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery"   alt="<?php echo $row['blog_gal_name']; ?>" width="200" height="133" /></a> 
            
             <div class="btn btn-mini btn-default" type="button">
             <a href="<?php echo $this->config->item('base_url').'admin/galleries/edit/'; echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>/<?php echo $row['blog_tbn_id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>
             </div>
             <div class="btn btn-mini btn-default" type="button">
             <a onclick="return confirm('Are you sure you want to delete?')" href="<?php echo $this->config->item('base_url').'admin/galleries/delete/'; echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>"><span class="glyphicon glyphicon-remove-sign"></span></a>
             </div>
            
              <!--end col-lg-12--></div>
            <?php } } ?>
            <!-- end first row -->
            <div class="clearfix"> </div>
            
            <!--end col-lg-12--></div>
          <!--end row--></div>
      </div>
	  <?php } ?>
      
      <?php } else {  ?>
      <div class="span4">You havent created any Gallery yet</div>
      <?php } ?>
      
      </div> <!--end left--> 
      <div class="col-md-4 well pull-right">
      <?php
		foreach ($gallery as $row){
			$blog_gal_id = $row['blog_gal_id'];
			$blog_id = $row['blog_id'];
			$blog_gal_name = $row['blog_gal_name'];
			$blog_gal_id = $row['blog_gal_id'];
			$blog_gal_pagename = $row['blog_gal_pagename'];
			$blog_gal_description = $row['blog_gal_description'];
			$blog_gal_image_tbn = $row['blog_gal_image_tbn'];
		}	  
	  
	  ?>

      <?php if ($error){ echo $error; } ?> 
      <?php if ($success){ echo $success; } ?>

	  <?php echo form_open_multipart('upload/edit_gallery');?>
      	<h4>Edit <?php echo ucwords($blog_gal_name);  ?> Gallery</h4>
        <div>
        <img class="img-thumbnail my-pic" src="<?php echo $this->config->item('base_url').'uploads/'; echo $blog_gal_image_tbn; ?>"  alt=""/>
        </div>
        <div>
        <h5>Gallery Name</h5>
        <input type="text" class="form-control" name="gall" value="<?php echo $blog_gal_name; ?>" />
        </div> 
        <div>
        <h5>Gallery Description</h5>
        <textarea rows="3"  class="form-control"  name="desc"><?php echo $blog_gal_description; ?></textarea>
        </div> 
        <div>
        <h5>Change Feature Photo</h5>
        <input name="userfile" type="file" required="required" size="20" /></div>
        <div style="margin-top:1%">
        <input type="submit" class="btn btn-primary" value="Edit Gallery" />
        <input type="hidden" name="edit_gallery" value="Edit Gallery" />
        <input type="hidden" name="blog_gal_id" value="<?php echo $blog_gal_id ; ?>" />
        </div>
        </form>
        </div>
        
        <?php if ($this->uri->segment(6)) { ?>
        <div class="col-md-4 well pull-right">
        <h4>Edit Photo</h4>
        <?php echo form_open_multipart('upload/photos');?>
        <?php
			foreach ($gallery_images as $row) {
				$blog_tbn_image_tbn = $row['blog_tbn_image_tbn'];
				$blog_tbn_caption = $row['blog_tbn_caption'];
				$blog_tbn_desc = $row['blog_tbn_desc'];
				$blog_tbn_name = $row['blog_tbn_name'];
				$blog_tbn_id = $row['blog_tbn_id'];
			}
		?>
        
        <div>
        <img class="img-thumbnail my-pic" src="<?php echo $this->config->item('base_url').'uploads/'; echo $blog_tbn_image_tbn; ?>"  alt=""/>
        </div>        
        
        <div>
          <h5>Gallery Name</h5>
          <input name="photo_gall" type="text" class="form-control" value="<?php echo $blog_gal_name; ?>" readonly />
        </div>
        <div>
          <h5>Photo Name</h5>
          <input type="text" class="form-control" name="photo_name"  value="<?php echo $blog_tbn_caption; ?>"  />
        </div>
        <div>
          <h5>Photo Description</h5>
          <textarea rows="2"  class="form-control"  name="photo_desc"> <?php echo $blog_tbn_desc; ?> </textarea>
        </div>

        <div style="margin-top:1%">
          <input type="submit" class="btn btn-primary" value="Add Photo" />
          <input type="hidden" name="edit_photo" value="<?php echo $blog_tbn_id; ?>" />
          <input type="hidden" name="gal_pagename" value="<?php echo $blog_gal_pagename; ?>" />
          <input type="hidden" name="gal_id" value="<?php echo $blog_gal_id ; ?>" />
        </div>
        </form>
        </div> <!--end left-->

		<?php } ?>
        
        
        
      </div> <!--end left--> 
      
    <!--end row--> </div>
    
    
    
    
    <!--end adm-container--></div>
  <!--end section--></section>
