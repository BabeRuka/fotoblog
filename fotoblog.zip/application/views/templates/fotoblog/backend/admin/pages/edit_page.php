<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
foreach ($page_details as $row){
	$blog_content_id = $row['blog_content_id'];
	$blog_id = $row['blog_id'];
	$blog_content_description = $row['blog_content_description'];
	$blog_content_page = $row['blog_content_page'];
	$blog_content_pagetitle = $row['blog_content_pagetitle'];
	$blog_content_date = $row['blog_content_date'];
	$blog_content_hits = $row['blog_content_hits'];
	$blog_content_type = $row['blog_content_type'];
	$blog_content_scope = $row['blog_content_scope'];
}
?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active"><?php echo $breadcrumb; ?> <span class="divider">/</span></li>
      <li class="active">Edit Page</li>
    </ul>
  </div>
     <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">
    <div class="row">
      <div class="col-md-7 well">
        <div align="center"><strong><?php echo $success; ?></strong></div>
        <div class="table-responsive">
          <table class="table table-striped">
            <tr>
              <td><div align="center" style="font-weight: bold">Title</div></td>
              <td><div align="center" style="font-weight: bold">Type</div></td>
              <td><div align="center" style="font-weight: bold">Views</div></td>
              <td><div align="center" style="font-weight: bold">Published Date</div></td>
              <td colspan="2"><div align="center" style="font-weight: bold">Actions</div></td>
            </tr>
            <?php foreach ($all_page_details as $row){ ?>
            <tr >
              <td><a href="#"><?php echo $row['blog_content_pagetitle']; ?></a></td>
              <td><a href="#"><?php echo ucwords($row['blog_content_type']); ?></a></td>
              <td><a href="#"><?php echo $row['blog_content_hits']; ?></a></td>
              <td><a href="#"><?php echo $row['blog_content_date']; ?></a></td>
              <td><a href="<?php echo $base_url; ?>admin/pages/edit/<?php echo $row['blog_content_id']; ?>/<?php echo $row['blog_id']; ?>"><span class="glyphicon glyphicon-edit"></span></td>
              <td><a href="<?php echo $base_url; ?>admin/pages/delete/<?php echo $row['blog_content_id']; ?>/<?php echo $row['blog_id']; ?>"onclick="return confirm('Are you sure you want to delete?')"><span class="glyphicon glyphicon-remove-sign"></span></a></td>
            </tr>
            <?php }  ?>
          </table>
        </div>
      </div>
      <!-- start right-->
      <div class="col-md-4 well pull-right">
        <h4><strong>Edit <?php echo $blog_content_pagetitle; ?></strong></h4>
        <form method="post" name="form1" action="<?php echo $base_url; ?>admin/pages/edit/<?php echo $this->uri->segment(4); ?>/<?php echo $this->uri->segment(5); ?>">
          <div>Page Owner</div>
          <div>
            <?php if ($this->session->userdata('blog_catergory')=='Super Administrator') { ?>
            <select name="blog_id" class="form-control"   >
              <option value='0' <?php if ($blog_id == '0') { ?>  selected="selected" <?php } ?> >Not Applicable</option>
              <?php foreach ($all_blogs as $k=>$v){ ?>
              <option value='<?php echo $v['blog_id']; ?>' <?php if ($blog_id == $v['blog_id']) { ?>  selected="selected" <?php } ?> ><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></option>
              <?php } ?>
            </select>
            <?php }else{ ?>
            <input name="blog_owner" type="text" value="<?php echo $this->session->userdata('blog_fname'); ?> <?php echo $this->session->userdata('blog_lname'); ?>"" readonly>
            <input type="hidden" name="blog_id" value="<?php echo $this->session->userdata('blog_id'); ?>">
            <?php } ?>
          </div>
          <div>Page Type</div>
          <div>
          <select name="blog_content_type" class="form-control"   >
            <option value='about' <?php if ($blog_content_type=='about') { ?>  selected="selected" <?php } ?>>About Page</option>
            <option value='contact' <?php if ($blog_content_type=='contact') { ?>  selected="selected" <?php } ?>>Contact Page</option>
            <option value='services' <?php if ($blog_content_type=='services') { ?>  selected="selected" <?php } ?>>Services Page</option>
            <option value='page' <?php if ($blog_content_type=='page') { ?>  selected="selected" <?php } ?> >Page</option>
            </select>
          </div>
          <div>Title:</div>
          <div>
            <input type="text" class="form-control" name="blog_content_pagetitle" value="<?php echo $blog_content_pagetitle; ?>" size="32">
          </div>
          <div>Details:</div>
          <div>
            <textarea  class="form-control"  name="blog_content_description" cols="70" rows="50"><?php echo $blog_content_description; ?></textarea>
          </div>
          <div>
            <input type="submit" class="btn btn-primary" value="Edit Page">
          </div>
          <input type="hidden" name="blog_content_id" value="<?php echo $blog_content_id; ?>">
          <input type="hidden" name="page_update" value="form1">
        </form>
        
        <!-- end col-md-8 well--></div>
      <!-- end right-->
      
      <div class="clearfix"> </div>
    </div>
  </div>
</section>
