<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active"><?php echo $breadcrumb; ?> <span class="divider">/</span></li>
      <li class="active">Manage <?php echo $breadcrumb; ?></li>
    </ul>
  </div>
  <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
  ?>
  <div class="adm-container">
    <div class="row">
      <div class="col-md-6 well">
        <div align="center"><strong><?php echo $success; ?></strong></div>
        <div class="table-responsive">
          <?php if (count($page_details) > 0){ ?>
          <table class="table table-striped">
            <tr>
              <td><div align="center" style="font-weight: bold">Title</div></td>
              <td><div align="center" style="font-weight: bold">Type</div></td>
              <td><div align="center" style="font-weight: bold">Views</div></td>
              <td><div align="center" style="font-weight: bold">Published Date</div></td>
              <td colspan="2"><div align="center" style="font-weight: bold">Actions</div></td>
            </tr>
            <?php foreach ($page_details as $row){ ?>
            <tr >
              <td><a href="#"><?php echo $row['blog_content_pagetitle']; ?></a></td>
              <td><a href="#"><?php echo ucwords($row['blog_content_type']); ?> Page</a></td>
              <td><a href="#"><?php echo $row['blog_content_hits']; ?></a></td>
              <td><a href="#"><?php echo $row['blog_content_date']; ?></a></td>
              <td><a href="<?php echo $base_url; ?>admin/pages/edit/<?php echo $row['blog_content_id']; ?>/<?php echo $row['blog_id']; ?>"><span class="glyphicon glyphicon-edit"></span></td>
              <td><a href="<?php echo $base_url; ?>admin/pages/delete/<?php echo $row['blog_content_id']; ?>/<?php echo $row['blog_id']; ?>"onclick="return confirm('Are you sure you want to delete?')"><span class="glyphicon glyphicon-remove-sign"></span></a></td>
            </tr>
            <?php }  ?>
          </table>
          <?php }else{ ?>
              <p>There are no articles</p>
          <?php }  ?>
        </div>
      </div>
      <!-- start right-->
      <div class="col-md-4 well pull-right">
        <h4><strong>Create Page</strong></h4>
        <form action="<?php echo $base_url; ?>admin/pages/create" method="post" name="form1" id="form1">
          <div>Page Owner:</div>
          <div>
            <select name="blog_id" class="form-control"   >
              <option value='0' selected="selected">Not Applicable</option>
              <?php foreach ($all_blogs as $k=>$v){ ?>
              <option value='<?php echo $v['blog_id']; ?>'><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></option>
              <?php } ?>
            </select>
          </div>
          <div>Page Type:</div>
          <div>
            <select name="blog_content_type" class="form-control"   >
              <option value='about'>About Page</option>
              <option value='contact'>Contact Page</option>
              <option value='services'>Services Page</option>
              <option value='page' selected="selected">Page</option>
            </select>
          </div>
          <div>Title:</div>
          <div>
            <input type="text" class="form-control" name="blog_content_pagetitle" value="" size="32" />
          </div>
          <div>Page Details:</div>
          <div>
            <textarea  class="form-control"  name="blog_content_description" class="form-control" cols="70" rows="70">
            </textarea>
          </div>
          <div>&nbsp;</div>
          <div>
            <input type="submit" value="Add Page" class="btn btn-primary" />
          </div>
          <input type="hidden" name="blog_content_id" value="" />
          <input type="hidden" name="blog_content_date" value="" />
          <input type="hidden" name="page_insert" value="form1" />
        </form>
        
        <!-- end col-md-8 well--></div>
      <!-- end right-->
      
      <div class="clearfix"> </div>
    </div>
  </div>
</section>