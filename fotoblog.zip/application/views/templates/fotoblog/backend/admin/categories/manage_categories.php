<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Categories <span class="divider">/</span></li>
      <li class="active">Manage Categories </li>
    </ul>
  </div>
  <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
  <div class="adm-container">
    <div class="row">
      <div class="col-md-7 well">
        <div align="center"><strong><?php echo $success; ?></strong></div>
        <div class="table-responsive">
          <table class="table table-striped">
            <tr>
              <td align="center" valign="middle"><div align="center" style="font-weight: bold">Author</div></td>
              <td align="center" valign="middle"><div align="center" style="font-weight: bold">Category Name</div></td>
              <td colspan="2" align="center" valign="middle"><div align="center" style="font-weight: bold">Settings</div></td>
            </tr>
            <?php foreach ($all_categories as $row_Categories){ ?>
            <tr >
              <td align="center" valign="middle"><a href="#"><?php echo $row_Categories['blog_fname']; ?> <?php echo $row_Categories['blog_lname']; ?></a></td>
              <td align="center" valign="middle"><a href="#"><?php echo $row_Categories['blog_category_name']; ?></a></td>
              <td align="center" valign="middle">
              <span style="font-weight: bold"><a href="<?php echo $base_url; ?>admin/categories/edit/<?php echo $row_Categories['blog_category_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Edit <?php echo $row_Categories['blog_category_name']; ?>"><span class="glyphicon glyphicon-edit"></a></span>
              <span style="font-weight: bold"><a href="<?php echo $base_url; ?>admin/categories/delete/<?php echo $row_Categories['blog_category_id']; ?>/" data-toggle="tooltip" data-placement="bottom" title="Delete <?php echo $row_Categories['blog_category_name']; ?>" onclick="return confirm('Are you sure you want to delete?')"><span class="glyphicon glyphicon-remove-sign"></a></span></td>
            </tr>
            <?php }  ?>
          </table>
        </div>
      </div>
      <!-- start right-->
     <div class="col-md-4 well pull-right">
        <h4><strong>Manage Categories </strong></h4>
        <form action="<?php echo $base_url; ?>admin/categories/create" method="post" name="form1" id="form1">
          <table align="center" class="tablecontent1">
            <tr valign="baseline">
              <td align="right" valign="middle" nowrap="nowrap">Blog Name:</td>
              <td><select class="form-control"  name="blog_id" >
                  <option value='<?php echo $this->session->userdata('blog_id'); ?>'><?php echo $this->session->userdata('blog_fname'); ?> <?php echo $this->session->userdata('blog_lname'); ?></option>
                </select></td>
            </tr>
            <tr valign="baseline">
              <td align="right" valign="middle" nowrap="nowrap">Category Name:</td>
              <td><input type="text" class="form-control" name="blog_category_name" value="" size="32" /></td>
            </tr>
            <tr valign="baseline">
              <td align="right" valign="middle" nowrap="nowrap">&nbsp;</td>
              <td><input type="submit" value="Add Category" class="btn btn-primary" /></td>
            </tr>
          </table>
          <input type="hidden" name="blog_category_id" value="" />
          <input type="hidden" name="category_creation" value="" />
          <input type="hidden" name="MM_insert" value="form1" />
        </form>
        
        <!-- end col-md-8 well--></div>
      <!-- end right-->
      
      <div class="clearfix"> </div>
    </div>
  </div>
</section>
