<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
foreach ($admin_details as $k=>$v){
		$blog_id= $v['blog_id'];
		$blog_description= $v['blog_description'];
		$blog_page= $v['blog_page'];
		$blog_pagetitle= $v['blog_pagetitle'];
		$blog_username= $v['blog_username'];
		$blog_password= $v['blog_password'];
		$blog_fname= $v['blog_fname'];
		$blog_lname= $v['blog_lname'];
		$blog_email= $v['blog_email'];
		$blog_level= $v['blog_level'];
		$blog_catergory= $v['blog_catergory'];
}
?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Users <span class="divider">/</span></li>
      <li class="active">Edit <?php echo $blog_fname; ?> <?php echo $blog_lname; ?>'s Profile </li>
    </ul>
  </div>
    <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">
    <div class="row">
      <div class="col-md-8 well">
        <div>
          <form action="<?php echo $base_url; ?>admin/blogs/edit/<?php echo $blog_id; ?>" method="post" name="form2" id="form2">
            <div>Blog Page:</div>
            <div>
              <input name="blog_page" type="text" disabled class="form-control" value="<?php echo $blog_page; ?>" size="32" />
            </div>
            <div>Blog Pagetitle:</div>
            <div>
              <input type="text" class="form-control" name="blog_pagetitle" value="<?php echo $blog_pagetitle; ?>" size="32" />
            </div>
            <div>Blog Username:</div>
            <div>
              <input type="text" class="form-control" name="blog_username" value="<?php echo $blog_username; ?>" size="32" />
            </div>
            <div>First Name:</div>
            <div>
              <input type="text" class="form-control" name="blog_fname" value="<?php echo $blog_fname; ?>" size="32" />
            </div>
            <div>Last Name:</div>
            <div>
              <input type="text" class="form-control" name="blog_lname" value="<?php echo $blog_lname; ?>" size="32" />
            </div>
            <div>Email Address:</div>
            <div>
              <input type="text" class="form-control" name="blog_email" value="<?php echo $blog_email; ?>" size="32" />
            </div>
            <div>A Description of your Blog:</div>
            <div>
              <textarea  class="form-control"  name="blog_description" cols="50" rows="5"><?php echo $blog_description; ?></textarea>
            </div>
            <div>
              <input type="submit" class="btn btn-primary" value="Edit Blog" />
            </div>
            <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>" />
            <input type="hidden" name="blog_update" value="form1" />
          </form>
          </form>
          <!--end--> 
        </div>
      </div>
      <!-- start right-->
      <div class="col-md-3 pull-right">
        <div class="col-md-12 well">
          <h4><strong> Change Profile Picture</strong></h4>
          <div>
          <?php 
		  foreach($my_profile as $row_Blog) { 
		  	 $profile_pic = $row_Blog['blog_profile_pic'];
		  }
		  if($profile_pic){ ?>
            <div id="blog_profile_pic"> <img src="<?php echo $this->config->item('base_url'); ?>assets/images/<?php echo $profile_pic; ?>" alt="Upload a Profile Picture" class="img-responsive my-pic"  /> </div>
            <?php }else{?>
            <div><img src="<?php echo $this->config->item('base_url'); ?>assets/images/avatar.png" alt="Upload a Profile Picture" class="img-responsive"  /></div>
            <?php } ?>
          </div>
          <div>
            <?php if ($success){ ?>
            <div><strong><?php echo $success;?></strong></div>
            <?php } ?>
            <?php echo $error;?>
            <div>
              <form action="<?php echo $this->config->item('base_url'); ?>profile/do_upload" method="post" enctype="multipart/form-data">
                <div>Select a Blog User:</div>
                <div>
                  <?php if($this->session->userdata('blog_catergory') == 'Super Administrator'){ ?>
                  <select name="blog_id" id="blog_id" required class="form-control"   >
                    <?php foreach ($my_blog as $k=>$v){ ?>
                    <option value='<?php echo $v['blog_id']; ?>'><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></option>
                    <?php } ?>
                  </select>
                  <?php }else{ ?>
                  <input type="hidden" name="blog_id" required="required" value="<?php echo $this->session->userdata('blog_id'); ?>" id="userfile">
                  <?php } ?>
                </div>
                <div>Select a profile Picture to upload:</div>
                <div>
                  <input type="file" name="userfile" required="required" id="userfile">
                </div>
                <div>
                  <input type="submit" value="Upload Profile Picture" class="btn btn-primary" name="submit">
                </div>
              </form>
            </div>
            <!--end--></div>
        </div>
        
        <!--end--></div>
    </div>
    <!-- end col-md-8 well--></div>
  <!-- end right-->
  
  <div class="clearfix"> </div>
  </div>
  </div>
</section>
