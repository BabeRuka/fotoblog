<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>
   <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">
<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Settings </li>
    </ul>
  </div>
  <div class="adm-container">
    <div class="row">
      <div class="col-md-7">
<div class="leftcontent" style="width:98%;">
<?php //echo validation_errors(); ?>
<div align="center"><strong>Please Fill in Your Personal Details Below:</strong></div>
<?php echo form_open(''.$url.'register/index'); ?>

<h5>Username</h5>
<?php echo form_error('blog_username'); ?>
<input type="text" class="form-control" name="blog_username" value="<?php echo set_value('blog_username'); ?>" size="50" />

<h5>Password</h5>
<?php echo form_error('blog_password'); ?>
<input type="password" name="blog_password" value="<?php echo set_value('blog_password'); ?>" size="50" />

<h5>Password Confirm</h5>
<?php echo form_error('blog_password_confirm'); ?>
<input type="password" name="blog_password_confirm" value="<?php echo set_value('blog_password_confirm'); ?>" size="50" />

<h5>First Name</h5>
<?php echo form_error('blog_fname'); ?>
<input type="text" class="form-control" name="blog_fname" value="<?php echo set_value('blog_fname'); ?>" size="50" />

<h5>Last Name</h5>
<?php echo form_error('blog_lname'); ?>
<input type="text" class="form-control" name="blog_lname" value="<?php echo set_value('blog_lname'); ?>" size="50" />

<h5>Email Address</h5>
<?php echo form_error('blog_email'); ?>
<input type="text" class="form-control" name="blog_email" value="<?php echo set_value('blog_email'); ?>" size="50" />

<h5>The Name of Your Page</h5>
<?php echo form_error('blog_pagetitle'); ?>
<input type="text" class="form-control" name="blog_pagetitle" value="<?php echo set_value('blog_pagetitle'); ?>" size="50" />

<h5>A Short Description of Your Blog</h5>
<?php echo form_error('blog_description'); ?>
<textarea  class="form-control"  name="blog_description" rows="10" value="<?php echo set_value('blog_description'); ?>" ></textarea>


<div><input type="submit" value="Submit" class="btn btn-primary" /></div>

<input type="hidden" name="blog_id" value="" />
<input type="hidden" name="registered_from" value="admin" />
<input type="hidden" name="blog_level" value="Yet to be Administered" />
<input type="hidden" name="blog_activicationkey" value="<?php echo $activationKey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand(); ?>" />

</form>
</div>

</div>
