<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
if ($this->session->userdata('created')){
	echo '<h1>The user was created. Please Create another user below</h1>';
}else{
?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home </a> <span class="divider">/</span></li>
      <li class="active">Users <span class="divider">/</span></li>
      <li class="active">Create user</li>
    </ul>
  </div>
  <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
  <div class="adm-container">
    <div class="row">
      <div class="col-md-7 well">
        <?php //echo validation_errors(); ?>
        <div align="text-left"><strong>Please Fill in Your Personal Details Below:</strong></div>
        <form action="<?php echo $base_url; ?>admin/blogs/create" method="post" name="register" id="register">
          <h5>Username</h5>
          <?php echo form_error('blog_username'); ?>
          <input name="blog_username" type="text" required class="form-control" value="<?php echo set_value('blog_username'); ?>" size="50" />
          <h5>Password</h5>
          <?php echo form_error('blog_password'); ?>
          <input name="blog_password" type="password" class="form-control" required value="<?php echo set_value('blog_password'); ?>" size="50" />
          <h5>Password Confirm</h5>
          <?php echo form_error('blog_password_confirm'); ?>
          <input name="blog_password_confirm" type="password" class="form-control" required value="<?php echo set_value('blog_password_confirm'); ?>" size="50" />
          <h5>First Name</h5>
          <?php echo form_error('blog_fname'); ?>
          <input name="blog_fname" type="text" required class="form-control" value="<?php echo set_value('blog_fname'); ?>" size="50" />
          <h5>Last Name</h5>
          <?php echo form_error('blog_lname'); ?>
          <input name="blog_lname" type="text" required class="form-control" value="<?php echo set_value('blog_lname'); ?>" size="50" />
          <h5>Email Address</h5>
          <?php echo form_error('blog_email'); ?>
          <input name="blog_email" type="text" required class="form-control" value="<?php echo set_value('blog_email'); ?>" size="50" />
          <h5>The Name of Your Page</h5>
          <?php echo form_error('blog_pagetitle'); ?>
          <input name="blog_pagetitle" type="text" required class="form-control" value="<?php echo set_value('blog_pagetitle'); ?>" size="50" />
          <h5>A Short Description of Your Blog</h5>
          <?php echo form_error('blog_description'); ?>
          <textarea  name="blog_description" rows="10"  class="form-control" value="<?php echo set_value('blog_description'); ?>" ></textarea>
          <div>
            <input type="submit" value="Submit" class="btn btn-primary" />
          </div>
          <input type="hidden" name="blog_id" value="" />
          <input type="hidden" name="registered_from" value="admin" />
          <input type="hidden" name="blog_level" value="Yet to be Administered" />
          <input type="hidden" name="blog_activicationkey" value="<?php echo $activationKey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand(); ?>" />
        </form>
        <?php } ?>
      </div>
      
      <!----> 
      
      <!--end--></div>
  </div>
  <!-- end col-md-8 well-->
  </div>
  <!-- end right-->
  
  <div class="clearfix"> </div>
  </div>
  </div>
</section>
