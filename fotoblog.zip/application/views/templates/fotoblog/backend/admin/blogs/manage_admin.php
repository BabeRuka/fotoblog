<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
foreach ($admin_details as $k=>$v){
	$blog_fname = $v['blog_fname'];
	$blog_lname = $v['blog_lname'];
	$blog_level = $v['blog_level'];
	$blog_id = $v['blog_id'];
	$blog_catergory = $v['blog_catergory'];
}
?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home </a> <span class="divider">/</span></li>
      <li class="active">Users <span class="divider">/</span></li>
      <li class="active">Manage <?php echo $blog_fname; ?> <?php echo $blog_lname; ?>'s Profile </li>
    </ul>
  </div>
     <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
 <div class="adm-container">
    <div class="row"> 
      <!--start left-->
      <div class="col-md-7">
        <div class="col-md-12 well">
          <form action="<?php echo $base_url; ?>admin/blogs/manage/<?php echo $blog_id; ?>" method="post" name="form2" id="form2">
            <div>Name:</div>
            <div>
              <input name="username" class="form-control" type="readonly" id="username" value="<?php echo $blog_fname; echo ' '; echo $blog_lname; ?>" size="32" />
            </div>
            <div>Blog Visibility:</div>
            <div>
              <select class="form-control"  name="blog_level" id="blog_level">
                <option value='Approved' <?php if ($blog_level == 'Approved') {echo 'selected="selected"';} ?>>Approved</option>
                <option value='Not Approved' <?php if ($blog_level == 'Not Approved') {echo 'selected="selected"';} ?>>Not Approved</option>
                <option value='Yet to be Administered' <?php if ($blog_level == 'Yet to be Administered') {echo 'selected="selected"';} ?>>Yet to be Administered</option>
              </select>
            </div>
            <div>Blog Role:</div>
            <div>
              <select class="form-control"  name="blog_catergory" id="blog_catergory">
                <option value='Administrators' <?php if ($blog_catergory == 'Administrators') {echo 'selected="selected"';} ?>>Administrators</option>
                <option value='Associate' <?php if ($blog_catergory == 'Associate') {echo 'selected="selected"';} ?>>Associate</option>
                <option value='Lawyers' <?php if ($blog_catergory == 'Lawyers') {echo 'selected="selected"';} ?>>Lawyers</option>
                <option value='Partner' <?php if ($blog_catergory == 'Partner') {echo 'selected="selected"';} ?>>Partner</option>
                <option value='Staff' <?php if ($blog_catergory == 'Staff') {echo 'selected="selected"';} ?>>Staff</option>
                <option value='Super Administrator' <?php if ($blog_catergory == 'Super Administrator') {echo 'selected="selected"';} ?>>Super Administrator</option>
                <option value='User' <?php if ($blog_catergory == 'User') {echo 'selected="selected"';} ?>>User</option>
              </select>
            </div>
            <div>&nbsp;</div>
            <div>
              <input type="submit" value="Edit User" class="btn btn-primary" />
            </div>
            <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>" />
            <input type="hidden" name="blog_update" value="form2" />
          </form>
          <!--end--> 
        </div>
        
        <!-- start right-->
        <?php /*?><div class="col-md-4 pull-right">
        <div class="col-md-12 well">
          <h4><strong> Add a Watermark Image</strong></h4>
          <div>
          
          </div>
          <!--end--></div>
      </div><?php */?>
        
        <!----> 
        
        <!--end--></div>
    </div>
    <!-- end col-md-8 well--> 
  </div>
  <!-- end right-->
  
  <div class="clearfix"> </div>
  </div>
  </div>
</section>
