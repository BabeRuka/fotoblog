<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<section>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <?php foreach ($galleries as $row){ ?>
        <!-- first row -->
        <div class="col-md-2 pull-left"> <a href="<?php echo $this->config->item('base_url'); ?>gallery/browse/<?php echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>"><img src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_gal_image_tbn']; ?>" title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery"   alt="<?php echo $row['blog_gal_name']; ?>"/></a> 
          <!--end col-lg-12--></div>
        <?php } ?>
        
        <!-- end first row -->
        <div class="clearfix"> </div>
        
        <!--end col-lg-12--></div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>
