<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<footer class="text-center well">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <p>Copyright &copy; <?php echo site_name; ?>. All rights reserved.</p>
      </div>
    </div>
  </div>
</footer>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="<?php echo $this->config->item('base_url'); ?>assets/js/jquery-1.11.3.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo $this->config->item('base_url'); ?>assets/js/bootstrap.js"></script>
<script type="application/javascript">
	$(document).ready(function(){
		 var url = window.location.href;
        $('.nav a[href="'+url+'"]').parent().addClass('active');
		
		$('[data-toggle="tooltip"]').tooltip(); 
	});

$( "#blog_id" ).change(function() {
	var blog_id = $("#blog_id").val();
	
	var request = $.ajax({
	  url: "<?php echo $this->config->item('base_url'); ?>ajax/get_blog_part",
	  method: "POST",
	  data: { blog_id : blog_id, part : "blog_profile_pic" },
	  dataType: "html"
	});
	request.done(function( msg ) {
	  $('#blog_profile_pic').html('<img src="<?php echo $this->config->item('base_url'); ?>assets/images/'+ msg +'" alt="Upload a Profile Picture" class="img-responsive my-pic img-thumbnail" />'); 
	})

	
});
</script>
</body></html>