<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$url = $this->config->item('base_url');
?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Profiles <span class="divider">/</span></li>
      <li class="active">Change Password </li>
    </ul>
  </div>
  <div class="adm-container">
    <div class="row">
      <div class="col-md-4 well">
        <div align="center"><strong><?php echo $success; ?></strong></div>
        <?php echo form_open(''.$url.'admin/password/change'); ?>
        <div>
          <h5>Password</h5>
          <?php echo form_error('password'); ?>
          <input name="password" type="password" id="password" required  class="form-control"  value="<?php echo set_value('password'); ?>" size="50" />
        </div>
        <div>
          <h5>Repeat Password</h5>
          <?php //echo $email_error; ?>
          <?php echo form_error('repeat_password'); ?>
          <input type="password" name="repeat_password" id="repeat_password" class="form-control"  value="<?php echo set_value('password'); ?>" size="50" />
          <input type="hidden" name="blog_id" value="<?php echo $this->session->userdata['blog_id'];  ?>" size="50" />
        </div>
        <div>
          <input type="submit" value="Submit" class="btn btn-primary" />
        </div>
        </form>
      </div>
    </div>
    
    <!--end--></div>
  </div>
  <!-- end col-md-8 well-->
  </div>
  <!-- end right-->
  
  <div class="clearfix"> </div>
  </div>
  </div>
</section>
