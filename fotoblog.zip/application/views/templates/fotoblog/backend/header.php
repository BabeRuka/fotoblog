<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="PhotoBlog is responsive Photo Bloging Template Powered by PHP and MySQL." />
<meta name="keywords" content="PhotoBlog, Solomon Bareebe" />
<meta name="author" content="Solomon Bareebe" />
<title><?php echo $title; ?></title>
<!-- Bootstrap -->
<link rel="stylesheet" href="<?php echo $this->config->item('base_url'); ?>assets/css/bootstrap.css">
<link rel="stylesheet" href="<?php echo $this->config->item('base_url'); ?>assets/css/style.css">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script src='<?php echo $this->config->item('base_url'); ?>assets/admin/tinymce/js/tinymce.min.js'></script>
<script type="text/javascript">
tinymce.init({
  selector: 'textarea',
  height: 500,
  plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table contextmenu paste code'
  ],
  toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
  content_css: [
    '//fast.fonts.net/cssapi/e6dc9b99-64fe-4292-ad98-6974f93cd2a2.css',
    '//www.tinymce.com/css/codepen.min.css'
  ]
});
</script>
<!-- /TinyMCE -->
<style>
.form-control {
	margin-top: 1%;
	margin-bottom: 1%;
}
.btn {
	margin-top: 1%;
	margin-bottom: 1%;
}
</style>
</head>
