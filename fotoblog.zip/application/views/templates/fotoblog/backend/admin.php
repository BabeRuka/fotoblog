<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Users <span class="divider">/</span></li>
      <li class="active">Manage Users </li>
    </ul>
  </div>
  <?php if ($success){ echo $success; } ?>
  <div class="adm-container">
    <div class="row">
      <div class="col-md-8 well">
        <div align="center"><strong></strong></div>
        <div class="table-responsive">
          <table class="table table-striped">
            <tr class="trevebheadlibe">
              <td><div align="center" style="font-weight: bold">
                  <div align="center">First Name</div>
                </div></td>
              <td><div align="center" style="font-weight: bold">
                  <div align="center">Last Name</div>
                </div></td>
              <td><div align="center" style="font-weight: bold">
                  <div align="center">Email</div>
                </div></td>
              <td><div align="center" style="font-weight: bold">
                  <div align="center">Level</div>
                </div></td>
              <td><div align="center" style="font-weight: bold">
                  <div align="center">Logins</div>
                </div></td>
              <td><div align="center" style="font-weight: bold">
                  <div align="center">Last Login</div>
                </div></td>
              <td><div align="center" style="font-weight: bold">
                  <div align="center">Category</div>
                </div></td>
              <td><div class="" style="font-weight: bold">
                  <div align="center">Settings</div>
                </div></td>
            </tr>
            <?php foreach($admin_details as $row_Blog) { ?>
            <tr class="trodd">
              <td><?php echo $row_Blog['blog_fname']; ?></td>
              <td><?php echo $row_Blog['blog_lname']; ?></td>
              <td><?php echo $row_Blog['blog_email']; ?></td>
              <td><?php echo $row_Blog['blog_level']; ?></td>
              <td><?php echo $row_Blog['blog_logins']; ?></td>
              <td><?php echo $row_Blog['blog_lastlogin']; ?></td>
              <td><?php echo $row_Blog['blog_catergory']; ?></td>
              <td><?php if ($this->session->userdata('blog_catergory') == 'Super Administrator') {	?>
                <a href="<?php echo $base_url; ?>admin/blogs/manage/<?php echo $row_Blog['blog_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Manage <?php echo $row_Blog['blog_fname']; ?>'s Records"><span class="glyphicon glyphicon-cog"></span></a>
                <?php } ?>
                <a href="<?php echo $base_url; ?>admin/blogs/edit/<?php echo $row_Blog['blog_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Edit <?php echo $row_Blog['blog_fname']; ?>'s Records"><span class="glyphicon glyphicon-edit"></span></a></div>
                <a href="<?php echo $base_url; ?>admin/password/<?php echo $row_Blog['blog_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Change <?php echo $row_Blog['blog_fname']; ?>'s Password"><span class="glyphicon glyphicon-question-sign"></span></a>
                <?php if ($this->session->userdata('blog_catergory') == 'Super Administrator'){ ?>
                <a href="<?php echo $base_url; ?>admin/blogs/delete/<?php echo $row_Blog['blog_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Delete <?php echo $row_Blog['blog_fname']; ?>'s Records" onclick="return confirm('Are you sure you want to delete?')"><span class="glyphicon glyphicon-remove-sign"></span></a></td>
              <?php } ?>
            </tr>
            <?php } ?>
          </table>
        </div>
      </div>
      <!-- start right-->
      <div class="col-md-3 pull-right">
      <div class="col-md-12 well">
        <h4><strong> Change Profile Picture</strong></h4>
        <div>
          <?php 
		  //my_blog_details
		  foreach($my_profile as $row_Blog) { 
		  	 $profile_pic = $row_Blog['blog_profile_pic'];
		  }
		  if($profile_pic){ ?>
          <div id="blog_profile_pic"> <img src="<?php echo $this->config->item('base_url'); ?>assets/images/<?php echo $profile_pic; ?>" alt="Upload a Profile Picture" class="img-responsive my-pic"  /> </div>
          <?php }else{?>
          <div><img src="<?php echo $this->config->item('base_url'); ?>assets/images/avatar.png" alt="Upload a Profile Picture" class="img-responsive"  /></div>
          <?php } ?>
        </div>
        <div>
          <?php if ($success){ ?>
          <div><strong><?php echo $success;?></strong></div>
          <?php } ?>
          <?php echo $error;?>
          <div>
            <form action="<?php echo $this->config->item('base_url'); ?>profile/do_upload" method="post" enctype="multipart/form-data">
              <div>Select a Blog User:</div>
              <div>
              	<?php if($this->session->userdata('blog_catergory') == 'Super Administrator'){ ?>
                <select name="blog_id" id="blog_id" required class="form-control"   >
                  <?php foreach ($my_blog as $k=>$v){ ?>
                  <option value='<?php echo $v['blog_id']; ?>'><?php echo $v['blog_fname']; ?> <?php echo $v['blog_lname']; ?></option>
                  <?php } ?>
                </select>
                <?php }else{ ?>
                <input type="hidden" name="blog_id" required="required" value="<?php echo $this->session->userdata('blog_id'); ?>" id="userfile">
                <?php } ?>
              </div>
              <div>Select a profile Picture to upload:</div>
              <div>
                <input type="file" name="userfile" required="required" id="userfile">
              </div>
              <div>
                <input type="submit" value="Upload Profile Picture" class="btn btn-primary" name="submit">
              </div>
            </form>
          </div>
          <!--end--></div>
      </div>
      
      
      
    
      
      
      <!--end--></div></div>
    <!-- end col-md-8 well--></div>
  <!-- end right-->
  
  <div class="clearfix"> </div>
  </div>
  </div>
</section>
