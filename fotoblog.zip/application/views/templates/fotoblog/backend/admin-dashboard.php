<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Dashboard</li>
    </ul>
  </div>
  <div class="adm-container">
    <div class="row"> 
      <!--start left  -->
      <div class="col-md-3 offset1 well">
        <h5><strong>Snapshot</strong></h5>
            <?php if ($this->session->userdata('blog_catergory') == 'Super Administrator') { ?>
            <div class="span4"><strong><?php echo $all_blogs; ?></strong> Active Blogs</div>
            <?php }; ?>
            <div class="span4"><strong><?php echo $total_logins; ?></strong> Logins  for <?php echo date('F'); ?> <?php echo date('Y'); ?></div>
            <div class="span4"><strong><?php echo $total_galleries; ?></strong> Galleries </div>
            <div class="span4"><strong><?php echo $total_gallery_images; ?></strong> Gallery Photos</div>
            <div class="span4"><strong><?php echo $total_articles; ?></strong> Published Articles</div>
            <div class="span4"><strong><?php echo $total_pages; ?></strong> Pages</div>
            <div class="span4"><strong><?php echo $total_comments; ?></strong> Comments</div>

      </div>
      <!--end left--> 
      
      <!-- start right-->
      <div class="col-md-3 col-md-offset-1 well pull-left">
        <h5><strong>Quick Links</strong></h5>
        <?php if ($this->session->userdata('blog_catergory') == 'Super Administrator') { ?>
        <div class="span4"><a href="<?php echo $this->config->item('base_url'); ?>admin/blogs/create"><span class="glyphicon glyphicon-user"></span> Create a User</a></div><?php } ?>
        <div class="span4"><a href="<?php echo $this->config->item('base_url'); ?>admin/articles"><span class="glyphicon glyphicon-th-list"></span> Create an Article</a></div>
        <div class="span4"><a href="<?php echo $this->config->item('base_url'); ?>admin/pages"><span class="glyphicon glyphicon-th-large"></span> Create a Page</a></div>
        <div class="span4"><a href="<?php echo $this->config->item('base_url'); ?>admin/categories"><span class="glyphicon glyphicon-tasks"></span> Create a Category</a></div>
        
        <!-- end col-md-8 well--></div>
      <!-- end right-->
      
      <div class="col-md-4 well pull-right">
        <h5><strong>PHP Details</strong></h5>
        <div class="span4"><strong>PHP Version</strong>: <?php echo phpversion(); ?></div>
        <?php
		//mysql_version
			if (ini_get('display_errors') == 1){
				echo '<div class="span4"><strong>Display Errors</strong>:  <strong  class="text-warning">PHP Errors are enabled and will display</strong></div>';
			}else{
				echo '<div class="span4"><strong>Register Globals</strong>:  <strong  class="text-success">PHP Errors are not enabled and will not display</strong></div>';
			}
			echo '<div class="span4"><strong>Maxiumum Size of a Single Upload</strong>:  ' . ini_get('post_max_size') . "</div>";
			echo '<div class="span4"><strong>Maxiumum Size of Multiple Uploads</strong>:  ' . (ini_get('post_max_size')+1) . "</div>";
			if (extension_loaded('gd') && function_exists('gd_info')) {
				echo '<div><strong>GD Image Library: </strong> <strong class="text-success">GD is installed</strong></div>';
			}else{
				echo '<div><strong>GD Image Library: </strong> <strong  class="text-warning">GD is not installed</strong></div>';
			}
			if(extension_loaded('imagick')) {
				echo '<div><strong>GD Image Library: </strong> <strong class="text-success">Imagick is installed</strong></div>';
			}else{
				echo '<div><strong>GD Image Library: </strong> <strong  class="text-warning">Imagick is not installed</strong></div>';
			}
			if (substr($mysql_version, 0, 1) >= '5'){
				echo '<div><strong>MySQL Version: </strong> <strong class="text-success">'.$mysql_version.'</strong></div>';
			}else{
				echo '<div><strong>MySQL Version: </strong> <strong class="text-warning">'.$mysql_version.'</strong></div>';
			}
	    ?>
        <?php
?>
        
        <!-- end col-md-8 well--></div>
      <div class="clearfix"> </div>
      <!--end row--> </div>
    
    <!--end adm-container--></div>
  <!--end section--></section>
