<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<section class="admin">
  <div class="adm-container">
    <div class="row">
      <div class="col-md-12"> <?php if ($error){ echo $error; } ?> 
	  <?php echo form_open_multipart('upload/do_upload');?>
        <input type="file" name="userfile" size="20" />
        <br />
        <br />
        <input type="submit" value="upload" />
        </form>
        
        <!-- end first row -->
        <div class="clearfix"> </div>
        
        <!--end col-lg-12--></div>
      <!--end row--></div>
    <!--end row--></div>
  <!--end section--></section>
