<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home </a> <span class="divider">/</span></li>
      <li><a href="#">Galleries </a> <span class="divider">/</span></li>
      <li class="active">Manage</li>
    </ul>
  </div>
  <div class="adm-container">
  <?php
  
  if ($this->uri->segment(5)=='success'){ 
	  echo '<div class="container">
	  <div class="alert alert-success">
	  <strong>Success!</strong> Your action was successful.
	  </div>
	  </div>';
  }
  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
  
  ?>
      <div class="row"> 
      <!--start left-->
      <div class="col-md-7">
      
        <div class="col-md-12 well">
          <?php if ( count($galleries) > 0 ) { ?>
          <div class="table-responsive">
            <table class="table table-striped">
              <tr>
                <td><div align="center" style="font-weight: bold">
                    <div align="center">Gallery Name</div>
                  </div></td>
                <td><div align="center" style="font-weight: bold">
                    <div align="center">Featured Image</div>
                  </div></td>
                <td><div align="center" style="font-weight: bold">
                    <div align="center">Settings</div>
                  </div></td>
              </tr>
              <?php foreach($galleries as $row) { ?>
              <tr>
                <td align="center" valign="middle"><?php echo $row['blog_gal_name']; ?></td>
                <td align="center" valign="middle"><img class="img-thumbnail my-pic" src="<?php echo $this->config->item('base_url').'uploads/'; echo $row['blog_gal_image_tbn']; ?>" width="100" alt=""/></td>
                <td align="center" valign="middle"><a href="<?php echo $this->config->item('base_url').'admin/galleries/'; echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Add Photos to <?php echo $row['blog_gal_pagename']; ?>" Gallery><span class="glyphicon glyphicon-plus-sign"></span></a> <a href="<?php echo $this->config->item('base_url').'admin/galleries/edit/'; echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>"  data-toggle="tooltip" data-placement="bottom" title="Edit <?php echo $row['blog_gal_pagename']; ?>"><span class="glyphicon glyphicon-edit"></span></a> <a onclick="return confirm('Are you sure you want to delete?')" href="<?php echo $this->config->item('base_url').'admin/galleries/delete/'; echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Delete <?php echo $row['blog_gal_pagename']; ?>"><span class="glyphicon glyphicon-remove-sign"></span></a></td>
                  </td>
              </tr>
              <?php } ?>
            </table>
            <p><?php echo $links; ?></p>
            <!--end--></div>
          <?php } else {  ?>
          <div class="span4">You havent created any Gallery yet</div>
          <?php } ?>
        </div>
        <?php if ( $photos ){ ?>
        <div class="col-md-12 well ">
          <h4>Photos in the <?php echo $gallery_name; ?> Gallery</h4>
          <div class="row">
            <div class="col-md-12">
              <?php if (count($photos) > 0) { foreach ($photos as $row){ ?>
              <!-- first row -->
              <div class="col-md-2"> <a href=""> <img class="img-thumbnail my-pic" src="<?php echo $this->config->item('base_url'); ?>uploads/<?php echo $row['blog_tbn_image_tbn']; ?>" title="View <?php echo ucwords($row['blog_gal_name']); ?> <?php echo site_name; ?> Gallery"   alt="<?php echo $row['blog_gal_name']; ?>" width="200" height="133" /></a> <a href="<?php echo $this->config->item('base_url').'admin/galleries/edit/'; echo $row['blog_gal_pagename']; ?>/<?php echo $row['blog_gal_id']; ?>/<?php echo $row['blog_tbn_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Edit Photo"><span class="glyphicon glyphicon-edit"></span></a> <a onclick="return confirm('Are you sure you want to delete?')" href="<?php echo $this->config->item('base_url').'admin/photos/'; echo $row['blog_gal_pagename']; ?>/delete/<?php echo $row['blog_gal_id']; ?>/<?php echo $row['blog_tbn_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Delete Photo"><span class="glyphicon glyphicon-remove-sign"></span></a> 
                
                <!--end col-lg-12--></div>
              <?php } } ?>
              <!-- end first row -->
              <div class="clearfix"> </div>
              
              <!--end col-lg-12--></div>
            <!--end row--></div>
        </div>
        <?php } ?>
      </div>
      <!--end left--> 
      <!-- bulk upload images -->
      <?php if ($gallery_id = $this->uri->segment(4)) { ?>
      <div class="col-md-4 well pull-right">
        <h4>Bulk Uploader :: Add Gallery Photos</h4>
        <?php echo form_open_multipart('upload/bulk_photos');?>
        <?php if ($this->uri->segment(5) == 'saved'){ 
					echo '<div class="alert alert-success">SUCCESS: Your action was Successful :-)</div>'; 
				}
				if ($this->uri->segment(5) == 'failed'){ 
					echo "<div class='alert alert-error'>ERROR: Your action wasn't Successful :-)</div>";
				}
			 ?>
        <div id="userfile_fields" class="front-div">
          <div>
            <h5>Upload Photo (1)</h5>
            <input name="userfile[]" required size="20" type="file">
          </div>
        </div>
        <div>
          <input type="button" class="btn btn-mini btn-info" id="more_fields" onclick="add_fields();" value="Add More" />
        </div>
        <div style="margin-top:1%">
          <input type="submit" class="btn btn-primary" value="Add Photo" />
          <input type="hidden" name="blog_gal_id" value="<?php echo $this->uri->segment(4); ?>" />
          <input type="hidden" name="blog_gal_title" value="<?php echo $this->uri->segment(3); ?>" />
          <input type="hidden" name="photo_gall" value="<?php echo $gallery_name; ?>" />
        </div>
        </form>
      </div>
      <script type="application/javascript">
			var file = 1;
			function add_fields() {
				file++;
				var objTo = document.getElementById('userfile_fields')
				var moreFiles = document.createElement("div");
				moreFiles.innerHTML = '<div><h5>Upload Photo (' + file +') </h5><input name="userfile[]" required="required" size="20" type="file"></div>';
				
				objTo.appendChild(moreFiles)
			}
		</script> 
      
      <!-- end bulk upload images --> 
      <!-- upload gallery photos manually -->
      <div class="col-md-4 well pull-right">
        <h4>Add Gallery Photos</h4>
        <?php if ($this->uri->segment(6) == 'saved'){ 
					echo '<div class="alert alert-success">SUCCESS: Your action was Successful :-)</div>'; 
				}
				if ($this->uri->segment(6) == 'failed'){
					echo "<div class='alert alert-error'>ERROR: Your action wasn't Successful :-)</div>";
				}
		?>
        <?php echo form_open_multipart('upload/photos');?>
        <div>
          <h5>Gallery Name</h5>
          <input name="photo_gall" type="text" class="form-control" value="<?php echo $gallery_name; ?>" readonly />
        </div>
        <div>
          <h5>Photo Name</h5>
          <input type="text" class="form-control" name="photo_name" />
        </div>
        <div>
          <h5>Photo Description</h5>
          <textarea rows="2"  class="form-control"  name="photo_desc"></textarea>
        </div>
        <div>
          <h5>Upload Photo</h5>
          <input name="userfile" type="file" required size="20" />
        </div>
        <div>
          <div style="margin-top:1%">
            <input type="submit" class="btn btn-primary" value="Add Photo" />
            <input type="hidden" name="blog_gal_id" value="<?php echo $this->uri->segment(4); ?>" />
            <input type="hidden" name="blog_gal_title" value="<?php echo $this->uri->segment(3); ?>" />
          </div>
          </form>
        </div>
        <script type="application/javascript">
	  
			var file = 1;
			function watermark_text() {
				file++;
				if(file == 2){ 
					var objTo = document.getElementById('Watermark_fields')
					var watermarkFiles = document.createElement("div");
					watermarkFiles.innerHTML = '<div><h5>Watermark Text</h5><input name="watermark_text" id="watermark_text"  class="form-control" required="required" type="text"></div>';
					
					objTo.appendChild(watermarkFiles)
				}
			}
			
			var file = 1;
			function watermark_img() {
				file++;
				if(file == 2){ 
					var objTo = document.getElementById('Watermark_fields')
					var watermarkImages = document.createElement("div");
					watermarkImages.innerHTML = '<div><h5>Watermark Image</h5><div> <img src="<?php echo $this->config->item('base_url'); ?>assets/images/settings/watermark.png"width="100" height="100" class="img-responsive" alt=""/></div></div>';
					
					objTo.appendChild(watermarkImages)
				}
			}
			
		</script> 
        <!-- end upload gallery photos manaully-->
        <?php }else{ ?>
        
        <!-- create gallery photos -->
        
        <div class="col-md-4 well pull-right">
          <?php if ($error){ echo $error; } ?>
          <?php if ($success){ echo $success; } ?>
          <?php echo form_open_multipart('upload/gallery');?>
          <h4>Create a Gallery</h4>
          <div>
            <h5>Gallery Name</h5>
            <input type="text" class="form-control" name="gall" />
          </div>
          <div>
            <h5>Gallery Description</h5>
            <textarea rows="3"  class="form-control"  name="desc"></textarea>
          </div>
          <div>
            <h5>Feature Photo</h5>
            <input name="userfile" type="file" required size="20" />
          </div>
          <div style="margin-top:1%">
            <input type="submit" class="btn btn-primary" value="Add Gallery" />
          </div>
          </form>
        </div>
        <?php } ?>
        
        <!-- end create gallery photos --> 
        
      </div>
      <!--end left--> 
      <!--end row--> </div>
    
    <!--end adm-container--> 
  </div>
  <!--end section--></section>
