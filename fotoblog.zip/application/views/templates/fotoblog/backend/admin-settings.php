<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Settings </li>
    </ul>
  </div>
  <div class="adm-container">
    <div class="row">
      <div class="col-md-7">
        <div align="center"><strong><?php echo $success; ?></strong></div>
        <div class="panel-group" id="accordion">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Site Settings</a> </h4>
            </div>
            <div id="collapse1" class="panel-collapse collapse in">
              <div class="panel-body"> <?php echo form_open_multipart('settings/edit');?>
                <?php 
                    foreach ($site as $row){
						$setting_image='';
						if ($row['setting_input_value'] == 'textarea'){
							$input = '<textarea name="site_'.$row['setting_id'].'[]" class="form-control"  >'.$row['setting_value'].'</textarea>';	
						}else if ($row['setting_input_value'] == 'select'){
							//get the selected options
							if ($row['setting_value'] == 'Show '.$row['setting_name'].''){
								$selected_show = 'selected="selected"';
								$selected_hide = '';
							}else if ($row['setting_value'] == 'Hide '.$row['setting_name'].''){
								$selected_hide = 'selected="selected"';
								$selected_show = '';
							}else{
								$selected = '';
							}
							if ($row['setting_input_text'] == 'big'){
								$row_numbers = 'rows="3"';
							}else{
								$row_numbers = '';
							}
							if ($row['setting_key']=='default_homepage') {
								
								if ($row['setting_value'] == 'Show All Homepages'){
									$selected_all = 'selected="selected"';
								}else{
									$selected_all = '';
								}
								
								$extra_home_value = '<option value="Show All Homepages" '.$selected_all.'>Show All Homepages</option>';
							}else{
								$extra_home_value = '';
							}
							$input = '
								<select name="site_'.$row['setting_id'].'[]"  class="form-control">
								  <option value="Show '.$row['setting_name'].'" '.$selected_show.'>Show '.$row['setting_name'].'</option>
								  <option value="Hide '.$row['setting_name'].'" '.$selected_hide.'>Hide '.$row['setting_name'].'</option>
								  '.$extra_home_value.'
								</select> ';								
						}else if ($row['setting_input_value'] == 'file'){
							if ($row['setting_value']){
								$setting_image = '<div class="front-div"><img src="'.$this->config->item('base_url').'assets/images/settings/'.$row['setting_value'].'" class="img-responsive thumbnail" alt=""/></div>';
							}
							$input = '<input name="site_'.$row['setting_id'].'[]"  type="file"> ';								
						}else{
							$input = '<input name="site_'.$row['setting_id'].'[]" '.$row_numbers.' type="'.$row['setting_input_value'].'" class="form-control" value="'.$row['setting_value'].'" />';	
						}
                        echo '<div><h5><strong>'.$row['setting_name'].'</strong></h5></div>';  echo  $setting_image; echo '<div>'.$input.'</div>';
                    }
                
                ?>
                
                <div style="margin-top:1%">
                  <input type="submit" class="btn btn-primary" value="Save Site Settings" />
                  <input type="hidden" name="site_settings" value="site_settings" />
                </div>
                </form>
              </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Email Settings</a> </h4>
            </div>
            <div id="collapse2" class="panel-collapse collapse">
              <div class="panel-body"> <?php echo form_open_multipart('settings/edit');?>
                <?php 
                    foreach ($email as $row){
						if ($row['setting_input_text'] == 'big'){
							$row_numbers = 'rows="3"';
						}else{
							$row_numbers = '';
						}
						if ($row['setting_input_value'] == 'textarea'){
							$input = '<textarea name="email_'.$row['setting_id'].'[]" class="form-control"  >'.$row['setting_value'].'</textarea>';	
							
						}else{
							$input = '<input name="email_'.$row['setting_id'].'[]" type="'.$row['setting_input_value'].'" '.$row_numbers.' class="form-control" value="'.$row['setting_value'].'" />';	
						}
                        echo '<div><h5><strong>'.$row['setting_name'].'</strong></h5></div>'; echo '<div>'.$input.'</div>';
                    }
                
                ?>
                <div style="margin-top:1%">
                  <input type="submit" class="btn btn-primary" value="Save Email Settings" />
                  <input type="hidden" name="email_settings" value="email_settings" />
                </div>
                </form>
              </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Contacts</a> </h4>
            </div>
            <div id="collapse3" class="panel-collapse collapse">
              <div class="panel-body"> <?php echo form_open_multipart('settings/edit');?>
                <?php 
                    foreach ($contacts as $row){
						if ($row['setting_input_text'] == 'big'){
							$row_numbers = 'rows="3"';
						}else{
							$row_numbers = '';
						}
						if ($row['setting_input_value'] == 'textarea'){
							
							
							$input = '<textarea name="contact_'.$row['setting_id'].'[]" class="form-control"  >'.$row['setting_value'].'</textarea>';
						}else{
							$input = '<input name="contact_'.$row['setting_id'].'[]" '.$row_numbers.' type="'.$row['setting_input_value'].'" class="form-control" value="'.$row['setting_value'].'" />';	
						}
                        echo '<div><h5><strong>'.$row['setting_name'].'</strong></h5></div>'; echo '<div>'.$input.'</div>';
                    }
                
                ?>
                <div style="margin-top:1%">
                  <input type="submit" class="btn btn-primary" value="Save Contact Settings" />
                  <input type="hidden" name="contact_settings" value="contact_settings" />
                </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- start right-->
      <?php /*?><div class="col-md-4 pull-right">
        <div class="col-md-12 well">
          <h4><strong> Add a Watermark Image</strong></h4>
          <div>
          
          </div>
          <!--end--></div>
      </div><?php */?>
      
      <!----> 
      
      <!--end--></div>
  </div>
  <!-- end col-md-8 well-->
  </div>
  <!-- end right-->
  
  <div class="clearfix"> </div>
  </div>
  </div>
</section>
