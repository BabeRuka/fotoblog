<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<section>
<div class="container">
    <div class="row">
      <div class="col-md-12">
      
     <!-- first row -->
      <div class="col-md-2 pull-left">
      <img src="<?php echo $this->config->item('base_url'); ?>assets/images/envato/brunettes/2914242800_5bae6afa4c_o_d.jpg"   alt=""/>
      <!--end col-lg-12--></div>
      
      <div class="col-md-2 pull-left">
      <img src="<?php echo $this->config->item('base_url'); ?>assets/images/envato/cities/3110691475_be6474d823_o_d.jpg" alt=""/>
      <!--end col-lg-12--></div>
      
      <div class="col-md-2 pull-left">
      <img src="<?php echo $this->config->item('base_url'); ?>assets/images/envato/kids/19482639_3045a6946d_o_d.jpg" alt=""/>
      <!--end col-lg-12--></div>
      
      <div class="col-md-2 pull-left">
      <img src="<?php echo $this->config->item('base_url'); ?>assets/images/envato/lakes/6192979956_600d7de042_o_d.jpg" alt=""/>
      <!--end col-lg-12--></div>
      
      <div class="col-md-2 pull-left">
      <img src="<?php echo $this->config->item('base_url'); ?>assets/images/envato/nature/1N7E0264a (2).jpg" alt=""/>
      <!--end col-lg-12--></div>
      
      <div class="col-md-2 pull-left">
      <img src="<?php echo $this->config->item('base_url'); ?>assets/images/envato/people/16600115_c5a162e6a5_o_d.jpg" alt=""/>
      <!--end col-lg-12--></div>
      
      
      
      
     <!-- end first row -->
	<div class="clearfix"> </div>
        
      <!--end col-lg-12--></div>
    <!--end row--></div>
    <!--end row--></div>
<!--end section--></section>