<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<body>
<nav class="navbar navbar-default adm">
  <div class="adm-container">
    <div class="adm-header">
      <div class="row">
        <div class="logo pull-left col-md-3">
          <div id="logo"><?php echo site_name; ?></div>
          <!-- logo --></div>
        <div class="menu pull-left col-md-6">
          <div class="pull-left"> 
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myDefaultNavbar1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
              <!-- navbar-header --> </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="myDefaultNavbar1">
              <ul class="nav navbar-nav">
                <li><a href="<?php echo $this->config->item('base_url'); ?>dashboard/index">Admin Home <span class="sr-only">(current)</span></a></li>
                <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true">Settings<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="<?php echo $this->config->item('base_url'); ?>admin/index">Users</a></li>
                    <?php if ($this->session->userdata('blog_catergory') == 'Super Administrator') {	?>
                        <li role="separator" class="divider"></li>
                        <li><a href="<?php echo $this->config->item('base_url'); ?>admin/blogs/create">Create User</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="<?php echo $this->config->item('base_url'); ?>settings/index">Site Settings</a></li>
                    <?php }	?>
                  </ul>
                </li>
                <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true">Galleries <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="<?php echo $this->config->item('base_url'); ?>admin/galleries">Galleries</a></li>
                    <?php if ($this->session->userdata('blog_catergory') == 'Super Administrator') {	?>
                        <li role="separator" class="divider"></li>
                        <li><a href="<?php echo $this->config->item('base_url'); ?>admin/slideshow/index">Slideshow</a></li>
                    <?php }	?>
                  </ul>
                </li>
                <li><a href="<?php echo $this->config->item('base_url'); ?>admin/pages"> Pages </a></li>
                <li><a href="<?php echo $this->config->item('base_url'); ?>admin/categories"> Categories </a></li>
                <li><a href="<?php echo $this->config->item('base_url'); ?>admin/articles"> Articles </a></li>
                <li><a href="<?php echo $this->config->item('base_url'); ?>admin/comments"> Comments </a></li>
                <li><a href="<?php echo $this->config->item('base_url'); ?>">Back to Site<span class="sr-only">(current)</span></a></li>
                <li><a href="<?php echo $this->config->item('base_url'); ?>logout/index" id="MenuBarItemSubmenu"><span class="glyphicon glyphicon-log-out"></span></a></li>
              </ul>
              <!-- menu --> </div>
            <!-- menu --> </div>
          <!-- menu --> </div>
        
          <div class="pull-right">
            <ul class="profile">
              
              <?php if ($this->session->userdata('profile_pic')){
					   $image = explode('.', $this->session->userdata('profile_pic'));
					   $image = $image[0].'_cropped_300_300.'.$image[1];
				  }else{
					   $image = 'avatar.png';
				  }
			   ?>
              <li class="avatar-pic-text"><?php echo $this->session->userdata('blog_fname'); ?> <?php echo $this->session->userdata('blog_lname'); ?></li>
              <li><img class="avatar-pic" src="<?php echo $this->config->item('base_url'); ?>assets/images/<?php echo $image; ?>" alt="<?php echo $this->session->userdata('blog_fname'); ?> <?php echo $this->session->userdata('blog_lname'); ?>" width="50" height="60"/></li>
            </ul>
            <!-- right --> </div>        
        
        <!-- collapse navbar-collapse--> </div>
      
      <!-- collapse navbar-collapse--> </div>
    <div class="clearfix" />
    <!-- header --> </div>
  <!-- container -->
  </div>
</nav>
