<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home</a> <span class="divider">/</span></li>
      <li class="active">Articles <span class="divider">/</span></li>
      <li class="active">Feature Image </li>
    </ul>
  </div>
  <div class="adm-container">
    <div class="row">
      <div class="col-md-7 well">
        <?php if ($success){ ?>
        <div><strong><?php echo $success;?></strong></div>
        <?php } ?>
        <?php echo $error;?>
        <div>
          <form action="<?php echo $this->config->item('base_url'); ?>featured/photos" method="post" enctype="multipart/form-data">
            <div>Select a Featured Image to upload:</div>
            <div>
              <input name="userfile" type="file" required="required" id="featured_image">
            </div>
            <div>
              <input type="hidden" value="<?php echo $this->uri->segment(3); ?>" name="blog_articles_id">
              <input type="submit" value="Upload a Featured Image" class="btn btn-primary" name="submit">
            </div>
          </form>
        </div>
        <!--end--></div>
      
      <!--<div class="col-md-7 well">--></div>
    
    <!-- end col-md-8 well--></div>
  <!-- end right-->
  
  <div class="clearfix"> </div>
  </div>
  </div>
</section>
