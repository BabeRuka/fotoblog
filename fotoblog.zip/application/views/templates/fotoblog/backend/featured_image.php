<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php if ($success){ ?>
<div><strong><?php echo $success;?></strong></div>
<?php } ?>
<?php echo $error;?>
<div>
<form action="<?php echo $this->config->item('base_url'); ?>featured/do_upload" method="post" enctype="multipart/form-data">
    <div>Select a Featured Image to upload:</div>
    <div><input type="file" name="featured_image" id="featured_image"></div>
    <div>
    <input type="hidden" value="<?php echo $this->uri->segment(3); ?>" name="blog_articles_id">
    <input type="submit" value="Upload a Featured Image" class="btn btn-primary" name="submit"></div>
</form>
</div>
<!--end--></div>