<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="admin">
  <div class="admin-div">
    <ul class="breadcrumb">
      <li><a href="#">Admin Home </a> <span class="divider">/</span></li>
      <li><a href="#">Slideshows </a> <span class="divider">/</span></li>
      <li class="active">Manage</li>
    </ul>
  </div>
   <?php
	  if ($this->uri->segment(3)=='success'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(3)=='error'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
	  if ($this->uri->segment(4)=='saved'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-success">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 	  if ($this->uri->segment(4)=='failed'){ 
		  echo '<div class="adm-container">
		  <div class="alert alert-warning">
		  <strong>Success!</strong> Your action was successful.
		  </div>
		  </div>';
	  }
 ?>
  
  <div class="adm-container">
    <div class="row"> 
      <!--start left-->
      <div class="col-md-7">
        <div class="col-md-12 well">
          <?php if ( count($slideshows) > 0 ) { ?>
          <div class="table-responsive">
            <table class="table table-striped">
              <tr>
                <td><div align="center" style="font-weight: bold">
                    <div align="center">Slideshow Name</div>
                  </div></td>
                <td>Slideshow Page</td>
                <td>Slideshow Status</td>
                <td><div align="center" style="font-weight: bold">
                    <div align="center">Featured Image</div>
                  </div></td>
                <td><div align="center" style="font-weight: bold">
                    <div align="center">Settings</div>
                  </div></td>
              </tr>
              <?php foreach($slideshows as $row) { ?>
              <tr>
                <td align="center" valign="middle"><?php echo $row['slide_name']; ?></td>
                <td align="center" valign="middle"><?php echo strtoupper($row['slide_type']); ?></td>
                <td align="center" valign="middle"><?php
					if ($row['slide_status'] == '1'){
						$slide_status = 'Active';
					}else{
						$slide_status = 'Not Active';
					}
					echo $slide_status; 
				 ?></td>
                <td align="center" valign="middle"><img class="img-thumbnail my-pic" src="<?php echo $this->config->item('base_url').'uploads/slideshows/'; echo $row['slide_image_tbn']; ?>" width="100" alt=""/></td>
                <td align="center" valign="middle">
                <a href="<?php echo $this->config->item('base_url').'admin/slideshow/'; echo $row['slide_pagename']; ?>/<?php echo $row['slide_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Add Photos to <?php echo $row['slide_pagename']; ?>" Slideshow><span class="glyphicon glyphicon-plus-sign"></span></a>
                  <a href="<?php echo $this->config->item('base_url').'admin/slideshow/edit/'; echo $row['slide_pagename']; ?>/<?php echo $row['slide_id']; ?>"  data-toggle="tooltip" data-placement="bottom" title="Edit <?php echo $row['slide_pagename']; ?>"><span class="glyphicon glyphicon-edit"></span></a>
                  <a onclick="return confirm('Are you sure you want to delete?')" href="<?php echo $this->config->item('base_url').'admin/slideshow/delete/'; echo $row['slide_pagename']; ?>/<?php echo $row['slide_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Delete <?php echo $row['slide_pagename']; ?>"><span class="glyphicon glyphicon-remove-sign"></span></a></td>
                  </td>
              </tr>
              <?php } ?>
            </table>
            
            <p><?php //echo $links; ?></p>
          <!--end--></div>
          <?php } else {  ?>
          <div class="span4">You havent created any Slideshow yet</div>
          <?php } ?>
        </div>
        <?php if ( $photos ){ ?>
        <div class="col-md-12 well ">
          <h4>Photos in the <?php echo $slideshow_name; ?> Slideshow</h4>
          <div class="row">
            <div class="col-md-12">
              <?php if (count($photos) > 0) { foreach ($photos as $row){ ?>
              <!-- first row -->
              <div class="col-md-2"> <a href=""> <img class="img-thumbnail my-pic" src="<?php echo $this->config->item('base_url'); ?>uploads/slideshows/<?php echo $row['slide_images_image_tbn']; ?>" title="View <?php echo ucwords($row['slide_name']); ?> <?php echo site_name; ?> Slideshow"   alt="<?php echo $row['slide_name']; ?>" width="200" height="133" /></a>
                <a onclick="return confirm('Are you sure you want to delete?')" href="<?php echo $this->config->item('base_url').'admin/photos/slideshow/'; echo $row['slide_pagename']; ?>/delete/<?php echo $row['slide_id']; ?>/<?php echo $row['slide_image_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Delete Photo"><span class="glyphicon glyphicon-remove-sign"></span></a>
                
                <!--end col-lg-12--></div>
              <?php } } ?>
              <!-- end first row -->
              <div class="clearfix"> </div>
              
              <!--end col-lg-12--></div>
            <!--end row--></div>
        </div>
        <?php } ?>
      </div>
      <!--end left--> 
       <div class="col-md-4 pull-right">
       
        <?php if ($this->uri->segment(5) == 'saved'){ 
					echo '<div class="alert alert-success btn btn-success">
  					<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>SUCCESS</strong>: Your action was Successful :-)
					</div>'; 
				}
				if ($this->uri->segment(5) == 'failed'){
					echo '<div class="alert alert-error btn btn-warning">
  					<button type="button" class="close" data-dismiss="alert">&times;</button>
  					<strong>ERROR</strong>: Your action wasn not Successful :-)
					</div>';
				}
		?>
      <!-- bulk upload images -->
       <?php if ((int)$this->uri->segment(4)) { ?>
      
       <div class="col-md-12 pull-right well">
      
      <!-- end bulk upload images --> 
      <!-- upload slideshow photos manually -->
      <div class="col-md-12 pull-right">
        <h4>Add Slideshow Photos</h4>
        <?php echo form_open_multipart('upload/slideshow');?>
        <div>
          <h5>Slideshow Name</h5>
          <input name="photo_gall" type="text" class="form-control" value="<?php echo $slideshow_name; ?>" readonly />
        </div>
        <div>
          <h5>Photo Name</h5>
          <input type="text" class="form-control" name="photo_name" />
        </div>
        <div>
          <h5>Slide Status</h5>
          <select class="form-control"  name="slide_status">
          	<option value="1">Active</option>
          	<option value="0" selected="selected">In Active</option>
          </select>
        </div>
        <div>
          <h5>Photo Description</h5>
          <textarea rows="2"  class="form-control"  name="photo_desc"></textarea>
        </div>
        <div>
          <h5>Upload Photo</h5>
          <input name="userfile" type="file" required size="20" />
        </div>
        <div>

          <div style="margin-top:1%">
            <input type="submit" class="btn btn-primary" value="Add Photo" />
            <input type="hidden" name="add_blog_slide_images" value="slide images" />
            <input type="hidden" name="slide_id" value="<?php echo $this->uri->segment(4); ?>" />
            <input type="hidden" name="slide_name" value="<?php echo $this->uri->segment(3); ?>" />
          </div>
          </form>
        </div>
        <script type="application/javascript">
	  
			var file = 1;
			function watermark_text() {
				file++;
				if(file == 2){ 
					var objTo = document.getElementById('Watermark_fields')
					var watermarkFiles = document.createElement("div");
					watermarkFiles.innerHTML = '<div><h5>Watermark Text</h5><input name="watermark_text" id="watermark_text"  class="form-control" required="required" type="text"></div>';
					
					objTo.appendChild(watermarkFiles)
				}
			}
			
			var file = 1;
			function watermark_img() {
				file++;
				if(file == 2){ 
					var objTo = document.getElementById('Watermark_fields')
					var watermarkImages = document.createElement("div");
					watermarkImages.innerHTML = '<div><h5>Watermark Image</h5><div> <img src="<?php echo $this->config->item('base_url'); ?>assets/images/settings/watermark.png"width="100" height="100" class="img-responsive" alt=""/></div></div>';
					
					objTo.appendChild(watermarkImages)
				}
			}
			
		</script> 
        <!-- end upload slideshow photos manaully-->
        <?php }else{ ?>
        
        <!-- create slideshow photos -->
        
        <div class="col-md-12 pull-right well">
         <?php echo form_open_multipart('upload/slideshow');?>
          <h4>Create a Slideshow</h4>
          <div>
            <h5>Slideshow Name</h5>
            <input name="gall" type="text" required class="form-control" />
          </div>
        <div>
          <h5>Slide Status</h5>
          <select class="form-control"  name="slide_status">
          	<option value="1">Active</option>
          	<option value="0" selected="selected">In Active</option>
          </select>
        </div>
          <div>
            <h5>Slideshow Description</h5>
            <textarea rows="3"  class="form-control"  name="desc"></textarea>
          </div>
          <div>
            <h5>Feature Photo</h5>
            <input name="userfile" type="file" required size="20" />
          </div>
          <div style="margin-top:1%">
            <input type="submit" class="btn btn-primary" value="Add Slideshow" />
          </div>
          </form>
        </div>
        <?php } ?>
        
        <!-- end create Slideshow photos --> 
        
      </div>
      <!--end left--> 
      <!--end row--> </div>
      <!--end row--> </div>
    
    <!--end adm-container--> 
  </div>
  <!--end section--></section>
