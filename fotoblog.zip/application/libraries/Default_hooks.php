<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class default_hooks {
	 
        public function galleries() {

			echo '<ul>';
			foreach ($footer_links as $row) {
					echo '<li><a href="'.$this->config->item('base_url').'gallery/browse/'. $row['blog_gal_pagename'].''. $row['blog_gal_id'] .'">'.$row['blog_gal_name'] .'</a></li>'; 
			}
			echo '</ul>';
		}
}
