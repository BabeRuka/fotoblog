<?php  
defined('BASEPATH') OR exit('No direct script access allowed');

class Functions {
	public function load_template($url, $file, $title){
		include($url.$file.'.php');
	}

	public function load_template_with_data($url, $file, $title, $blog_articles = NULL, $blog_title = NULL, $blog_description = NULL, $success = NULL){
		include($url.$file.'.php');
	}
	public function check_editor(){
		if ($this->session->userdata('blog_catergory') == 'Administrators'){ 
			$blog_id = $_POST['blog_id'];
		}else{
			$blog_id = $this->session->userdata('blog_id');
		}
		return $blog_id; 
	}
	public function get_path($part){
		$paths = $_SERVER['REQUEST_URI']; 
		$paths = explode ('/', $paths);
		return $paths[$part]; 
	}
	public function get_array_end_item(){
		$paths = $_SERVER['REQUEST_URI']; 
		$paths = explode ('/', $paths);
		return end($paths); 
	}
	public function get_total_number_of_paths(){
		$paths = $_SERVER['REQUEST_URI']; 
		$paths = explode ('/', $paths);
		return count($paths); 
	}	
	public function strip_all_invalids($strip){
		$strip=preg_replace('/[.,:?]/', '', $strip);
		$strip = str_replace("'", ' ', strtolower($strip));
		$strip = str_replace('"', ' ', $strip);
		$strip = str_replace(" ", '-', $strip);
		$strip = str_replace("_", '-', strtolower($strip));
		return $strip;  
	}		
	public function db(){
				$db = new connection();
				return $db;
	}
	public function get_full_url(){
		$url = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];	
		return $url;
	}
	public function get_requested_url(){
		$url = get_full_url();	
		$requested_url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];	
		return $url;
	}
	public function admin_joiner(){
		if ($this->session->userdata('blog_catergory')=='Administrators'){ 
			$joiner = "AND blogs.blog_id !=''";	
		}else{
			$joiner = "AND blogs.blog_id ='".$this->session->userdata('blog_id')."'";	
		}
		return $joiner;
		
	}
	public function admin_blog_id(){
		if ($_SESSION['blog_catergory']=='Administrators'){ 
			$joiner = "AND blogs.blog_id !=''";	
		}else{
			$joiner = "AND blogs.blog_id ='".$this->session->userdata('blog_id')."'";	
		}
		return '';
		
	}
	function strip_all_html_tags($content){
		$content = strip_tags(preg_replace('/<[^>]*>/','',str_replace(array("&nbsp;","\n","\r"),"",html_entity_decode($content,ENT_QUOTES,'UTF-8'))));
		return $content;
	}
}