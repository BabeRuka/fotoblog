<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','unit_test'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','menu','my_blog','outbound','article','all_blog_archives', 'all_categories','galleries','ajax_model'));
        $this->load->helper('url_helper');
		$this->load->model('authentication');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
	}


	public function get_blog_part() {
		$blog_id = $this->input->post('blog_id');
		$part = $this->input->post('part');
		echo $this->ajax_model->get_blog_part($blog_id, $part);
	}




}
