<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Articles extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','menu','my_blog','outbound','article','all_blog_archives','all_categories','galleries','settings','my_page'));
        $this->load->helper('url_helper');
		$this->load->model('authentication');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
		$data['footer_links'] = $this->galleries->latest_galleries();

		//global variables to be used in the class
		$this->about_data = $this->my_page->page_part('blog_content_description','about','global');
		//settings data
		$this->show_footer_widgets = $this->settings->setting_part('footer_widgets','site');
		$this->site_logo = $this->settings->setting_part('site_logo','site');
		$this->show_blog = $this->settings->setting_part('blog','site');
		$this->show_logo = $this->settings->setting_part('image_logo','site');
		$this->show_full_homepage = $this->settings->setting_part('full_homepage','site');
		$this->default_homepage = $this->settings->setting_part('default_homepage','site');
		$this->show_blog_posts = $this->settings->setting_part('blog_posts','site');
		$this->show_multiple_blogs = $this->settings->setting_part('multiple_blogs','site');
		$this->show_multiple_galleries = $this->settings->setting_part('multiple_galleries','site');
		$this->show_image_logo = $this->settings->setting_part('image_logo','site');
		$this->contacts_data = $this->settings->setting_parts('setting_name, setting_value','contacts');
		//data for the footer
		$this->latest_galleries = $this->galleries->latest_galleries();
		$this->latest_photos = $this->galleries->latest_photos();
		$this->latest_blog_posts = $this->my_blog->blog_content_with_limit(2);
		$this->archived_articles = $this->all_blog_archives->all_archives();
		$this->grouped_categories = $this->all_categories->all_grouped_categories();
		$this->blog_pages = $this->my_page->blog_pages();
		//keywords and description for site engines
		$default_description = ''.site_name.' is responsive Photo Bloging Template Powered by PHP and MySQL';
		$description = $this->article->get_article_title();
		$this->description =  $description ? $description : $default_description ; 
		$default_keyword = site_name; 
		$keyword = 'Gallery, Photo Gallery, Responsive Galleries,'.$this->article->get_article_title().','.$this->my_blog->my_blog_title();	
		$this->keywords = $keyword ? $keyword : $default_keyword; 
		//register link
		$this->register_link = $this->settings->setting_part('register_link','site');
		//email data
		$this->email_address = $this->settings->setting_part('email_address','email');
		$this->email_password = $this->settings->setting_part('email_password','email');
		$this->email_username = $this->settings->setting_part('email_username','email');
		$this->smtp_host = $this->settings->setting_part('smtp_host','email');
		$this->smtp_port = $this->settings->setting_part('smtp_port','email');
		$this->smtp_user = $this->settings->setting_part('smtp_user','email');
	}


	public function index() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['my_blog_content'] = $this->menu->my_blog_content();
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$data['footer_links'] = $this->galleries->latest_galleries();
		if ($this->input->post()){
			$blog_id = $this->article->getBlogID();	
			$article_id = $this->article->getArticleID();	
			$blog_title = $this->my_blog->my_blog_title();
			$article_title = $this->article->get_article_title();
			$data['blog_comments'] = $this->comments->all_blog_comments();	
			$data['my_blog_comments'] = $this->comments->my_blog_comment();	
			$data['blog_id'] = $blog_id;	
			$data['article_id'] = $article_id;	
			$data['title'] = $article_title;	
			$data['my_blog_content'] = $this->my_blog->all_my_blog_content();
			$data['page_title'] = ''.$article_title.' :: '.$blog_title.'';	
			$data['article'] = $this->article->get_article();	
			$data['some_articles'] = $this->article->get_some_of_my_articles($blog_id, $article_id);
			if ($this->comments->post_comment()){
				$data['message'] = '<input class="alert alert-success form-control"  type="text" value="Your Comment was successfull posted and will appear once it has been approved by the blog owner"> </input>';
			}else{
				$data['message'] = '<input class="alert alert-warning form-control"  type="text" value="Your Comment wasnt successfull posted. Please try again" ></input>';
			}
			$this->load->view(default_frontend_dir.'header', $data);
		$this->load->view(default_frontend_dir.'menu', $data);
			$this->load->view(default_frontend_dir.'articles', $data);
			$this->load->view(default_frontend_dir.'right-sidebar', $data);

		}else{
			$data['footer_links'] = $this->galleries->latest_galleries();
			$data['archived_articles'] = $this->all_blog_archives->all_archives();
			$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
			$blog_id = $this->article->getBlogID();	
			$article_id = $this->article->getArticleID();	
			$blog_title = $this->my_blog->my_blog_title();
			$article_title = $this->article->article_title();
			$data['message'] = 'Please enter your Comment below';	
			$data['blog_comments'] = $this->comments->all_blog_comments();	
			$data['my_blog_comments'] = $this->comments->my_blog_comment();	
			$data['blog_id'] = $blog_id;	
			$data['article_id'] = $article_id;	
			$data['title'] = $article_title;	
			$data['my_blog_content'] = $this->my_blog->all_my_blog_content();
			$data['page_title'] = ''.$article_title.' :: '.$blog_title.'';	
			$data['article'] = $this->article->get_article();	
			$data['some_articles'] = $this->article->get_some_of_my_articles($blog_id, $article_id);
			$this->load->view(default_frontend_dir.'header', $data);
			$this->load->view(default_frontend_dir.'menu', $data);
			$data['my_blog_content'] = $this->menu->my_blog_content();
			$this->load->view(default_frontend_dir.'articles', $data);
			$this->load->view(default_frontend_dir.'right-sidebar', $data);
		}

		$this->load->view(default_frontend_dir.'footer', $data);
	}




}
