<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation','image_lib','pagination'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('authentication','all_blogs','articles','comments','my_blog','menu','login_user','admin_dashboard','register_blog','all_categories', 'all_tags','reset_password', 'my_page','slideshow'));
		$this->load->model(array('galleries','uploader'));
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
		$this->authentication->is_loggedin($this->session->userdata('blog_id'));
        $this->load->helper('url_helper');
		
	}


	public function index() {
			if ($this->session) {
				$data['my_blog'] = $this->all_blogs->all_blog_content();
				$data['base_url'] = $this->config->item('base_url');
				$data['my_profile'] = $this->my_blog->my_blog_details();
				$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
				$data['blog_comments'] = $this->comments->all_blog_comments();	
				$data['getAllBlogContentRows'] = $this->all_blogs->getAllBlogContentRows();	
				$data['getAllRecordCount'] = $this->all_blogs->getAllRecordCount();	
				$data['getCurrentCount'] = $this->all_blogs->getCurrentCount();	
				//$data['my_blog_details'] = $this->all_blogs->my_blog_details();	// $this->news_model->get_news();
				$data['blog_articles'] = $this->all_blogs->all_blog_articles();	
				$data['blog_content'] = $this->all_blogs->all_blog_content();
				if ($this->session->userdata('blog_catergory') == 'Super Administrator') {					
					$data['admin_details'] = $this->admin_dashboard->all_admin_details();	
				}else{
					$blog_id=$this->session->userdata('blog_id');
					$data['admin_details'] = $this->admin_dashboard->admin_details($blog_id);	
				}
				$data['success'] = '';
				$data['error'] = '';
				$success = '';
				if ($this->uri->segment(3) == 'success') { 
					$data['success'] = $this->get_success_message(1);
				}
				$data['title'] = 'Admin Dashboard';
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
				$this->load->view(default_backend_dir.'admin');
				$this->load->view(default_backend_dir.'footer', $data);
			}else{
				redirect('/login/index');
			}
	}
	public function Galleries() {
		
        $config = array();
        $config["base_url"] = base_url().'admin/galleries';
        $config["total_rows"] = $this->galleries->total_galleries();
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		
		$data['title'] = 'Admin Dashboard :: Galleries';
		if ((int)$this->uri->segment(3))  {
			$data['galleries'] = $this->galleries->all_galleries($config["per_page"], $page);
		}else{
			$data['galleries'] = $this->galleries->admin_galleries();
		}
		$data['error'] = '';
		$data['success'] = '';
		$data['photos'] = '';
		$data['total_galleries'] = $this->galleries->total_galleries();
		$data["links"] = $this->pagination->create_links();

		//if the gallery has been selected then we give the option to upload photos for that gallery 
		if ($this->uri->segment(4)) { 
		
			//if there's the edit function on the url 
			if ($this->uri->segment(3) == 'edit') { 
				$gallery_id = $this->uri->segment(5);
				$gallery_title = $this->uri->segment(4);
				$data['gallery_name'] = $this->galleries->gallery_part($gallery_id, $part='blog_gal_name');
				$data['gallery'] = $this->galleries->this_gallery($gallery_id);
				
				//if there's an option to edit a photo
				if ($this->uri->segment(6)){
					$data['gallery_images'] = $this->galleries->gallery_images($this->uri->segment(6));
					$data['photos'] = $this->galleries->all_gallery_images($gallery_id);
				}
				
				//load the views
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
				$this->load->view(default_backend_dir.'admin/gallery/edit_gallery', $data);
				$this->load->view(default_backend_dir.'footer', $data);
			}else if ($this->uri->segment(3) == 'delete') { 
				$gallery_id = $this->uri->segment(5);
				$gallery_title = $this->uri->segment(4);
				$data['gallery_name'] = $this->galleries->gallery_part($gallery_id, $part='blog_gal_name');
				$data['gallery'] = $this->galleries->this_gallery($gallery_id);
				$data['deleted'] = $this->admin_dashboard->delete_gallery($gallery_id);
				if ($data['deleted']){
					$data['success'] = $this->get_success_message(1);
					redirect($this->config->item('base_url').'admin/galleries/success');
				}else{
					$data['success'] = $this->get_success_message(0);
					redirect($this->config->item('base_url').'admin/galleries/error');
				}
			}else{	
				$gallery_id = $this->uri->segment(4);
				$gallery_title = $this->uri->segment(3);
				$data['gallery_name'] = $this->galleries->gallery_part($gallery_id, $part='blog_gal_name');
				$data['photos'] = $this->galleries->all_gallery_images($gallery_id);
				//load the views
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
				$this->load->view(default_backend_dir.'admin-galleries', $data);
				$this->load->view(default_backend_dir.'footer', $data);
			}
			
		}else{
			if ($this->uri->segment(3)=='success')  {
				$data['success'] = $this->get_success_message(1);
			}
			$data['photos'] = '';
			$this->load->view(default_backend_dir.'header', $data);
			$this->load->view(default_backend_dir.'menu', $data);
			$this->load->view(default_backend_dir.'admin-galleries', $data);
			$this->load->view(default_backend_dir.'footer', $data);
		}
	}
	
	
	public function photos() {
		$data['title'] = 'Admin Dashboard :: Galleries';
		$data['galleries'] = $this->galleries->latest_galleries();
		$data['error'] = '';
		$data['success'] = '';
		$data['photos'] = '';
		//if the gallery has been selected then we give the option to upload photos for that gallery 
		if ($this->uri->segment(5)) { 
				if ($this->uri->segment(5) == 'delete') { 
				//if its a slideshow photo
					if ($this->uri->segment(3) == 'slideshow') { 
						//admin/photos/slideshow/all-galleries-slideshow/delete/1/3
						$photo=$this->slideshow->slideshow_photo($this->uri->segment(7), $part='slide_images_image');
						//delete the first photo
						unlink('uploads/slideshows/'.$photo);
						//delete the second photo
						$photo_two = explode('.',$photo);
						$photo_two = $photo_two[0].'_cropped_900_600.'.$photo_two[1];
						unlink('uploads/slideshows/'.$photo_two);
						//delete the third photo
						$photo_three = explode('.',$photo);
						$photo_three = $photo_three[0].'_cropped_500_200.'.$photo_three[1];
						unlink('uploads/slideshows/'.$photo_three);	
						
						if($this->admin_dashboard->delete_slide_photo($this->uri->segment(7)) ){	
							redirect($this->config->item('base_url').'admin/slideshow/'.$this->uri->segment(4).'/'.$this->uri->segment(6).'/saved');
						}else{
							redirect($this->config->item('base_url').'admin/slideshow/'.$this->uri->segment(4).'/'.$this->uri->segment(6).'/failed');
						}
					}
				}
	
			if ($this->uri->segment(4) == 'delete') { 
				//if its a slideshow photo
				$gallery_id = $this->uri->segment(5);
				$photo_id = $this->uri->segment(6);
				$gallery_name =  $this->uri->segment(3);
				//get the photo
				$photo=$this->galleries->gallery_photo($photo_id, $part='blog_tbn_image');
				//delete the first photo
				unlink('uploads/'.$photo);
				//delete the second photo
				$photo_two = explode('.',$photo);
                $photo_two = $photo_two[0].'_cropped_700_600.'.$photo_two[1];
				unlink('uploads/'.$photo_two);
				//delete the third photo
				$photo_three = explode('.',$photo);
                $photo_three = $photo_three[0].'_300_200.'.$photo_three[1];
				unlink('uploads/'.$photo_three);
			//delete the fourth photo
				$photo_four=$this->galleries->gallery_photo($photo_id, $part='blog_tbn_image_tbn');
				unlink('uploads/'.$photo_four);
				//load the views
				$data['deleted'] = $this->admin_dashboard->delete_photo($photo_id);				
				redirect($this->config->item('base_url').'admin/galleries/'.$gallery_name.'/'.$gallery_id.'/success');
			}
		}
	
	}
		
	public function Slideshow() {
		
        $config = array();
        $config["base_url"] = base_url().'admin/slideshows';
        $config["total_rows"] = $this->slideshow->total_slideshows();
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		
		$data['title'] = 'Admin Dashboard :: Slideshows';
		if ((int)$this->uri->segment(3))  {
			$data['slideshows'] = $this->slideshow->all_slideshows($config["per_page"], $page);
		}else{
			$data['slideshows'] = $this->slideshow->latest_slideshows();
		}
		$data['error'] = '';
		$data['success'] = '';
		$data['photos'] = '';
		$data['total_slideshows'] = $this->slideshow->total_slideshows();
		$data["links"] = $this->pagination->create_links();

		//if the slideshow has been selected then we give the option to upload photos for that slideshow 
		if ($this->uri->segment(4)) { 
		
			//if there's the edit function on the url 
			if ($this->uri->segment(3) == 'edit') { 
				$slide_id = $this->uri->segment(5);
				$slideshow_title = $this->uri->segment(4);
				$data['slideshow_name'] = $this->slideshow->slideshow_part($slide_id, $part='slide_name');
				$data['slideshow'] = $this->slideshow->this_slideshow($slide_id);
				
				//if there's an option to edit a photo
				if ($this->uri->segment(6)){
					$data['slideshow_images'] = $this->slideshow->slideshow_images($this->uri->segment(6));
					$data['photos'] = $this->slideshow->all_slideshow_images($slide_id);
				}
				
				//load the views
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
				$this->load->view(default_backend_dir.'admin/slideshows/edit-slideshow', $data);
				$this->load->view(default_backend_dir.'footer', $data);
			}else if ($this->uri->segment(3) == 'delete') { 
				$slide_id = $this->uri->segment(5);
				$slideshow_title = $this->uri->segment(4);
				$data['slideshow_name'] = $this->slideshow->slideshow_part($slide_id, $part='slide_name');
				$data['slideshow'] = $this->slideshow->this_slideshow($slide_id);
				
				$photo=$this->slideshow->slideshow_part($slide_id, $part='slide_image');
				//delete the first photo
				unlink('uploads/slideshows/'.$photo);
				//delete the second photo
				$photo_two = explode('.',$photo);
				$photo_two = $photo_two[0].'_cropped_900_600.'.$photo_two[1];
				unlink('uploads/slideshows/'.$photo_two);
				//delete the third photo
				$photo_three = explode('.',$photo);
				$photo_three = $photo_three[0].'_cropped_500_200.'.$photo_three[1];
				unlink('uploads/slideshows/'.$photo_three);
				if ($this->admin_dashboard->delete_slideshow($slide_id)){
					$data['success'] = '<div class="alert alert-success">SUCCESS: Your action was Successful :-)</div>';
					$success= 1;
					$result = 'saved';
					redirect($this->config->item('base_url').'admin/slideshow/index/saved');
				}else{
					$result = 'failed';
					redirect($this->config->item('base_url').'admin/slideshow/index/failed');
				}
			}else{		
				//if ((int)$this->uri->segment(4))  {
					$slide_id = $this->uri->segment(4);
					$slideshow_title = $this->uri->segment(3);
					$data['slideshow_name'] = $this->slideshow->slideshow_part($slide_id, $part='slide_name');
					$data['photos'] = $this->slideshow->all_slideshow_images($slide_id);
					//load the views
					$this->load->view(default_backend_dir.'header', $data);
					$this->load->view(default_backend_dir.'menu', $data);
					$this->load->view(default_backend_dir.'admin-slideshow', $data);
					$this->load->view(default_backend_dir.'footer', $data);
				//}else{
				//	redirect($this->config->item('base_url').'admin/slideshow/index/'.$result.'');
				//}
			}
			
		}else{
			$data['photos'] = '';
			$this->load->view(default_backend_dir.'header', $data);
			$this->load->view(default_backend_dir.'menu', $data);
			$this->load->view(default_backend_dir.'admin-slideshow', $data);
			$this->load->view(default_backend_dir.'footer', $data);
		}
	}
			
		
	public function password() {
		
		//login the user	
			if ($this->session) {
				$data['base_url'] = $this->config->item('base_url');
				$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
				$data['blog_comments'] = $this->comments->all_blog_comments();	
				$data['getAllBlogContentRows'] = $this->all_blogs->getAllBlogContentRows();	
				$data['getAllRecordCount'] = $this->all_blogs->getAllRecordCount();	
				$data['getCurrentCount'] = $this->all_blogs->getCurrentCount();	
				//$data['my_blog_details'] = $this->all_blogs->my_blog_details();	// $this->news_model->get_news();
				$data['blog_articles'] = $this->all_blogs->all_blog_articles();	
				$data['blog_content'] = $this->all_blogs->all_blog_content();
				if ($this->session->userdata('blog_catergory') == 'Super Administrator') {					
					$data['admin_details'] = $this->admin_dashboard->all_admin_details();	
				}else{
					$blog_id=$this->session->userdata('blog_id');
					$data['admin_details'] = $this->admin_dashboard->admin_details($blog_id);	
				}
				
				$functions = $this->uri->segment(3);
				
				if ($functions == 'change') {
					//validate
					$this->load->helper(array('form', 'url'));
					$this->load->library('form_validation');
					$this->form_validation->set_rules('password', 'Password', 'required', array('required' => 'You must provide a %s.') );
					$this->form_validation->set_rules('repeat_password', 'Password Confirmation', 'required|matches[password]');
					if ($this->form_validation->run() == FALSE) {
						$set_userdata = $this->session->set_userdata('success', '0');
						$success = 0;
						$data['success'] = $this->get_success_message($success);
						$data['title']= 'Admin Dashboard';
						$this->load->view(default_backend_dir.'header', $data);
						$this->load->view(default_backend_dir.'menu', $data);
						$this->load->view(default_backend_dir.'change-password');
						$this->load->view(default_backend_dir.'footer', $data);
					} else {
						//control the user and make sure he / her has the right to change a passowrd
						$control = $this->control_actions($blog_id = $this->input->post('blog_id'));
						$change = $this->reset_password->change();
						$set_userdata = $this->session->set_userdata('success', '1');
						$success = 1;
						$data['success'] = $this->get_success_message($success);
						$data['title']= 'Admin Dashboard';
						$this->load->view(default_backend_dir.'header', $data);
						$this->load->view(default_backend_dir.'menu', $data);
						$this->load->view(default_backend_dir.'change-password');
						$this->load->view(default_backend_dir.'footer', $data);
					}
				}else{
					$data['success'] = '';
					$success = '';
					$data['success'] = $this->get_success_message($success);
					$data['title']= 'Admin Dashboard';
					$this->load->view(default_backend_dir.'header', $data);
					$this->load->view(default_backend_dir.'menu', $data);
					$this->load->view(default_backend_dir.'change-password');
					$this->load->view(default_backend_dir.'footer', $data);
				}
			}else{
				redirect('/login/index');
			}
	}
	public function blogs() {
		
		//login the user	
			if ($this->session) {
				$data['error'] = '';
				$data['base_url'] = $this->config->item('base_url');
				$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
				$data['blog_comments'] = $this->comments->all_blog_comments();	
				$data['getAllBlogContentRows'] = $this->all_blogs->getAllBlogContentRows();	
				$data['getAllRecordCount'] = $this->all_blogs->getAllRecordCount();	
				$data['getCurrentCount'] = $this->all_blogs->getCurrentCount();	
				$data['blog_articles'] = $this->all_blogs->all_blog_articles();	
				$data['blog_content'] = $this->all_blogs->all_blog_content();
				$data['my_profile'] = $this->my_blog->all_my_blog_details($this->input->post('blog_id'));
				$data['my_blog'] = $this->all_blogs->all_blog_content();
				//default views
				$data['title']= 'Admin Dashboard';
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);				
				
				//get the task that a user is involved in
				$functions = $this->uri->segment(3);
				//break the tasks
				if ($functions == 'manage') {	
					//check if the user is a super admin or a regular user	
					$data['admin_details'] = $this->get_data();	
					if($this->input->post('blog_id') ){
			
						$blog_catergory= $this->input->post('blog_catergory');
						$blog_level= $this->input->post('blog_level');
						$blog_id= $this->input->post('blog_id');

						$data['update_details'] = $this->admin_dashboard->manage_blog_details($blog_id,$blog_catergory,$blog_level);	
						if ($data['update_details']){
							redirect($this->config->item('base_url').'admin/index/success');
						}else{
							redirect($this->config->item('base_url').'admin/index/error');
						}
					}else{
						//load the manage view
						$this->load->view(default_backend_dir.'admin/blogs/manage_admin', $data);	
					}
				}else if($functions == 'edit'){
					$data['success'] = '';
					$data['my_profile'] = $this->my_blog->my_blog_details();
					$data['admin_details'] = $this->get_data();	
					
					//if there's post data then we perform an edit 
					if($this->input->post('blog_id') ){
						//get the blog id
						$blog_id= $this->input->post('blog_id');
						//update the records
						$data['update_details'] = $this->admin_dashboard->edit_blog_details($blog_id);
						$set_userdata = $this->session->set_userdata('success', '1');
						if ($data['update_details']){
							redirect($this->config->item('base_url').'admin/index/success');
						}else{
							redirect($this->config->item('base_url').'admin/index/error');
						}
					}else{
						//load the manage view
						$this->load->view(default_backend_dir.'admin/blogs/edit_blog', $data);	
					}					
					
				}else if($functions == 'delete'){
					
					
					//if there's post data then we perform an edit 
					if( $this->uri->segment(4) ){
						//get the blog id
						$data['success'] = '0';
						$blog_id= $this->uri->segment(4);
						$control = $this->control_actions($blog_id);
						//update the records
						$set_userdata = $this->session->set_userdata('success', '1');
						$success = 1;
						$data['success'] = $this->get_success_message($success);	
						$data['update_details'] = $this->admin_dashboard->delete_blog($blog_id);	
						if ($data['update_details']){
							redirect($this->config->item('base_url').'admin/index/success');
						}else{
							redirect($this->config->item('base_url').'admin/index/error');
						}
					}else{
						//load the index view
						$data['success'] = '0';
						$data['admin_details'] = $this->get_data();	
						//load the admin view
						$this->load->view(default_backend_dir.'admin', $data);						
					}					

				}else if($functions == 'create'){
					if ($this->session->userdata('blog_catergory') !== 'Super Administrator') { 
						redirect($this->config->item('base_url').'dashboard/index');
					}
					//if there's post data then we perform an edit 
					if($this->input->post() ){
						//start edit user		
						$this->form_validation->set_rules('blog_username', 'Username', 'trim|alpha_numeric_spaces|callback_username_check|min_length[5]|max_length[12]', array('required' => 'Please enter a Username!!!'));
						$this->form_validation->set_rules('blog_password', 'Password', 'trim|required|min_length[8]', array('required' => 'Please enter a Password!!!'));
						$this->form_validation->set_rules('blog_password_confirm', 'Password Confirmation', 'required|matches[blog_password]' ,array('required' => 'Your Passwords must match!!!'));
						$this->form_validation->set_rules('blog_email', 'Email', 'trim|callback_email_check|valid_email|is_unique[blog_users.blog_email]', array('required' => 'Please enter a valid Email Address!!!'));
						$this->form_validation->set_rules('blog_fname', 'First Name', 'trim|alpha|required', array('required' => 'Please enter your First Name!!!'));
						$this->form_validation->set_rules('blog_lname', 'Last Name', 'trim|alpha|required', array('required' => 'Please enter your Last Name!!!'));
						$this->form_validation->set_rules('blog_pagetitle', 'Blog Title', 'trim|required', array('required' => 'Please enter a title for your blog!!!'));
				
						if ($this->form_validation->run() == FALSE) {
							//iof its from the admin area then we use an admin template
								$this->load->view(default_backend_dir.'admin/blogs/create_blog');	
						}else{
							$data['register'] = $this->register_blog->register();
							if ($data['register']){
								redirect($this->config->item('base_url').'admin/index/success');
							}else{
								redirect($this->config->item('base_url').'admin/index/error');
							}
						}
						//end validate the user						
						
					}else{
						//load the manage view
						$data['success'] = '';
						$success = '';
						$data['success'] = $this->get_success_message($success);
						$this->load->view(default_backend_dir.'admin/blogs/create_blog');		
					}					
					
					
					
				}else{
					//there are no actions so we direct the user to the dashboard
					$data['success'] = '';
					$data['admin_details'] = $this->get_data();	
					//load the admin view
					$this->load->view(default_backend_dir.'admin', $data);
				}
				//default views
				$this->load->view(default_backend_dir.'footer', $data);
			}else{
				redirect('/login/index');
			}
	}	
	
	
	public function articles() {
		
		//login the user	
			if ($this->session) {
				$data['base_url'] = $this->config->item('base_url');
				$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
				$data['all_articles'] = $this->get_articles_data();
				//default views
				$data['title']= 'Admin Dashboard :: Articles';
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);				
				
				//get the task that a user is involved in
				$functions = $this->uri->segment(3);
				//break the tasks
				if ($functions == 'manage') {	
					//check if the user is a super admin or a regular user	
					$data['success'] = '';
					$data['article_details'] = $this->get_articles_data();	
					$data['all_categories'] = $this->get_categories();	//get_categories
					$this->load->view(default_backend_dir.'admin/articles/manage_articles', $data);	
				}else if($functions == 'edit'){
					
					//if there's post data then we perform an edit 
					if($this->input->post('blog_articles_id') ){
						//get the blog id
						$data['success'] = '';
						$article_id = $this->input->post('blog_articles_id');
						$blog_id = $this->articles->get_blog_id_from_article($article_id);
						$control = $this->control_actions($blog_id);
						$data['article_details'] = $this->articles->get_article($article_id);
						$data['article_cats'] = $this->all_categories->all_article_categories($article_id);
						//update the records
						$data['update_details'] = $this->admin_dashboard->edit_article_details($article_id);	
						//blog_articles_catergory
						$blog_category_name = $this->input->post('blog_category_name'); 
						$category_slug = explode(",", $blog_category_name);
						foreach ($category_slug as $row) {
							$category_name = strtolower($row);
							$category_slug = str_replace("'", ' ', $row);
							$category_slug = str_replace('"', ' ', $category_slug);
							$category_slug = str_replace(" ", '', $category_slug);
							$category_slug = str_replace(" ", '-', $category_slug);
							$category_slug = str_replace("_", '-', strtolower($category_slug));
							$category_id = $this->all_categories->match_category($blog_id, $article_id, $category_name);
							if ($category_id){
								if (!empty($category_id )){
									$this->all_categories->update_category($category_id, $blog_id, $article_id, $category_name, $category_slug) ;
								}
							}else{
								$this->all_categories->insert_category($blog_id,$article_id,$category_name,$category_slug);
							}
						}
						//get the previous category
						$category = $this->articles->get_category($this->input->post('blog_articles_id'));
						//join the two categories
						if ($category){
							$category = $category.','.$blog_category_name;
						}else{
							$category = $blog_category_name;
						}
						$data['category'] = $this->admin_dashboard->update_category($this->input->post('blog_articles_id'), $category) ;
						if ($data['update_details']){	
								redirect($this->config->item('base_url').'admin/articles/success');
							}else{
								redirect($this->config->item('base_url').'admin/articles/error');
						}
					}else{
						//load the manage view
						$article_id = $this->uri->segment(4);
						$data['article_cats'] = $this->all_categories->all_article_categories($article_id);
						$data['article_details'] = $this->articles->get_article($article_id = $this->uri->segment(4));
						$data['success'] = '';
						$this->load->view(default_backend_dir.'admin/articles/edit_article', $data); 
					}					
					
				}else if($functions == 'delete'){
					
					
					//if there's post data then we perform an edit 
					if( $this->uri->segment(4) ){
						//get the blog id
						$data['success'] = 0;
						$article_id = $this->uri->segment(4);
						$blog_id = $this->articles->get_blog_id_from_article($article_id);
						$control = $this->control_actions($blog_id); 
						//update the records
						$data['success'] = 1;
						$success = 1;
						$data['success'] = $this->get_success_message($success);
						$data['update_details'] = $this->admin_dashboard->delete_article($article_id);	
						if ($data['update_details']){	
								redirect($this->config->item('base_url').'admin/articles/success');
							}else{
								redirect($this->config->item('base_url').'admin/articles/error');
						}
					}else{
						//load the index view
						$data['article_details'] = $this->get_articles_data();	//get_categories
						$data['all_categories'] = $this->get_categories();	//get_categories
						//load the admin view
						$data['success'] = '';
						$this->load->view(default_backend_dir.'admin/articles/manage_articles', $data);						
					}					

				}else if($functions == 'create'){
					if( $this->input->post('article_insert') ){
						$data['success'] = 0;
						//insert the new article
						$category_id = $this->input->post('article_catergory');
						$blog_id = $this->input->post('blog_id'); 
						$article_id = $this->articles->create_article();	
						$control = $this->control_actions($blog_id); 
						//get the category and slug names 
						$success = 1;
						$data['success'] = $this->get_success_message($success);
						$one_cat = $this->all_categories->one_category($category_id);
						foreach ($this->all_categories->one_category($category_id) as $k=>$v){
							$blog_category_name=$v['blog_category_name'];
							$blog_category_slug=$v['blog_category_slug'];
						}
						//get the tags and explode them then isert them based
						$article_tags = $this->input->post('article_tags'); 
						$article_tags = explode(",", $article_tags);
						foreach ($article_tags as $row) {
							$blog_tag_slug = str_replace("'", ' ', $row);
							$blog_tag_slug = str_replace('"', ' ', $blog_tag_slug);
							$blog_tag_slug = str_replace(" ", '-', $blog_tag_slug);
							$blog_tag_slug = str_replace("_", '-', strtolower($blog_tag_slug));
							$this->all_tags->insert_tag($blog_id,$article_id,$blog_tag_name=$row,$blog_tag_slug);
						}
						if($this->all_categories->insert_category($blog_id,$article_id,$blog_category_name,$blog_category_slug) ) {
							$set_userdata = $this->session->set_userdata('success', '1');
							redirect($this->config->item('base_url').'admin/articles/success');
						}else{
							$set_userdata = $this->session->set_userdata('success', '0');
							redirect($this->config->item('base_url').'admin/articles/error');
						}
					}else{
						//load the index view
						$data['article_details'] = $this->get_articles_data();	//get_categories
						$data['all_categories'] = $this->get_categories();	//get_categories
						$data['categories'] = $this->grouped_categories();	
						$data['blog_content'] = $this->get_blogs();	
						$data['success'] = '';
						//load the admin view
						$this->load->view(default_backend_dir.'admin/articles/create_article', $data);
					}
				}else{
					//there are no actions so we direct the user to the dashboard
					$data['admin_details'] = $this->get_data();	
					$data['all_categories'] = $this->get_categories();	
					$data['categories'] = $this->grouped_categories();	
					//load the admin view
					$data['success'] = '';
					$this->load->view(default_backend_dir.'admin/articles/manage_articles', $data);
				}
				//default views
				$this->load->view(default_backend_dir.'footer', $data);
			}else{
				redirect('/login/index');
			}
	}	
	
	public function categories() {
		
		//login the user	
			if ($this->session) {
				$data['base_url'] = $this->config->item('base_url');
				$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
				$data['all_articles'] = $this->articles->all_articles();	
				
				//default views
				$data['title']= 'Admin Dashboard :: Articles';
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);				
				
				//get the task that a user is involved in
				$functions = $this->uri->segment(3);
				//break the tasks
				if ($functions == 'edit'){
					//if there's post data then we perform an edit 
					$data['all_categories'] = $this->get_categories();	//get_categories
					if($this->input->post() ){
						//get the blog id
						$one_category = $this->all_categories->one_category($category_id);
						$category_id = $this->input->post('blog_category_id');
						$category_name = $this->input->post('blog_category_name');
						$category_slug = $this->input->post('blog_category_slug');
						$data['category'] = $this->articles->get_article($category_id);
						//update the records
						$data['update_details'] = $this->admin_dashboard->edit_category($category_id, $category_name, $category_slug);
						if ($data['update_details']){	
							redirect($this->config->item('base_url').'admin/categories/success');
						}else{
							redirect($this->config->item('base_url').'admin/categories/error');
						}
					}else{
						//load the manage view
						$data['success'] = '';
						$category_id = $this->uri->segment(4);
						$data['one_category'] = $this->all_categories->one_category($category_id);
						$this->load->view(default_backend_dir.'admin/categories/edit_category', $data);	
					}					
					
				}else if($functions == 'delete'){
					
					
					//if there's post data then we perform an edit 
					if( $this->uri->segment(4) ){
						//get the blog id
						$category_id = $this->uri->segment(4);
						//update the records
						$data['update_details'] = $this->admin_dashboard->delete_category($category_id);	
						$success = 1;
						if ($data['update_details']){	
							redirect($this->config->item('base_url').'admin/categories/success');
						}else{
							redirect($this->config->item('base_url').'admin/categories/error');
						}
					}else{
						//load the index view
						$data['article_details'] = $this->get_articles_data();	//get_categories
						$data['all_categories'] = $this->get_categories();	//get_categories
						//load the admin view
						$data['success'] = '';
						$this->load->view(default_backend_dir.'admin/categories/manage_categories', $data);						
					}					

				}else if($functions == 'create'){
					//create a new article from here 
					if ($this->input->post()) {
							$blog_id = $this->input->post('blog_id');
							$article_id = NULL;
							$blog_category_name = $this->input->post('blog_category_name');
							$blog_category_slug = trim_slashes($blog_category_name);
							$blog_category_slug = str_replace("'", ' ', $blog_category_slug);
							$blog_category_slug = str_replace('"', ' ', $blog_category_slug);
							$blog_category_slug = str_replace(" ", '-', $blog_category_slug);
							$blog_category_slug = str_replace("_", '-', $blog_category_slug);
							$insert_category = $this->all_categories->insert_category($blog_id,$article_id,$blog_category_name,$blog_category_slug);
							$set_userdata = $this->session->set_userdata('success', '1');
							$success = 1;
							$insert_category = $this->get_success_message($success);
							if ($insert_category){	
								redirect($this->config->item('base_url').'admin/categories/success');
							}else{
								redirect($this->config->item('base_url').'admin/categories/error');
							}
					}else{
						//load the index view
						$data['article_details'] = $this->get_articles_data();	
						$data['all_categories'] = $this->get_categories();	
						$data['categories'] = $this->get_categories();	
						$data['blog_content'] = $this->get_blogs();
						//load the admin view
						$data['success'] = '';
						$this->load->view(default_backend_dir.'admin/categories/create_category', $data);	
					}
				}else{
					//there are no actions so we direct the user to the dashboard
					$data['admin_details'] = $this->get_data();	
					$data['all_categories'] = $this->get_categories();	//get_categories
					//load the admin view
					$data['success'] = '';
					$this->load->view(default_backend_dir.'admin/categories/manage_categories', $data);
				}
				//default views
				$this->load->view(default_backend_dir.'footer', $data);
			}else{
				redirect('/login/index');
			}
	}	

	public function comments() {
		
		//login the user	
			if ($this->session) {
				$data['base_url'] = $this->config->item('base_url');
				$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
				$data['all_comments'] = $this->get_comments_data();
				//default views
				$data['title']= 'Admin Dashboard :: Comments';
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);				
				
				//get the task that a user is involved in
				$functions = $this->uri->segment(3);
				//break the tasks
				if ($functions == 'manage') {	
					//check if the user is a super admin or a regular user	
					$data['comments'] = $this->get_comments_data();	
					$data['success'] = '';
					$this->load->view(default_backend_dir.'admin/comments/manage_comments', $data);	
					
				}else if($functions == 'edit'){
					
					//if there's post data then we perform an edit 
					if($this->input->post('blog_comment_id') ){
						//get the blog id
						$comment_id = $this->input->post('blog_comment_id');
						$data['comments'] = $this->comments->get_comment($comment_id);
						$blog_id = $this->comments->get_blog_id($comment_id);
						$control = $this->control_actions($blog_id);
						//update the records
						$data['update_comments'] = $this->admin_dashboard->edit_comments($comment_id);	
						$success = 1;
						redirect($this->config->item('base_url').'admin/comments/success');
					}else{
						//load the manage view
						$comment_id = $this->uri->segment(4);
						$data['all_comments'] = $this->get_comments_data();	
						$data['success'] = '';
						$data['comments'] = $this->comments->get_comment($comment_id);
						$this->load->view(default_backend_dir.'admin/comments/edit_comments', $data);
						
					}					
					
				}else if($functions == 'delete'){
					//if there's post data then we perform an edit 
					if( $this->uri->segment(4) ){
						//update the records
						$blog_id = $this->comments->get_blog_id($comment_id = $this->uri->segment(4));
						$control = $this->control_actions($blog_id);
						$data['comments'] = $this->admin_dashboard->delete_comment($comment_id = $this->uri->segment(4));	
						$set_userdata = $this->session->set_userdata('success', '1');
						redirect($this->config->item('base_url').'admin/comments');
					}else{
						//load the index view
						$data['comments'] = $this->get_comments_data();	
						//load the admin view
						$data['success'] = '';
						$this->load->view(default_backend_dir.'admin/comments/manage_comments', $data);						
					}					

				}else{
					//there are no actions so we direct the user to the dashboard
					$data['comments'] = $this->get_comments_data();	//all_comments
					//load the admin view
					$data['success'] = '';
					$this->load->view(default_backend_dir.'admin/comments/manage_comments', $data);
				}
				//default views
				$this->load->view(default_backend_dir.'footer', $data);
			}else{
				redirect('/login/index');
			}
	}
	
	public function pages() {
		
		//login the user	
			if ($this->session) {
				$data['all_blogs'] = $this->all_blogs->all_blog_content();
				$data['base_url'] = $this->config->item('base_url');
				$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
				$data['all_pages'] = $this->get_pages_data();
				//default views
				$data['title']= 'Admin Dashboard :: Pages';
				$data['breadcrumb']= 'Pages';
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);				
				
				//get the task that a user is involved in
				$functions = $this->uri->segment(3);
				//break the tasks
				if ($functions == 'manage') {	
					//check if the user is a super admin or a regular user	
					$data['success'] = '';
					$data['page_details'] = $this->get_pages_data();	
					$this->load->view(default_backend_dir.'admin/pages/manage_pages', $data);	
				
				//edit 
				}else if($functions == 'edit'){
					$data['all_page_details'] = $this->get_pages_data();	
					//if there's post data then we perform an edit 
					if($this->input->post('blog_content_id') ){
						//redirect the user
						$blog_id = $this->input->post('blog_id');
						$control_actions = $this->control_actions($blog_id);
						//get the content id
						$blog_content_id = $this->input->post('blog_content_id');
						$data['page_details'] = $this->my_page->selected_page($blog_content_id);
						$set_userdata = $this->session->set_userdata('success', '0');
						//$control = $this->control_actions($blog_id);
						//update the records
						$data['update_details'] = $this->admin_dashboard->edit_page_details($content_id = $blog_content_id);	
						if ($data['page_details']){
							redirect($this->config->item('base_url').'admin/pages/success');
						}else{
							redirect($this->config->item('base_url').'pages/edit/'.$this->input->post('blog_content_id').'/'.$this->input->post('blog_id').'/error');
						}
					}else{
						//load the manage view
						$blog_content_id = $this->uri->segment(4);
						$data['success'] = '';
						$data['page_details'] = $this->my_page->selected_page($blog_content_id);
						$this->load->view(default_backend_dir.'admin/pages/edit_page', $data);	
					}					
					
				}else if($functions == 'delete'){
					
					
					//if there's post data then we perform an edit 
					if( $this->uri->segment(4) ){
						//get the blog id
						$page_id = $this->uri->segment(4);
						$blog_id = $this->uri->segment(5);
						$set_userdata = $this->session->set_userdata('success', '0');
						$control_actions = $this->control_actions($blog_id);
						//update the records
						$data['update_details'] = $this->admin_dashboard->delete_page($page_id);
						if ($data['update_details']){
							redirect($this->config->item('base_url').'admin/pages/success');
						}else{
							redirect($this->config->item('base_url').'admin/pages/error');
						}
					}else{
						//load the index view
						$data['page_details'] = $this->get_pages_data();
						$data['success'] = '';	
						//load the admin view
						$this->load->view(default_backend_dir.'admin/pages/manage_pages', $data);						
					}					

				}else if($functions == 'create'){
					if( $this->input->post('page_insert') ){
						//insert the new page
						$data['page_details'] = $this->get_pages_data();
						$blog_id = $this->input->post('blog_id'); 
						//$data['page_details'] = $this->my_page->selected_page($blog_content_id);							
						if( $this->my_page->create_page() ) {
							redirect($this->config->item('base_url').'admin/pages/success');
						}else{
							redirect($this->config->item('base_url').'admin/pages/error');
						}
					}else{
						$data['blog_content'] = $this->get_blogs();	
						//load the admin view
						$this->load->view(default_backend_dir.'admin/pages/create_page', $data);
					}
				}else{
					//there are no actions so we direct the user to the dashboard
					$data['success'] = '';
					$data['page_details'] = $this->get_pages_data();
					$this->load->view(default_backend_dir.'admin/pages/manage_pages', $data);
				}
				//default views
				$this->load->view(default_backend_dir.'footer', $data);
			}else{
				redirect('/login/index');
			}
	}		
	public function get_data(){
			//check if the user is a super admin or a regular user				
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {					
				$blog_id=$this->uri->segment(4);
				return $this->admin_dashboard->admin_details($blog_id);	
			}else{
				$blog_id=$this->session->userdata('blog_id');
				return $this->admin_dashboard->admin_details($blog_id);	
			}					
	}
	public function get_articles_data(){
			//check if the user is a super admin or a regular user				
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {					
				return $this->articles->all_articles();	
			}else{
				$blog_id=$this->session->userdata('blog_id');
				return $this->articles->get_my_articles($blog_id);	
			}					
	}	

	public function get_comments_data(){
			//check if the user is a super admin or a regular user				
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {					
				return $this->comments->all_comments();	
			}else{
				$blog_id=$this->session->userdata('blog_id');
				return $this->comments->get_my_comments($blog_id);	
			}					
	}	

	public function get_categories(){
			//check if the user is a super admin or a regular user				
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {					
				return $this->all_categories->all_categories();	
			}else{
				$blog_id=$this->session->userdata('blog_id');
				return $this->all_categories->all_my_categories($blog_id);	
			}					
	}	
	public function grouped_categories(){
			//check if the user is a super admin or a regular user				
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {					
				return $this->all_categories->grouped_categories(' WHERE blog_categories.blog_id IS NOT NULL ');	
			}else{
				$blog_id=$this->session->userdata('blog_id');
				return $this->all_categories->grouped_categories( ' WHERE blog_categories.blog_id = '.$blog_id.' ');	
			}					
	}	
	public function get_grouped_categories(){
			//check if the user is a super admin or a regular user				
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {					
				return $this->all_categories->all_blog_grouped_categories();	
			}else{
				$blog_id=$this->session->userdata('blog_id');
				return $this->all_categories->all_blog_grouped_categories_for_user($blog_id);	
			}					
	}	
	public function get_blogs(){
			//check if the user is a super admin or a regular user				
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {					
				return $this->all_blogs->all_blog_content();	
			}else{
				$blog_id=$this->session->userdata('blog_id');
				return $this->all_blogs->my_blog_details($blog_id);	
			}					
	}	
	public function get_pages_data(){
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {					
				return $this->my_page->all_pages();	
			}else{
				$blog_id=$this->session->userdata('blog_id');
				return $this->my_page->one_page($blog_id);	
			}					
	}
	public function username_check($str) {
		   $username_check = $this->register_blog->username_check($str);
           if ($str == $username_check ){
               $this->form_validation->set_message('username_check', 'SORRY: The {field} field cannot be "'.$username_check.'". The username is already being used :-(');
               return FALSE;
           }else{
               return TRUE;
           }
    }

	public function email_check($str) {
		   $email_check = $this->register_blog->email_check($str);
           if ($str == $email_check ){
               $this->form_validation->set_message('email_check', 'SORRY: The {field} field cannot be "'.$email_check.'". The Email is already in use :-(');
               return FALSE;
           }else{
               return TRUE;
           }
	}
	
	function check_editor($article_id, $function){
		$blog_id=$this->articles->get_blog_id_from_article($article_id);
		if ($blog_id !== $this->session->userdata('blog_id')){
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {
				$data['article_details'] = $this->articles->get_article($article_id);
				return $this->load->view($function, $data);	
			}else{
				return $this->load->view('blocked');
			}
		}else{
			$data['article_details'] = $this->articles->get_article($article_id);
			return $this->load->view($function, $data);	
		}
	}
	function control_actions($blog_id){
		$my_blog_id = $this->session->userdata('blog_id');
		if ($blog_id != $my_blog_id ){
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {
				return TRUE;	
			}else{
				redirect($this->config->item('base_url').'admin/index');
			}
		}else{
			return FALSE;	
		}
	}

	function check_deletor($article_id){
		$blog_id=$this->articles->get_blog_id_from_article($article_id);
		if ($blog_id !== $this->session->userdata('blog_id')){
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {
				return TRUE;	
			}else{
				redirect($this->config->item('base_url').'logout/index');
			}
		}else{
			return TRUE;	
		}
	}

	function get_success_message($success = NULL){  

			if ($success ){
				if ($success == '1'){
					$success = '<div class="container">
								  <div class="alert alert-success">
									<strong>Success!</strong> Your action was successful.
								  </div>
								</div>';
				}else if($success == '0'){
					$success = '<div class="container">
								  <div class="alert alert-warning">
									<strong>Error!</strong> Your action wasn’t successful. Please try again or contact your administrator.
								  </div>
								</div>';
				}else{
					$success = '';
				}
			}else{
				$success = '';
			}
			
			return $success;
		
	}		
}
