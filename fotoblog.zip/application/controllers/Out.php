<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Out extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','my_blog','outbound'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));

	}


	public function index() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$blog_id = $this->outbound->getBlogID();	
		$article_id = $this->outbound->getArticleID();	
		$track_article = $this->outbound->track_article();	
		$article_title = $this->outbound->article_title($article_id);
		$article_title = trim(strip_tags($article_title));
		$article_title = strtolower(str_replace("'", '', $article_title));
		// Strip HTML Tags
		$article_title = strip_tags($article_title);
		// Clean up things like &amp;
		$article_title = html_entity_decode($article_title);
		// Strip out any url-encoded stuff
		$article_title = urldecode($article_title);
		// Replace non-AlNum characters with space
		$article_title = preg_replace('/[^A-Za-z0-9]/', ' ', $article_title);
		// Replace Multiple spaces with single space
		$article_title = preg_replace('/ +/', ' ', $article_title);
		// Trim the string of leading/trailing space
		$article_title = trim($article_title);
		$article_title = strtolower(str_replace(' ', '-', $article_title));

		redirect(''.$this->config->item("base_url").'articles/index/'.$blog_id.'/'.$article_id.'/'.$article_title.'');
	}

	public function gallery() {
		$track_gallery = $this->outbound->track_gallery();	
		$gallery_id = $this->outbound->getGalleryID();	
		$gallery_name = $this->outbound->getGallery();
		redirect(''.$this->config->item("base_url").'gallery/browse/'.$gallery_name.'/'.$gallery_id.'');
	}

	public function photo() {
		$track_photo = $this->outbound->track_photo();	
		$gallery_id = $this->outbound->getGalleryID();	
		$photo_id = $this->outbound->getPhotoID();	
		$gallery_name = $this->outbound->getGallery();
		redirect(''.$this->config->item("base_url").'modal/browse/'.$gallery_name.'/'.$gallery_id.'/'.$photo_id.'');
	}

	public function page() {
		$blog_id = $this->outbound->getBlogID();	
		$content_id = $this->outbound->getContentID();
		$track_page = $this->outbound->track_page();	
		redirect(''.$this->config->item("base_url").'page/index/'.$blog_id.'/'.$content_id.'');
	}

}
