<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation','email'));
		$this->load->library('image_lib');
		$this->load->helper(array('url','form','html','url_helper','email'));
		$this->load->model(array('my_blog','login_user','reset_password','admin_dashboard','uploader','settings','all_blog_archives','my_page','galleries','all_categories','ajax_model'));
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));

		//global variables to be used in the class
		$this->about_data = $this->my_page->page_part('blog_content_description','about','global');
		$this->show_footer_widgets = $this->settings->setting_part('footer_widgets','site');
		$this->site_logo = $this->settings->setting_part('site_logo','site');
		$this->show_blog = $this->settings->setting_part('blog','site');
		$this->show_logo = $this->settings->setting_part('image_logo','site');
		$this->show_full_homepage = $this->settings->setting_part('full_homepage','site');
		$this->default_homepage = $this->settings->setting_part('default_homepage','site');
		$this->show_blog_posts = $this->settings->setting_part('blog_posts','site');
		$this->show_multiple_blogs = $this->settings->setting_part('multiple_blogs','site');
		$this->show_multiple_galleries = $this->settings->setting_part('multiple_galleries','site');
		$this->show_image_logo = $this->settings->setting_part('image_logo','site');
		$this->contacts_data = $this->settings->setting_parts('setting_name, setting_value','contacts');
		//data for the footer
		$this->latest_galleries = $this->galleries->latest_galleries();
		$this->latest_photos = $this->galleries->latest_photos();
		$this->latest_blog_posts = $this->my_blog->blog_content_with_limit(2);
		$this->archived_articles = $this->all_blog_archives->all_archives();
		$this->grouped_categories = $this->all_categories->all_grouped_categories();
		$this->blog_pages = $this->my_page->blog_pages();
	}


	public function index() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['base_url'] = $this->config->item('base_url');
		$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
		$data['title'] = 'Upload Profile Picture';
		$data['error'] = '';
		$data['success'] = 'Please upload your new profile picture using the form below';
		$this->load->view(default_backend_dir.'header', $data);
		$this->load->view(default_backend_dir.'menu', $data);
		$this->load->view(default_backend_dir.'profile_pic');
		$this->load->view(default_backend_dir.'footer', $data);
	}
	public function do_upload() {		
				$data['my_blog'] = $this->my_blog->blog_content();
				$data['title']='Admin Dashboard :: Upload';
				$file_name = $this->input->post('blog_id').'_'.time();
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
                $config['upload_path']          = 'assets/images/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 5000;
                $config['max_width']            = 5000;
				$config['file_name'] = $file_name;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile')) {
                    $error = array('error' => $this->upload->display_errors());
					$this->load->view(default_backend_dir.'admin', $error);
					$this->load->view(default_backend_dir.'footer', $data);
                } else {
 					$data['update'] = $this->admin_dashboard->update_profile_picture($blog_id = $this->input->post('blog_id'), $profile_pic = ''.$file_name.''.$this->upload->data('file_ext').'');
                   $data = array('upload_data' => $this->upload->data());
					//create a thumbnail by resizing the image
					if( $this->upload->data('is_image') ) {
						$file_path = $this->upload->data('file_path');
						$raw_name = $this->upload->data('raw_name');
						$orig_name = $this->upload->data('orig_name');
						$source_image = $this->upload->data('full_path');
						$image_width = $this->upload->data('image_width');
						$image_height = $this->upload->data('image_height');
						$file_ext = $this->upload->data('file_ext');
						$this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '300', $thumb_height='300', $file_ext);
						$this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '700', $thumb_height='600', $file_ext);
					}
					//create a thumbnail by cropping the image
					redirect($this->config->item('base_url').'admin/index');
                }
				$this->load->view(default_backend_dir.'footer', $data);
    }
	
	

	

}
