<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logout extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','my_blog','menu','login_user','admin_dashboard','register_blog','logout_user'));
        $this->load->helper('url_helper');

	}


	public function index() {
		
		//track the user
		$track_user = $this->logout_user->track();	
		$name = 'logout';
		$value = $track_user;
		$expire = '86500';
		$domain = $this->config->item('base_url');
		$path = '/';
		$prefix = 'tb';
		$secure = 'TRUE';
		$this->input->set_cookie($name, $value, $expire, $domain, $path, $prefix, $secure);
		$this->session->sess_destroy();
		$data = array(
			'user_active' => 0,
			'user_logged_out' => 0
		);	
		$set_userdata = $this->session->set_userdata($data);			
		//end tracking the user
		redirect($this->config->item('base_url'));
	}

	

}
