<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gallery extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','unit_test'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('authentication','galleries','comments','all_blog_archives','all_categories','my_blog','all_blogs','slideshow','settings','my_page'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
		//global variables to be used in the class
		$this->about_data = $this->my_page->page_part('blog_content_description','about','global');
		$this->show_footer_widgets = $this->settings->setting_part('footer_widgets','site');
		$this->site_logo = $this->settings->setting_part('site_logo','site');
		$this->show_blog = $this->settings->setting_part('blog','site');
		$this->show_logo = $this->settings->setting_part('image_logo','site');
		$this->show_full_homepage = $this->settings->setting_part('full_homepage','site');
		$this->default_homepage = $this->settings->setting_part('default_homepage','site');
		$this->show_blog_posts = $this->settings->setting_part('blog_posts','site');
		$this->show_multiple_blogs = $this->settings->setting_part('multiple_blogs','site');
		$this->show_multiple_galleries = $this->settings->setting_part('multiple_galleries','site');
		$this->show_image_logo = $this->settings->setting_part('image_logo','site');
		$this->contacts_data = $this->settings->setting_parts('setting_name, setting_value','contacts');
		$this->show_homepage_slide = $this->settings->setting_part('homepage_slide','site');
		//data for the footer
		$this->latest_galleries = $this->galleries->latest_galleries();
		$this->latest_photos = $this->galleries->latest_photos();
		$this->latest_blog_posts = $this->my_blog->blog_content_with_limit(2);
		$this->archived_articles = $this->all_blog_archives->all_archives();
		$this->grouped_categories = $this->all_categories->all_grouped_categories();
		$this->blog_pages = $this->my_page->blog_pages();
		//keywords and description for site engines
		$default_description = ''.site_name.' is responsive Photo Bloging Template Powered by PHP and MySQL';
		$description = '';
		$this->description =  $description ? $description : $default_description ; 
		$default_keyword = site_name; 
		$keyword = 'Gallery, Photo Gallery, Responsive Galleries';	
		$this->keywords = $keyword ? $keyword : $default_keyword; 
		//register link
		$this->register_link = $this->settings->setting_part('register_link','site');
		//email data
		$this->email_address = $this->settings->setting_part('email_address','email');
		$this->email_password = $this->settings->setting_part('email_password','email');
		$this->email_username = $this->settings->setting_part('email_username','email');
		$this->smtp_host = $this->settings->setting_part('smtp_host','email');
		$this->smtp_port = $this->settings->setting_part('smtp_port','email');
		$this->smtp_user = $this->settings->setting_part('smtp_user','email');
	}


	public function index() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['title'] = 'Welcome to '.site_name.'';
		$data['footer_links'] = $this->galleries->latest_galleries();
		$data['galleries'] = $this->galleries->latest_galleries();
		$this->load->view(default_frontend_dir.'header', $data);
		$this->load->view(default_frontend_dir.'menu', $data);
		$this->load->view(default_frontend_dir.'home-grid', $data);
		$this->load->view(default_frontend_dir.'footer', $data);
		$data['my_blog'] = $this->my_blog->blog_content();
	}

	public function web() {
		
		if ($this->show_full_homepage == 'Show Full Homepage') {
			$data['my_blog'] = $this->my_blog->blog_content();
			$data['all_blogs'] = $this->all_blogs->all_blog_content();
			$data['title'] = 'Welcome to '.site_name.'';
			$data['latest_photos'] = $this->galleries->latest_photos();
			$data['galleries'] = $this->galleries->latest_galleries();
			$image = $this->slideshow->one_active_slideshow_image('homepage',$part='slide_images_image');
			$data['slide_image_name']  = $this->slideshow->one_active_slideshow_image('homepage',$part='slide_image_name');
			$data['slide_image_caption']  = $this->slideshow->one_active_slideshow_image('homepage',$part='slide_image_caption');
			$data['slide_name']  = $this->slideshow->one_active_slideshow_image('homepage',$part='slide_name');
			//slide_name
			$data['one_slideshow'] = $image;
			$data['slideshow'] = $this->slideshow->active_slideshow('homepage', $image);
			//$data['photo_id'] = $this->galleries->gallery_part($gallery_id, $part = 'blog_tbn_id'); 
			$this->load->view(default_frontend_dir.'header', $data);
			$this->load->view(default_frontend_dir.'menu', $data);
			$this->load->view(default_frontend_dir.'home-web', $data);
			$this->load->view(default_frontend_dir.'footer', $data);
		}else{
			$data['my_blog'] = $this->my_blog->blog_content();
			$data['title'] = 'Welcome to '.site_name.'';
			$data['footer_links'] = $this->galleries->latest_galleries();
			$data['galleries'] = $this->galleries->latest_galleries();
			$this->load->view(default_frontend_dir.'header', $data);
			$this->load->view(default_frontend_dir.'menu', $data);
			$this->load->view(default_frontend_dir.'home-grid', $data);
			$this->load->view(default_frontend_dir.'footer', $data);
			$data['my_blog'] = $this->my_blog->blog_content();
		}		
		
	}

	public function browse() {
		$data['footer_links'] = $this->galleries->latest_galleries();
		$data['my_blog'] = $this->my_blog->blog_content();
		$gallery_id = $this->uri->segment(4);
		$data['photo'] = '';
		$data['photo_caption'] = '';
		if ($this->uri->segment(5)){
			$data['photo'] = $this->galleries->gallery_photo($this->uri->segment(5), 'blog_tbn_image');
			$data['photo_caption'] = $this->galleries->gallery_photo($this->uri->segment(5), 'blog_tbn_caption');
			$data['photo_id'] = $this->galleries->gallery_part($gallery_id=$this->uri->segment(5), $part = 'blog_tbn_id'); 
		}
		
		$gallery_title = $this->uri->segment(3);
		$data['title'] = ''.$this->galleries->gallery_part($gallery_id, $part = 'blog_gal_name').' Gallery'; 
		$data['photos'] = $this->galleries->all_gallery_images($gallery_id);
		$data['gallery'] = $this->galleries->this_gallery($gallery_id);
		$this->load->view(default_frontend_dir.'header', $data);
		$this->load->view(default_frontend_dir.'menu', $data);
		$this->load->view(default_frontend_dir.'home-grid-gallery', $data);
		$this->load->view(default_frontend_dir.'footer', $data);
	}


}
