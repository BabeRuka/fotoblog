<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Password extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation','email'));
		$this->load->helper(array('url','form','html','url_helper','email'));
		$this->load->model(array('my_blog','login_user','reset_password','all_blog_archives','all_categories','settings','my_page','galleries'));
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));

		//global variables to be used in the class
		$this->about_data = $this->my_page->page_part('blog_content_description','about','global');
		$this->show_footer_widgets = $this->settings->setting_part('footer_widgets','site');
		$this->site_logo = $this->settings->setting_part('site_logo','site');
		$this->show_blog = $this->settings->setting_part('blog','site');
		$this->show_logo = $this->settings->setting_part('image_logo','site');
		$this->show_full_homepage = $this->settings->setting_part('full_homepage','site');
		$this->default_homepage = $this->settings->setting_part('default_homepage','site');
		$this->show_blog_posts = $this->settings->setting_part('blog_posts','site');
		$this->show_multiple_blogs = $this->settings->setting_part('multiple_blogs','site');
		$this->show_multiple_galleries = $this->settings->setting_part('multiple_galleries','site');
		$this->show_image_logo = $this->settings->setting_part('image_logo','site');
		$this->contacts_data = $this->settings->setting_parts('setting_name, setting_value','contacts');
		//data for the footer
		$this->latest_galleries = $this->galleries->latest_galleries();
		$this->latest_photos = $this->galleries->latest_photos();
		$this->latest_blog_posts = $this->my_blog->blog_content_with_limit(2);
		$this->archived_articles = $this->all_blog_archives->all_archives();
		$this->grouped_categories = $this->all_categories->all_grouped_categories();
		$this->blog_pages = $this->my_page->blog_pages();
		//keywords and description for site engines
		$default_description = ''.site_name.' is responsive Photo Bloging Template Powered by PHP and MySQL';
		$description = '';
		$this->description =  $description ? $description : $default_description ; 
		$default_keyword = site_name; 
		$keyword = 'Gallery, Photo Gallery, Responsive Galleries,Register';	
		$this->keywords = $keyword ? $keyword : $default_keyword; 
		//register link
		$this->register_link = $this->settings->setting_part('register_link','site');
		//email data
		$this->email_address = $this->settings->setting_part('email_address','email');
		$this->email_password = $this->settings->setting_part('email_password','email');
		$this->email_username = $this->settings->setting_part('email_username','email');
		$this->smtp_host = $this->settings->setting_part('smtp_host','email');
		$this->smtp_port = $this->settings->setting_part('smtp_port','email');
		$this->smtp_user = $this->settings->setting_part('smtp_user','email');
	}


	public function index() {
		$data['message'] = ''; 
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$data['title'] = 'Reset Password';
		$data['success'] = 'Please enter your email address in order to reset your password';
		$this->load->view(default_frontend_dir.'header', $data);
		$this->load->view(default_frontend_dir.'menu', $data);
		$this->load->view(default_frontend_dir.'reset-password');
		$this->load->view(default_frontend_dir.'right-sidebar', $data);	
		$this->load->view(default_frontend_dir.'footer', $data);
		
	}
	
	public function change() {
			$data['my_blog'] = $this->my_blog->blog_content();
			$data['archived_articles'] = $this->all_blog_archives->all_archives();
			$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
			$data['message'] = ''; 
			$data['success'] = ''; 
			$error = '';
			if ($this->input->post()) {
				//there is post data and so we can go ahead
				$data['title'] = 'Reset Password';
				$valid_key = $this->input->post('key'); 
				$blog_id = $this->input->post('blog_id'); 
				$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]', array('required' => 'Please enter a Password!!!'));
				$this->form_validation->set_rules('repeat_password', 'Password Confirmation', 'required|matches[password]' ,array('required' => 'Your Passwords must match!!!'));
				if ($this->form_validation->run() == FALSE) {
						//the key is valid and so we can change the password
						$data['title'] = 'Reset Password';
						$data['message'] = '<div class="alert alert-error">Please try again</div>';
						$this->load->view(default_frontend_dir.'header', $data);
						$this->load->view(default_frontend_dir.'menu', $data);
						$this->load->view(default_frontend_dir.'change-password');	
						$this->load->view(default_frontend_dir.'right-sidebar', $data);	
				}else{
					//if both keys are valid then we can update
					$valid_code_is_valid = $this->valid_code($blog_id, $valid_key); 
					if ($valid_code_is_valid == '1'){
						//we cna now update the new passwords
						$change = $this->reset_password->change();
						$data['title'] = 'Reset Password';
						$data['message'] = '<div class="alert alert-success">You have successfully reset your password. Please login</div>';	
						$this->load->view(default_frontend_dir.'header', $data);
						$this->load->view(default_frontend_dir.'menu', $data);
						$this->load->view(default_frontend_dir.'login-user');
						$this->load->view(default_frontend_dir.'right-sidebar', $data);	
					}else{
						//the key is invalid and so we post an error message
						$data['title'] = 'Reset Password';
						$data['message'] = '<div class="alert alert-error">The activation key you provided is either not valid or the validity has elapsed. Please enter a new key below</div>';
						$this->load->view(default_frontend_dir.'header', $data);
						$this->load->view(default_frontend_dir.'menu', $data);
						$this->load->view(default_frontend_dir.'reset-password');
						$this->load->view(default_frontend_dir.'right-sidebar', $data);	
						
					}
				}
			}else{
					if ( $this->uri->segment(3) && $this->uri->segment(4) ) {
						//the key is valid and so we can change the password
						$data['title'] = 'Reset Password';
						$data['success'] = 'Please enter your new Passwords below';
						$_SESSION['valid_id'] = $this->uri->segment(3);
						$_SESSION['valid_key'] = $this->uri->segment(4);
						$this->load->view(default_frontend_dir.'header', $data);
						$this->load->view(default_frontend_dir.'menu', $data);
						$this->load->view(default_frontend_dir.'change-password');
						$this->load->view(default_frontend_dir.'right-sidebar', $data);			
					}else{
						//the key is invalid and so we post an error message
						$data['title'] = 'Reset Password';
						$data['success'] = '<div class="alert alert-error">The activation key you provided is either not valid or the validity has elapsed. Please enter your email below to receive a valid activation key</div>';
						$this->load->view(default_frontend_dir.'header', $data);
						$this->load->view(default_frontend_dir.'menu', $data);
						$this->load->view(default_frontend_dir.'reset-password');
					}
			}
		$this->load->view(default_frontend_dir.'footer', $data);
	}
	
	public function reset() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['message'] = ''; 
		$data['success'] = ''; 
		$this->form_validation->set_rules('blog_email', 'Email', 'required|valid_email');
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		
		if ($this->form_validation->run() == FALSE) {
			$data['title'] = 'Reset Password';
			$data['success'] = '<div class="alert alert-error">The email you entered is invalid. Please enter a valid email address</div>';
			$this->load->view(default_frontend_dir.'header', $data);
			$this->load->view(default_frontend_dir.'menu', $data);
			$this->load->view('reset-password');
		}else{
			
			$blog_email = $this->input->post('blog_email');
			if (!$this->email_check($blog_email)) {
				$data['title'] = 'Reset Password';
				$data['success'] = '<div class="alert alert-error">The email you entered is invalid. Please enter a valid email address</div>';
				$this->load->view(default_frontend_dir.'header', $data);
				$this->load->view(default_frontend_dir.'menu', $data);
				$this->load->view(default_frontend_dir.'reset_password');
			}else{
				$data['title'] = 'Reset Password';
				if ($this->reset_password->reset_password()) {
					$blog_email = $this->input->post('blog_email');
					$blog_id = $this->reset_password->get_blog_id($blog_email);
					// send an email to the user
					$reset_password=$this->reset_password->start_reset($blog_id);
					$user_details=$this->reset_password->user_details($blog_id);
					foreach ($user_details as $row){
						$username = ''.$row['blog_fname'].' '.$row['blog_lname'].'';
						$blog_passwordkey = $row['blog_passwordkey']; 
					}
					$subject = 'Please Reset Your Password :-)';
					$message = '
					<html>
					<head>
					  <title>Reset your Password</title>
					</head>
					<body>
					  <p>Dear '.$username.'</p>
					  <p>We received a request to reset your password to do so please click the link below.</p>
					  <p><a href="'.$this->config->item('base_url').'password/change/'.$blog_id.'/'.$blog_passwordkey.'">Click here to Reset your password</a></p>
					  <p>If you ignore the message, your password won’t be changed.</p>
					  <p>If you didn’t request a password please let us know.</p>
					  <p>Kind regards</p>
					  <p>The '.site_name.' Team</p>
					
					</body>
					</html>
					';
					$config = array(
						'protocol' => 'smtp',
						'smtp_host' => $this->smtp_host,
						'smtp_port' => $this->smtp_port,
						'smtp_user' => $this->smtp_user,
						'smtp_pass' => $this->email_password,
						'wordwrap' => TRUE, 
						//'newline' => "\r\n",
						'mailtype' => 'html',
						'charset'  => 'utf-8',
						'priority' => '1'
					);
					$this->load->library('email', $config);
					$this->email->initialize($config);
					$this->email->from($this->smtp_user, $this->email_username); //$this->email->to($blog_email);
					$this->email->to($blog_email);
					
					$this->email->subject($subject);
					$this->email->message($message);
	
	
					if ($this->email->send()) {
						$data['message'] = '<div class="container">
									  <div class="alert alert-success">
										<strong>Success!</strong> We have sent you an email with a link to reset your password.
									  </div>
									</div>';
					} else {
						$_SESSION['email_error']=$this->email->print_debugger();
						$data['message'] = '<div class="container">
									  <div class="alert alert-warning">
										<strong>Error!</strong> Your email wasnt sent
									  </div>
									</div>';
					}					
					
				}
			}
       }
	$this->load->view(default_frontend_dir.'header', $data);
	$this->load->view(default_frontend_dir.'menu', $data);
	$this->load->view(default_frontend_dir.'reset-password');
	$this->load->view(default_frontend_dir.'right-sidebar', $data);
	$this->load->view(default_frontend_dir.'footer', $data);
		
	}
	public function email_check($blog_email) {
		   $email_check = $this->reset_password->email_check($blog_email);
           if ($blog_email != $email_check ){
               return FALSE;
           }else{
               return TRUE;
           }
    }

	public function valid_code($blog_id, $valid_key) {
		   $valid_code = $this->reset_password->user_details($blog_id);
           foreach($valid_code as $row ){
			   $user_id = $row['blog_id'];
			   $blog_activicationkey = $row['blog_activicationkey'];
			   $blog_passwordkey = $row['blog_passwordkey'];
			   $blog_passwordkey_date = $row['blog_passwordkey_date']; 
           }
		   if ( ($blog_passwordkey == $valid_key) && ($blog_id == $user_id) ) {
			   $valid = 1;
		   }else{
			   $valid = 0;
		   }
		   
		   return $valid;

		   
    }
	

	

}
