<?php

class Upload extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
				$this->load->model(array('authentication','galleries', 'admin_dashboard', 'uploader','my_blog','admin_settings','slideshow'));
				$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
				$this->authentication->is_loggedin($this->session->userdata('blog_id'));
				$this->load->helper('url_helper');
     }

        public function index() {
				$data['my_blog'] = $this->my_blog->blog_content();
				$data['title']='Admin Dashboard :: Upload';
				$data['error']='';
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
				$this->load->view(default_backend_dir.'admin-gallery', $data);
 				$this->load->view(default_backend_dir.'footer', $data);
      }

        public function do_upload() {		
				$data['title']='Admin Dashboard :: Upload';
				$file_name = time();
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
                $config['upload_path']          = 'uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 5000;
                $config['max_width']            = 5000;
				$config['file_name'] = $file_name;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile')) {
                    $error = array('error' => $this->upload->display_errors());
					$this->load->view(default_backend_dir.'admin-gallery', $error);
                } else {
                    $data = array('upload_data' => $this->upload->data());
					//create a thumbnail by resizing the image
					if( $this->upload->data('is_image') ) {
						$file_path = $this->upload->data('file_path');
						$raw_name = $this->upload->data('raw_name');
						$orig_name = $this->upload->data('orig_name');
						$source_image = $this->upload->data('full_path');
						$image_width = $this->upload->data('image_width');
						$image_height = $this->upload->data('image_height');
						$file_ext = $this->upload->data('file_ext');
						$this->uploader->create_thumb($width = '300', $height='200');
						$this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '300', $thumb_height='200', $file_ext);
					}
					//create a thumbnail by cropping the image
					$this->load->view(default_backend_dir.'upload-success', $data);
                }
				$this->load->view(default_backend_dir.'footer', $data);
        }
		
		public function gallery() {		
				$data['my_blog'] = $this->my_blog->blog_content();
				$data['title']='Admin Dashboard :: Upload';
				$data['error'] = '';
				$data['success'] = '';
				$data['pagetitle'] = 'Dashboard';
				$data['total_logins'] =  $this->admin_dashboard->total_logins();
				$data['total_galleries'] =  $this->admin_dashboard->total_galleries();
				$data['total_gallery_images'] =  $this->admin_dashboard->total_gallery_images();
				$data['galleries'] =  $this->galleries->all_galleries(0,25);

				$file_name = time();
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
                $config['upload_path'] = 'uploads/';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size'] = 5000;
                $config['max_width'] = 5000;
				//get the gallery name
				$gallery_name = trim(strip_tags($this->input->post('gall')));
				$gallery_name = strtolower(str_replace("'", '', $gallery_name));
				$gallery_name = strtolower(str_replace(' ', '-', $gallery_name));					
				//create a new file_name
				$config['file_name'] = $gallery_name.'_'.$file_name;
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile')) {
                    $error = array('error' => $this->upload->display_errors());
					$this->load->view(default_backend_dir.'admin-gallery', $error);
                } else {
                    $data = array('upload_data' => $this->upload->data());
					//create a thumbnail by resizing the image
					if( $this->upload->data('is_image') ) {
						$file_path = $this->upload->data('file_path');
						$raw_name = $this->upload->data('raw_name');
						$orig_name = $this->upload->data('orig_name');
						$source_image = $this->upload->data('full_path');
						$image_width = $this->upload->data('image_width');
						$image_height = $this->upload->data('image_height');
						$file_ext = $this->upload->data('file_ext');
						$this->uploader->create_thumb($width = '300', $height='200');
						$imagename = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '300', $thumb_height='200', $file_ext);
						$imagename_two = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '700', $thumb_height='600', $file_ext);
					}
					//update the database
					if ($this->admin_dashboard->create_gallery($image = $gallery_name.'_'.$file_name.$file_ext, $image_tbn=$imagename)){
						$data['success'] = '<div class="alert alert-success">SUCCESS: Your action was Successful :-)</div>';
					}else{
						$data['error'] = "<div class='alert alert-error'>ERROR: Your action wasn't Successful :-)</div>";
					}
					//create a thumbnail by cropping the image
					redirect($this->config->item('base_url').'admin/galleries/success');
					$this->load->view(default_backend_dir.'admin-galleries', $data);
                }
				$this->load->view(default_backend_dir.'footer', $data);
        }		

		public function edit_gallery() {		
				$data['my_blog'] = $this->my_blog->blog_content();
				$data['title']='Admin Dashboard :: Upload';
				$data['error'] = '';
				$data['success'] = '';
				$data['pagetitle'] = 'Dashboard';
				$data['total_logins'] =  $this->admin_dashboard->total_logins();
				$data['total_galleries'] =  $this->admin_dashboard->total_galleries();
				$data['total_gallery_images'] =  $this->admin_dashboard->total_gallery_images();
				$data['galleries'] =  $this->galleries->all_galleries(0,25);

				$file_name = time();
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
                $config['upload_path'] = 'uploads/';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size'] = 5000;
                $config['max_width'] = 5000;
				//get the gallery name
				$gallery_name = trim(strip_tags($this->input->post('gall')));
				$gallery_name = strtolower(str_replace("'", '', $gallery_name));
				$gallery_name = strtolower(str_replace(' ', '-', $gallery_name));					
				//create a new file_name
				$config['file_name'] = $gallery_name.'_'.$file_name;
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile')) {
                    $error = array('error' => $this->upload->display_errors());
					$this->load->view(default_backend_dir.'pages/gallery/edit_gallery', $error);
                } else {
                    $data = array('upload_data' => $this->upload->data());
					//create a thumbnail by resizing the image
					if( $this->upload->data('is_image') ) {
						$file_path = $this->upload->data('file_path');
						$raw_name = $this->upload->data('raw_name');
						$orig_name = $this->upload->data('orig_name');
						$source_image = $this->upload->data('full_path');
						$image_width = $this->upload->data('image_width');
						$image_height = $this->upload->data('image_height');
						$file_ext = $this->upload->data('file_ext');
						$this->uploader->create_thumb($width = '300', $height='200');
						$imagename = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '300', $thumb_height='200', $file_ext);
						$imagename_two = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '700', $thumb_height='600', $file_ext);
					}
					//update the database
					if ($this->admin_dashboard->update_gallery($image = $gallery_name.'_'.$file_name.$file_ext, $image_tbn=$imagename)){
						$data['success'] = '<div class="alert alert-success">SUCCESS: Your action was Successful :-)</div>';
					}else{
						$data['error'] = "<div class='alert alert-error'>ERROR: Your action wasn't Successful :-)</div>";
					}
					//create a thumbnail by cropping the image
					redirect($this->config->item('base_url').'admin/galleries/success');
					//$this->load->view(default_backend_dir.'admin-galleries', $data);
                }
				$this->load->view(default_backend_dir.'footer', $data);
        }		
		
		public function photos() {
				$data['my_blog'] = $this->my_blog->blog_content();
				$data['title']='Admin Dashboard :: Upload';
				$data['error'] = '';
				$data['success'] = '';
				$data['pagetitle'] = 'Dashboard';
				$data['total_logins'] =  $this->admin_dashboard->total_logins();
				$data['total_galleries'] =  $this->admin_dashboard->total_galleries();
				$data['total_gallery_images'] =  $this->admin_dashboard->total_gallery_images();
				$data['galleries'] =  $this->galleries->all_galleries();
				if ($this->input->post('edit_photo')){
					$gallery_title= $this->input->post('gal_pagename');
					$gallery_id = $this->input->post('gal_id');
					$photo_id = $this->input->post('edit_photo');
					$result =  $this->admin_dashboard->update_gallery_photos($this->input->post('edit_photo'));
					redirect($this->config->item('base_url').'admin/galleries/edit/'.$gallery_title.'/'.$gallery_id.'/'.$photo_id.'');
				}
				$file_name = time();
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
                $config['upload_path'] = 'uploads/';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size'] = 5000;
                $config['max_width'] = 5000;
				//get the gallery name
				$gallery_name = trim(strip_tags($this->input->post('photo_gall')));
				$gallery_name = strtolower(str_replace("'", '', $gallery_name));
				$gallery_name = strtolower(str_replace(' ', '-', $gallery_name));					
				//create a new file_name
				$config['file_name'] = $gallery_name.'_'.$file_name;
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile')) {
                    $error = array('error' => $this->upload->display_errors());
					$this->load->view(default_backend_dir.'admin-galleries', $error);
                } else {
                    $data = array('upload_data' => $this->upload->data());
					
					//create a thumbnail by resizing the image
					if( $this->upload->data('is_image') ) {
						$file_path = $this->upload->data('file_path');
						$raw_name = $this->upload->data('raw_name');
						$orig_name = $this->upload->data('orig_name');
						$source_image = $this->upload->data('full_path');
						$image_width = $this->upload->data('image_width');
						$image_height = $this->upload->data('image_height');
						$file_ext = $this->upload->data('file_ext');
						$this->uploader->create_thumb($width = '300', $height='200');
						$imagename = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '300', $thumb_height='200', $file_ext);
						$imagename_two = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '700', $thumb_height='600', $file_ext);
					}
					//update the database
					if ($this->admin_dashboard->create_gallery_photos($image = $gallery_name.'_'.$file_name.$file_ext, $image_tbn=$imagename)){
						//redirect the user and log the result as a success
						redirect($this->config->item('base_url').'admin/galleries/'. $this->input->post('blog_gal_title').'/'. $this->input->post('blog_gal_id').'/photo/saved');

					}else{
						redirect($this->config->item('base_url').'admin/galleries/'. $this->input->post('blog_gal_title').'/'. $this->input->post('blog_gal_id').'/photo/failed');

					}
					$data['photos'] = '';
					//create a thumbnail by cropping the image
					$this->load->view(default_backend_dir.'admin-galleries', $data);
                }
				$this->load->view(default_backend_dir.'footer', $data);
        }	
		
		
		public function bulk_photos() {
				$data['my_blog'] = $this->my_blog->blog_content();
				$data['title']='Admin Dashboard :: Upload';
				$data['error'] = '';
				$data['success'] = '';
				$data['pagetitle'] = 'Dashboard';
				$data['total_logins'] =  $this->admin_dashboard->total_logins();
				$data['total_galleries'] =  $this->admin_dashboard->total_galleries();
				$data['total_gallery_images'] =  $this->admin_dashboard->total_gallery_images();
				$data['galleries'] =  $this->galleries->latest_galleries();
				$file_name = time();
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
                $config['upload_path'] = 'uploads/';
                $upload_path = 'uploads/';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size'] = 5000;
                $config['max_width'] = 5000;
				//get default input values
				$blog_id  = $this->input->post('blog_id');
				$blog_gal_id  = $this->input->post('blog_gal_id');
				
				//get the gallery name
				$gallery_name = trim(strip_tags($this->input->post('photo_gall')));
				$gallery_name = strtolower(str_replace("'", '', $gallery_name));
				$gallery_name = strtolower(str_replace(' ', '-', $gallery_name));					
				//create a new file_name
				$config['file_name'] = $gallery_name.'_'.$file_name;
				
                $this->load->library('upload', $config);
                if (empty($_FILES['userfile']['name'][0])) {
                    $error = array('error' => $this->upload->display_errors());
					$this->load->view(default_backend_dir.'admin-galleries', $error);
                } else {
					$data['photos'] = '';
					//loop through the userfiles
					$all_created_ids=array();
					for($i = 0; $i < count($_FILES['userfile']['name']); $i++){
						$target_file = $upload_path . basename($_FILES["userfile"]["name"][$i]);
						$file_type = pathinfo($target_file,PATHINFO_EXTENSION);
						//upload the image
						$blog_tbn_image = $this->uploader->bulk_photo_uploader($path=$upload_path, $gallery_name, $file_name, $file_number=$i, $tmp_name=$_FILES['userfile']['tmp_name'][$i], $file_type, $target_file); 
						//save the image
						if ($blog_tbn_image != 'error'){
							$created_id=$this->admin_dashboard->bulk_create_gallery_photos($blog_gal_id, $blog_tbn_image);
							if ($created_id){
								$all_created_ids[]  = $created_id;
							}
						}
						
					}
					//get all the inserted ids
					$selected_ids=implode(",", $all_created_ids);
					$last_images=$this->galleries->selected_gallery_images($selected_ids);
					foreach($last_images as $image){
						$blog_tbn_id = $file_name=$image['blog_tbn_id'];
						$blog_tbn_image_tbn = $this->uploader->bulk_crop_this_image($file_path=$upload_path, $thumb_width = '300', $thumb_height='200', $file_name=$image['blog_tbn_image']); 
						$blog_tbn_image_tbn_two = $this->uploader->bulk_crop_this_image($file_path=$upload_path, $thumb_width = '700', $thumb_height='600', $file_name=$image['blog_tbn_image']); 
						if ($blog_tbn_image_tbn ){
							$this->admin_dashboard->bulk_update_gallery_photos($blog_tbn_id, $blog_tbn_image_tbn);
							$success=TRUE;
						}
					}
					if($success){
						redirect($this->config->item('base_url').'admin/galleries/'. $this->input->post('blog_gal_title').'/'. $this->input->post('blog_gal_id').'/saved');
					}else{
						redirect($this->config->item('base_url').'admin/galleries/'. $this->input->post('blog_gal_title').'/'. $this->input->post('blog_gal_id').'/failed');
					}

					//create a thumbnail by cropping the image
					$this->load->view(default_backend_dir.'admin-galleries', $data);
                }
				//admin/galleries/kids/17
				//end uploading and saving the data
				
				
				$this->load->view(default_backend_dir.'footer', $data);
        }
		
		
		public function slideshow() {		
				$data['my_blog'] = $this->my_blog->blog_content();
				$data['title']='Admin Dashboard :: Upload';
				$data['error'] = '';
				$data['success'] = '';
				$data['pagetitle'] = 'Dashboard';
				$data['total_logins'] =  $this->admin_dashboard->total_logins();
				$data['total_slideshows'] =  $this->admin_dashboard->total_slideshows();
				$data['total_slideshow_images'] =  $this->admin_dashboard->total_slideshow_images();
				$data['slideshows'] =  $this->slideshow->all_slideshows(50,0);

				$file_name = time();
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
                $config['upload_path'] = 'uploads/slideshows/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = 5000;
                $config['max_width'] = 5000;
				//get the slideshow name
				if ($this->input->post('add_blog_slide_images')){
					$slideshow_name = trim(strip_tags($this->input->post('slide_name')));
				}else{
					$slideshow_name = trim(strip_tags($this->input->post('gall')));
				}
				$slideshow_name = strtolower(str_replace("'", '', $slideshow_name));
				$slideshow_name = strtolower(str_replace(' ', '-', $slideshow_name));					
				$slideshow_name = strtolower(str_replace('-', '_', $slideshow_name));					
				//create a new file_name
				$config['file_name'] = $slideshow_name.'_'.$file_name;
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile')) {
                    $error = array('error' => $this->upload->display_errors());
					redirect($this->config->item('base_url').'admin/slideshow/index/failed');
					$this->load->view(default_backend_dir.'admin-slideshow', $error);
                } else {
                    $data = array('upload_data' => $this->upload->data());
					//create a thumbnail by resizing the image
					if( $this->upload->data('is_image') ) {
						$file_path = $this->upload->data('file_path');
						$raw_name = $this->upload->data('raw_name');
						$orig_name = $this->upload->data('orig_name');
						$source_image = $this->upload->data('full_path');
						$image_width = $this->upload->data('image_width');
						$image_height = $this->upload->data('image_height');
						$file_ext = $this->upload->data('file_ext');
						$imagename = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '500', $thumb_height='200', $file_ext);
						$imagename_two = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '900', $thumb_height='600', $file_ext);
					}
					//update the database
					if ($this->input->post('add_blog_slide_images')){
						if ($this->admin_dashboard->create_slideshow_photos($image = $slideshow_name.'_'.$file_name.$file_ext, $image_tbn=$imagename)){
							$result  = $this->input->post('slide_id');
							$slideshow_name = $this->input->post('slide_name');
							$data['success'] = '<div class="alert alert-success">SUCCESS: Your action was Successful :-)</div>';
							$success = 1;
						}else{
							$data['error'] = "<div class='alert alert-error'>ERROR: Your action wasn't Successful :-)</div>";
							$success = 0;
						}
					}else{
						if ($result=$this->admin_dashboard->create_slideshow($image = $slideshow_name.'_'.$file_name.$file_ext, $image_tbn=$imagename)){
							$data['success'] = '<div class="alert alert-success">SUCCESS: Your action was Successful :-)</div>';
							$success = 1;
					}else{
							$data['error'] = "<div class='alert alert-error'>ERROR: Your action wasn't Successful :-)</div>";
							$success = 0;
						}
					}
					//create a thumbnail by cropping the image
					if ($success == 1){
						redirect($this->config->item('base_url').'admin/slideshow/'.$slideshow_name.'/'.$result.'/saved');
					}else{
						redirect($this->config->item('base_url').'admin/slideshow/'.$slideshow_name.'/'.$result.'/failed');
					}
                }
				$this->load->view(default_backend_dir.'footer', $data);
        }		

		public function edit_slideshow() {		
		
				//if there's no data then we update and redirect the user back
				if ( empty( $_FILES['userfile']['name'] ) ) {
					$slide_id  = $this->input->post('slide_id');
					$image = $this->slideshow->slideshow_part($slide_id, 'slide_image');
					$image_tbn = $this->slideshow->slideshow_part($slide_id, 'slide_image_tbn');
					if ($this->admin_dashboard->update_slideshow($image, $image_tbn)){
						$success = "1";
						$msg = "saved";
						redirect($this->config->item('base_url').'admin/slideshow/index/success');
					}else{
						$success = "0";
						$msg = "failed";
						redirect($this->config->item('base_url').'admin/slideshow/error');
					}
					
				}
		
				$data['my_blog'] = $this->my_blog->blog_content();
				$data['title']='Admin Dashboard :: Upload';
				$data['error'] = '';
				$data['success'] = '';
				$data['pagetitle'] = 'Dashboard';
				$data['total_logins'] =  $this->admin_dashboard->total_logins();
				$data['total_slideshows'] =  $this->admin_dashboard->total_slideshows();
				$data['total_slideshow_images'] =  $this->admin_dashboard->total_slideshow_images();
				$data['slideshows'] =  $this->slideshow->all_slideshows(50,0);
				$file_name = time();
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
                $config['upload_path'] = 'uploads/slideshows/';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size'] = 5000;
                $config['max_width'] = 5000;
				//get the slideshow name

				$slideshow_name = trim(strip_tags($this->input->post('gall')));
				$slideshow_name = strtolower(str_replace("'", '', $slideshow_name));
				$slideshow_name = strtolower(str_replace(' ', '-', $slideshow_name));					
				//create a new file_name
				$config['file_name'] = $slideshow_name.'_'.$file_name;
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile')) {
                    $error = array('error' => $this->upload->display_errors());
					redirect($this->config->item('base_url').'admin/slideshow/'.$this->input->post('slide_name').'/'.$this->input->post('slide_id').'/failed');
					$this->load->view(default_backend_dir.'admin/slideshows/edit-slideshow', $error);
                } else {
                    $data = array('upload_data' => $this->upload->data());
					//create a thumbnail by resizing the image
					if( $this->upload->data('is_image') ) {
						$file_path = $this->upload->data('file_path');
						$raw_name = $this->upload->data('raw_name');
						$orig_name = $this->upload->data('orig_name');
						$source_image = $this->upload->data('full_path');
						$image_width = $this->upload->data('image_width');
						$image_height = $this->upload->data('image_height');
						$file_ext = $this->upload->data('file_ext');
						$imagename = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '500', $thumb_height='200', $file_ext);
						$imagename_two = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '900', $thumb_height='600', $file_ext);
					}
					$slide_id = $this->input->post('slide_id');
					//get the photo
					$photo=$this->slideshow->slideshow_part($slide_id, $part='slide_image');
					//update the database
					if ($this->admin_dashboard->update_slideshow($image = $slideshow_name.'_'.$file_name.$file_ext, $image_tbn=$imagename)){
						$data['success'] = '<div class="alert alert-success">SUCCESS: Your action was Successful :-)</div>';
						$success= 1;
						//delete the first photo
						unlink('uploads/slideshows/'.$photo);
						//delete the second photo
						$photo_two = explode('.',$photo);
						$photo_two = $photo_two[0].'_cropped_900_600.'.$photo_two[1];
						unlink('uploads/slideshows/'.$photo_two);
						//delete the third photo
						$photo_three = explode('.',$photo);
						$photo_three = $photo_three[0].'_cropped_500_200.'.$photo_three[1];
						unlink('uploads/slideshows/'.$photo_three);
						//delete from the database
					}else{
						$data['error'] = "<div class='alert alert-error'>ERROR: Your action wasn't Successful :-)</div>";
					}
						
					redirect($this->config->item('base_url').'admin/slideshow/index/success');
                }
				$this->load->view(default_backend_dir.'footer', $data);
        }			
		
		public function watermark_text($source_image, $wm_text, $wm_font_size, $wm_padding) {
			$config['source_image']     = APPPATH.'uploads/'.$source_image.''; 
			$config['wm_text']          = ''.$wm_text.'';
			$config['wm_type']          = 'text';
			$config['wm_font_path']     = APPPATH.'assets/fonts/arial/arial.ttf';
			$config['wm_font_size']     = $wm_font_size;
			$config['wm_font_color']    = 'ffffff';
			$config['wm_vrt_alignment'] = 'middle';
			$config['wm_hor_alignment'] = 'center';
			$config['wm_padding']       = ''.$wm_padding.'';
			$this->image_lib->initialize($config);
			
			if (!$this->image_lib->watermark()) {
				echo $this->image_lib->display_errors();
			}/*else{
				$result = TRUE;
			}
			return $result;*/
			
		}
		public function watermark_iamge($source_image, $wm_img) {
			$config['image_library']    = 'gd2';
			$config['source_image']     = 'uploads/'.$source_image.'';
			$config['wm_type']          = 'overlay';
			$config['wm_overlay_path']  = APPPATH.'assets/images/settings/'.$wm_img.'';
			$config['wm_opacity']       = 50;
			$config['wm_vrt_alignment'] = 'middle';
			$config['wm_hor_alignment'] = 'center';
			$config['wm_hor_offset'] = 20; // px
			$config['wm_vrt_offset'] = 20; // px
			$config['wm_opacity'] = 30; // 1 - 100
			
			
			$this->image_lib->initialize($config);
			
			if (!$this->image_lib->watermark()) {
				$result = $this->image_lib->display_errors();
			}else{
				$result = TRUE;
			}
			return $result;
		}
			public function create_watermark_image($source_image, $wm_img) {
				
				$source_image = 'uploads/'.$image_name;
				header('content-type: '.$image_type.'');  
				$watermark_file='"assets/images/settings/'.$wm_img.'';
				$watermark = imagecreatefrompng($watermark_file);
				list($watermark_width,$watermark_height) = getimagesize($watermark_file);
				$image = imagecreatefromjpeg($source_image);
				$size = getimagesize($source_image);
				$dest_x = $size[0] - $watermark_width - 15;
				$dest_y = $size[1] - $watermark_height - 15;
				imagecopy($image, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height);
				imagejpeg($image);
				imagedestroy($image);
				imagedestroy($watermark);				
		}
	
					
				
}
?>
