<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','my_blog','menu','register_blog','all_blog_archives','all_categories','settings','my_page','galleries'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));

		//global variables to be used in the class
		$this->about_data = $this->my_page->page_part('blog_content_description','about','global');
		$this->show_footer_widgets = $this->settings->setting_part('footer_widgets','site');
		$this->site_logo = $this->settings->setting_part('site_logo','site');
		$this->show_blog = $this->settings->setting_part('blog','site');
		$this->show_logo = $this->settings->setting_part('image_logo','site');
		$this->show_full_homepage = $this->settings->setting_part('full_homepage','site');
		$this->default_homepage = $this->settings->setting_part('default_homepage','site');
		$this->show_blog_posts = $this->settings->setting_part('blog_posts','site');
		$this->show_multiple_blogs = $this->settings->setting_part('multiple_blogs','site');
		$this->show_multiple_galleries = $this->settings->setting_part('multiple_galleries','site');
		$this->show_image_logo = $this->settings->setting_part('image_logo','site');
		$this->contacts_data = $this->settings->setting_parts('setting_name, setting_value','contacts');
		//data for the footer
		$this->latest_galleries = $this->galleries->latest_galleries();
		$this->latest_photos = $this->galleries->latest_photos();
		$this->latest_blog_posts = $this->my_blog->blog_content_with_limit(2);
		$this->archived_articles = $this->all_blog_archives->all_archives();
		$this->grouped_categories = $this->all_categories->all_grouped_categories();
		$this->blog_pages = $this->my_page->blog_pages();
		//keywords and description for site engines
		$default_description = ''.site_name.' is responsive Photo Bloging Template Powered by PHP and MySQL';
		$description = '';
		$this->description =  $description ? $description : $default_description ; 
		$default_keyword = site_name; 
		$keyword = 'Gallery, Photo Gallery, Responsive Galleries,Register';	
		$this->keywords = $keyword ? $keyword : $default_keyword; 
		//register link
		$this->register_link = $this->settings->setting_part('register_link','site');
		//email data
		$this->email_address = $this->settings->setting_part('email_address','email');
		$this->email_password = $this->settings->setting_part('email_password','email');
		$this->email_username = $this->settings->setting_part('email_username','email');
		$this->smtp_host = $this->settings->setting_part('smtp_host','email');
		$this->smtp_port = $this->settings->setting_part('smtp_port','email');
		$this->smtp_user = $this->settings->setting_part('smtp_user','email');
	}


	public function index() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$url = $this->config->item('base_url');
		$data['url'] = $url;	
		$data['title'] = 'Register Blog';	
		
		$this->form_validation->set_rules('blog_username', 'Username', 'trim|alpha_numeric_spaces|callback_username_check|min_length[5]|max_length[12]', array('required' => 'Please enter a Username!!!'));
        $this->form_validation->set_rules('blog_password', 'Password', 'trim|required|min_length[8]', array('required' => 'Please enter a Password!!!'));
        $this->form_validation->set_rules('blog_password_confirm', 'Password Confirmation', 'required|matches[blog_password]' ,array('required' => 'Your Passwords must match!!!'));
		$this->form_validation->set_rules('blog_email', 'Email', 'trim|callback_email_check|valid_email|is_unique[blog_users.blog_email]', array('required' => 'Please enter a valid Email Address!!!'));
		$this->form_validation->set_rules('blog_fname', 'First Name', 'trim|alpha|required', array('required' => 'Please enter your First Name!!!'));
		$this->form_validation->set_rules('blog_lname', 'Last Name', 'trim|alpha|required', array('required' => 'Please enter your Last Name!!!'));
        $this->form_validation->set_rules('blog_pagetitle', 'Blog Title', 'trim|required', array('required' => 'Please enter a title for your blog!!!'));
        $this->form_validation->set_rules('blog_description', 'Blog Description', 'trim|required', array('required' => 'Please enter a short description about your blog'));
		

		if ($this->form_validation->run() == FALSE) {
			//iof its from the admin area then we use an admin template
			if($this->input->post('registered_from') ){
				$data['title']= 'Admin Dashboard';
				$this->load->view('templates/backend/header', $data);
				$this->load->view('templates/backend/menu', $data);	
				redirect($url.'admin/blogs/create');
				$this->load->view(default_frontend_dir.'right-sidebar', $data);			
			}else{
				$this->load->view(default_frontend_dir.'header', $data);
				$this->load->view(default_frontend_dir.'menu', $data);
				$this->load->view(default_frontend_dir.'register-blog');
				$this->load->view(default_frontend_dir.'right-sidebar', $data);
			}
			
           
        }else{
			//the form validation is successfully therefore lets upload the data
			$data['register'] = $this->register_blog->register();	
			if($this->input->post('registered_from') ){
				$data['success'] = 'Your acction was successfull';
				redirect($url.'admin/index/success');
			}else{
				$this->load->view(default_frontend_dir.'header', $data);
				$this->load->view(default_frontend_dir.'menu', $data);
				$this->load->view(default_frontend_dir.'register-blog-success');
				$this->load->view(default_frontend_dir.'right-sidebar', $data);
			}
        }
		
		
		$this->load->view(default_frontend_dir.'footer', $data);
	}

	public function username_check($str) {
		   $username_check = $this->register_blog->username_check($str);
           if ($str == $username_check ){
               $this->form_validation->set_message('username_check', 'SORRY: The {field} field cannot be "'.$username_check.'". The username is already being used :-(');
               return FALSE;
           }else{
               return TRUE;
           }
    }

	public function email_check($str) {
		   $email_check = $this->register_blog->email_check($str);
           if ($str == $email_check ){
               $this->form_validation->set_message('email_check', 'SORRY: The {field} field cannot be "'.$email_check.'". The Email is already in use :-(');
               return FALSE;
           }else{
               return TRUE;
           }
    }

}
