<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','unit_test'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','menu','my_blog','outbound','article','all_blog_archives', 'all_categories','my_page','settings','galleries'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));

		//global variables to be used in the class
		$this->about_data = $this->my_page->page_part('blog_content_description','about','global');
		$this->show_footer_widgets = $this->settings->setting_part('footer_widgets','site');
		$this->site_logo = $this->settings->setting_part('site_logo','site');
		$this->show_blog = $this->settings->setting_part('blog','site');
		$this->show_logo = $this->settings->setting_part('image_logo','site');
		$this->show_full_homepage = $this->settings->setting_part('full_homepage','site');
		$this->default_homepage = $this->settings->setting_part('default_homepage','site');
		$this->show_blog_posts = $this->settings->setting_part('blog_posts','site');
		$this->show_multiple_blogs = $this->settings->setting_part('multiple_blogs','site');
		$this->show_multiple_galleries = $this->settings->setting_part('multiple_galleries','site');
		$this->show_image_logo = $this->settings->setting_part('image_logo','site');
		$this->contacts_data = $this->settings->setting_parts('setting_name, setting_value','contacts');
		//data for the footer
		$this->latest_galleries = $this->galleries->latest_galleries();
		$this->latest_photos = $this->galleries->latest_photos();
		$this->latest_blog_posts = $this->my_blog->blog_content_with_limit(2);
		$this->archived_articles = $this->all_blog_archives->all_archives();
		$this->grouped_categories = $this->all_categories->all_grouped_categories();
		$this->blog_pages = $this->my_page->blog_pages();
		$this->profile = $this->my_blog->all_my_blog_details($this->uri->segment(3));
		//keywords and description for site engines
		$default_description = ''.site_name.' is responsive Photo Bloging Template Powered by PHP and MySQL';
		if ($this->uri->segment(4)){
			$description = strip_tags(substr(html_entity_decode($this->my_page->page_title('blog_content_description',$this->uri->segment(4))), 0,200));
		}else{
			$description = '';
		}
		$this->description =  $description ? $description : $default_description ; 
		$default_keyword = site_name; 
		if ($this->uri->segment(4)){
			$keyword = $this->my_page->page_title('blog_content_pagetitle',$this->uri->segment(4), $this->my_blog->blog_part('blog_fname',$this->uri->segment(3)) .' '.$this->my_blog->blog_part('blog_lname',$this->uri->segment(3)));	
		}else{
		$keyword = 'Gallery, Photo Gallery, Responsive Galleries,';	
		}
		$this->keywords = $keyword ? $keyword : $default_keyword; 
		//register link
		$this->register_link = $this->settings->setting_part('register_link','site');
		//email data
		$this->email_address = $this->settings->setting_part('email_address','email');
		$this->email_password = $this->settings->setting_part('email_password','email');
		$this->email_username = $this->settings->setting_part('email_username','email');
		$this->smtp_host = $this->settings->setting_part('smtp_host','email');
		$this->smtp_port = $this->settings->setting_part('smtp_port','email');
		$this->smtp_user = $this->settings->setting_part('smtp_user','email');	}


	public function index() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$blog_id=$this->uri->segment(3,0);
		$blog_title=$this->all_blogs->my_blog_title($blog_id);
		$data['my_blog_content'] = $this->menu->my_blog_content();
		$data['blog_id'] = $blog_id;	
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$data['my_page'] = $this->my_page->my_page();
		$data['title'] =  $this->my_page->page_title('blog_content_pagetitle',$this->uri->segment(4));	
		$this->load->view(default_frontend_dir.'header', $data);
		$this->load->view(default_frontend_dir.'menu', $data);
		$this->load->view(default_frontend_dir.'page', $data);
		$this->load->view(default_frontend_dir.'right-sidebar', $data);
		$this->load->view(default_frontend_dir.'footer', $data);
	}

	public function about() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$data['my_blog_content'] = $this->menu->my_blog_content();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$data['about_page'] = $this->my_page->about_page();
		$data['title'] = site_name.' :: About';	
		$this->load->view(default_frontend_dir.'header', $data);
		$this->load->view(default_frontend_dir.'menu', $data);
		$this->load->view(default_frontend_dir.'about', $data);
		$this->load->view(default_frontend_dir.'right-sidebar', $data);
		$this->load->view(default_frontend_dir.'footer', $data);
	}

	public function details() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$blog_id=$this->uri->segment(3,0);
		$blog_title=$this->all_blogs->my_blog_title($blog_id);
		$data['blog_id'] = $blog_id;	
		$data['my_blog_content'] = $this->menu->my_blog_content();
		$data['category_articles'] = $this->all_categories->all_category_articles();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		if( $this->uri->segment(3) == '0'  ){
			$data['title'] =  ucwords( strtolower( $blog_title.str_replace('-', ' ', $this->uri->segment(4)) ) );
		}else{
			if ($this->unit->run($this->uri->segment(3), 'is_int') ) {
				$data['title'] =  ucwords( strtolower( $blog_title  ) );
			}else{
				$data['title'] =  ucwords( strtolower( $blog_title.str_replace('-', ' ', $this->uri->segment(3)) ) );
			}
		}
		$this->load->view(default_frontend_dir.'header', $data);
		$this->load->view(default_frontend_dir.'menu', $data);
		$this->load->view(default_frontend_dir.'all-categories', $data);
		$this->load->view(default_frontend_dir.'right-sidebar', $data);
		$this->load->view(default_frontend_dir.'footer', $data);
	}




}
