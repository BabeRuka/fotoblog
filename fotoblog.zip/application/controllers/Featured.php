<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Featured extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation','email'));
		$this->load->library('image_lib');
		$this->load->helper(array('url','form','html','url_helper','email'));
		$this->load->model(array('my_blog','login_user','reset_password','admin_dashboard','articles','all_blog_archives','all_categories', 'all_tags','reset_password', 'my_page','uploader','settings','galleries'));
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));

		//global variables to be used in the class
		$this->about_data = $this->my_page->page_part('blog_content_description','about','global');
		$this->show_footer_widgets = $this->settings->setting_part('footer_widgets','site');
		$this->site_logo = $this->settings->setting_part('site_logo','site');
		$this->show_blog = $this->settings->setting_part('blog','site');
		$this->show_logo = $this->settings->setting_part('image_logo','site');
		$this->show_full_homepage = $this->settings->setting_part('full_homepage','site');
		$this->default_homepage = $this->settings->setting_part('default_homepage','site');
		$this->show_blog_posts = $this->settings->setting_part('blog_posts','site');
		$this->show_multiple_blogs = $this->settings->setting_part('multiple_blogs','site');
		$this->show_multiple_galleries = $this->settings->setting_part('multiple_galleries','site');
		$this->show_image_logo = $this->settings->setting_part('image_logo','site');
		$this->contacts_data = $this->settings->setting_parts('setting_name, setting_value','contacts');
		//data for the footer
		$this->latest_galleries = $this->galleries->latest_galleries();
		$this->latest_photos = $this->galleries->latest_photos();
		$this->latest_blog_posts = $this->my_blog->blog_content_with_limit(2);
		$this->archived_articles = $this->all_blog_archives->all_archives();
		$this->grouped_categories = $this->all_categories->all_grouped_categories();
		$this->blog_pages = $this->my_page->blog_pages();
		//keywords and description for site engines
		$default_description = ''.site_name.' is responsive Photo Bloging Template Powered by PHP and MySQL';
		$description = '';
		$this->description =  $description ? $description : $default_description ; 
		$default_keyword = site_name; 
		$keyword = 'Gallery, Photo Gallery, Responsive Galleries';	
		$this->keywords = $keyword ? $keyword : $default_keyword; 
		//register link
		$this->register_link = $this->settings->setting_part('register_link','site');
		//email data
		$this->email_address = $this->settings->setting_part('email_address','email');
		$this->email_password = $this->settings->setting_part('email_password','email');
		$this->email_username = $this->settings->setting_part('email_username','email');
		$this->smtp_host = $this->settings->setting_part('smtp_host','email');
		$this->smtp_port = $this->settings->setting_part('smtp_port','email');
		$this->smtp_user = $this->settings->setting_part('smtp_user','email');
	}

	public function index() {
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$data['base_url'] = $this->config->item('base_url');
		$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
		$data['title'] = 'Upload Featured Imag';
		$data['error'] = '';
		$data['success'] = 'Please upload your new Featured Imag using the form below';
		$this->load->view(default_backend_dir.'header', $data);
		$this->load->view(default_backend_dir.'menu', $data);
		$this->load->view(default_backend_dir.'featured-image');
		$this->load->view(default_backend_dir.'footer', $data);
	}
	public function photos() {
				$data['error'] = '';
				$data['success'] = '';
				$file_name = time();
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
                $config['upload_path'] = './assets/images/articles/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg|JPG';
                $config['max_size'] = 10000;
                $config['max_width'] = 10000;
				//get the gallery name
				$article_id=$this->uri->segment(3);
				//create a new file_name
				$config['file_name'] = $article_id.'_'.$file_name;
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile')) {
					$data['base_url'] = $this->config->item('base_url');
					$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
					$data['title'] = 'Upload Featured Imag';	
					$data['success'] = 'There was an error uploading your image';
                    $error = array('error' => $this->upload->display_errors());
                    $this->load->view(default_backend_dir.'featured-image', $error);
					$this->load->view(default_backend_dir.'footer', $data);
                } else {
                    $data = array('upload_data' => $this->upload->data());
					
					//create a thumbnail by resizing the image
					if( $this->upload->data('is_image') ) {
						$file_path = $this->upload->data('file_path');
						$raw_name = $this->upload->data('raw_name');
						$orig_name = $this->upload->data('orig_name');
						$source_image = $this->upload->data('full_path');
						$image_width = $this->upload->data('image_width');
						$image_height = $this->upload->data('image_height');
						$file_ext = $this->upload->data('file_ext');
						$imagename = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '300', $thumb_height='200', $file_ext);
						$imagename_two = $this->uploader->crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width = '700', $thumb_height='600', $file_ext);
					}
					//update the database
					if ( $this->articles->update_featured($featured_image = $this->upload->data('file_name')) ){
						//redirect the user and log the result as a success
						redirect($this->config->item('base_url').'admin/articles/success');

					}else{
						redirect($this->config->item('base_url').'admin/articles/failed');

					}
                }
				$this->load->view(default_backend_dir.'footer', $data);
    }	
		

	public function resize_image($source_image, $file_name, $width, $height) {

		$this->load->library('image_lib');
	
		$img_cfg['image_library'] = 'gd2';
		$config['source_image'] = $source_image;
		$img_cfg['maintain_ratio'] = TRUE;
		$img_cfg['create_thumb'] = TRUE;
		$img_cfg['new_image'] = $file_name;
		$img_cfg['quality'] = 100;
		$img_cfg['width'] = $width;
		$img_cfg['height'] = $height;

		$this->image_lib->resize();

	}	
	

}
