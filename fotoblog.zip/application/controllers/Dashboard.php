<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation','image_lib'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('authentication','all_blogs','articles','comments','my_blog','menu','login_user','admin_dashboard','register_blog','all_categories', 'all_tags','reset_password', 'my_page'));
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
		$this->authentication->is_loggedin($this->session->userdata('blog_id'));
        $this->load->helper('url_helper');
		
	}

	public function index() {
		$data['title'] = 'Welcome to the Admin Dashboard';
		$data['pagetitle'] = 'Dashboard';
		$data['total_logins'] =  $this->admin_dashboard->total_logins();
		$data['all_blogs'] =  $this->all_blogs->getAllBlogContentRows();
		$data['total_comments'] =  $this->admin_dashboard->total_comments();
		$data['total_pages'] =  $this->admin_dashboard->total_pages();
		$data['total_articles'] =  $this->admin_dashboard->total_articles();
		$data['total_galleries'] =  $this->admin_dashboard->total_galleries();
		$data['total_gallery_images'] =  $this->admin_dashboard->total_gallery_images();
		$data['mysql_version'] =  $this->admin_dashboard->mysql_version();
		$data['error'] = '';
		$this->load->view(default_backend_dir.'header', $data);
		$this->load->view(default_backend_dir.'menu', $data);
		$this->load->view(default_backend_dir.'admin-dashboard', $data);
		$this->load->view(default_backend_dir.'footer', $data);
	}
}
