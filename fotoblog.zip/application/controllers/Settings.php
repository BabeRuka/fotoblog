<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent','form_validation','image_lib'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('authentication','all_blogs','articles','comments','my_blog','menu','login_user','admin_dashboard','register_blog','all_categories', 'all_tags','reset_password', 'my_page','admin_settings','uploader'));
		$this->load->model(array('galleries','uploader'));
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));
		$this->authentication->is_loggedin($this->session->userdata('blog_id'));
        $this->load->helper('url_helper');
		
	}


	public function index() {
			if ($this->session) {
				$data['settings'] = $this->admin_settings->all_settings();
				$data['email'] = $this->admin_settings->some_settings($setting_type='email');
				$data['site'] = $this->admin_settings->some_settings($setting_type='site');
				$data['contacts'] = $this->admin_settings->some_settings($setting_type='contacts');

				$data['base_url'] = $this->config->item('base_url');
				$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
				$data['success'] = '';
				$data['error'] = '';
				$data['title'] = 'Admin Settings';
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
				$this->load->view(default_backend_dir.'admin-settings');
				$this->load->view(default_backend_dir.'footer', $data);
			}else{
				redirect('/login/index');
			}
	}
	public function edit() {
			if ($this->session) {
				$data['settings'] = $this->admin_settings->all_settings();
				$data['email'] = $this->admin_settings->some_settings($setting_type='email');
				$data['site'] = $this->admin_settings->some_settings($setting_type='site');
				$data['contacts'] = $this->admin_settings->some_settings($setting_type='contacts');
				$data['base_url'] = $this->config->item('base_url');
				$data['admin_url'] = $this->config->item('base_url').'assets/admin/';
				$data['success'] = '';
				$data['error'] = '';
				if ($this->input->post()){
					foreach ($this->input->post() as $k => $v){
						if ($this->input->post('site_settings')){
							$replace='site_';
						}else if ($this->input->post('email_settings')){
							$replace='email_';							
						}else if ($this->input->post('contact_settings')){
							$replace='contact_';							
						}
						$setting_id = str_replace("".$replace."","",$k); 
						$setting_value = $v[0]; 
						$result = $this->admin_settings->update_settings($setting_id, $setting_value);
					}
					if ($_FILES){
						foreach ($_FILES as $k => $v){
							if ($_POST['site_settings']){
								$replace='site_';
							}else if ($_POST['email_settings']){
								$replace='email_';							
							}else if ($_POST['contact_settings']){
								$replace='contact_';							
							}
							$setting_id = str_replace("".$replace."","",$k); 
							$setting_value = $k;
							if (!empty($_FILES[$setting_value]['name'][0])){
								$result=$this->uploader->bulk_upload($image_name=$_FILES[$setting_value]['name'][0], $tmp_name= $_FILES[$setting_value]['tmp_name'][0], $error= $_FILES[$setting_value]['error'][0]); 
								if ($result){ 
									$result = $this->admin_settings->update_settings($setting_id, $setting_value=$result); 
								}
							}
						}
					}	
				
					if ($result){
						$data['success'] = '<div class="container">
								  <div class="alert alert-success">
									<strong>Success!</strong> Your action was successful.
								  </div>
								</div>';
					}else{
						$data['success'] = '<div class="container">
								  <div class="alert alert-warning">
									<strong>Error!</strong> Your action wasn’t successful. Please try again or contact your administrator.
								  </div>
								</div>';
					}
				}
				
				
				
				
				$data['title'] = 'Admin Settings';
				$this->load->view(default_backend_dir.'header', $data);
				$this->load->view(default_backend_dir.'menu', $data);
				$this->load->view(default_backend_dir.'admin-settings');
				$this->load->view(default_backend_dir.'footer', $data);
			}else{
				redirect('/login/index');
			}
	}
	 

}
