<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class All_archives extends CI_Controller {
	 
    public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		$CI->load->library(array('session','user_agent'));
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('all_blogs','comments','my_blog','outbound','article','all_blog_archives','all_categories','galleries','settings','my_page'));
        $this->load->helper('url_helper');
		$this->session->set_userdata('referred_from', $this->config->item('base_url').$this->input->server('REDIRECT_QUERY_STRING'));

		//global variables to be used in the class
		$this->about_data = $this->my_page->page_part('blog_content_description','about','global');
		//settings data
		$this->show_footer_widgets = $this->settings->setting_part('footer_widgets','site');
		$this->site_logo = $this->settings->setting_part('site_logo','site');
		$this->show_blog = $this->settings->setting_part('blog','site');
		$this->show_logo = $this->settings->setting_part('image_logo','site');
		$this->show_full_homepage = $this->settings->setting_part('full_homepage','site');
		$this->default_homepage = $this->settings->setting_part('default_homepage','site');
		$this->show_blog_posts = $this->settings->setting_part('blog_posts','site');
		$this->show_multiple_blogs = $this->settings->setting_part('multiple_blogs','site');
		$this->show_multiple_galleries = $this->settings->setting_part('multiple_galleries','site');
		$this->show_image_logo = $this->settings->setting_part('image_logo','site');
		$this->contacts_data = $this->settings->setting_parts('setting_name, setting_value','contacts');
		$this->show_homepage_slide = $this->settings->setting_part('homepage_slide','site');
		//data for the footer
		$this->latest_galleries = $this->galleries->latest_galleries();
		$this->latest_photos = $this->galleries->latest_photos();
		$this->latest_blog_posts = $this->my_blog->blog_content_with_limit(2);
		$this->archived_articles = $this->all_blog_archives->all_archives();
		$this->grouped_categories = $this->all_categories->all_grouped_categories();
		$this->blog_pages = $this->my_page->blog_pages();
		//keywords and description for site engines
		$default_description = ''.site_name.' is responsive Photo Bloging Template Powered by PHP and MySQL';
		$description = '';
		$this->description =  $description ? $description : $default_description ; 
		$default_keyword = site_name.' Archives'; 
		$keyword = site_name.',Archives for ' .$this->uri->segment(4).' ' .$this->uri->segment(3).','.$this->uri->segment(3).'-' .$this->uri->segment(4); 
		$this->keywords = $keyword ? $keyword : $default_keyword; 
		//register link
		$this->register_link = $this->settings->setting_part('register_link','site');
		//email data
		$this->email_address = $this->settings->setting_part('email_address','email');
		$this->email_password = $this->settings->setting_part('email_password','email');
		$this->email_username = $this->settings->setting_part('email_username','email');
		$this->smtp_host = $this->settings->setting_part('smtp_host','email');
		$this->smtp_port = $this->settings->setting_part('smtp_port','email');
		$this->smtp_user = $this->settings->setting_part('smtp_user','email');
	}


	public function index() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['footer_links'] = $this->galleries->latest_galleries();
		$blog_title = site_name .' Archives'; //
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$data['title'] = $blog_title;	
		$this->load->view(default_frontend_dir.'header', $data);
		$this->load->view(default_frontend_dir.'menu', $data);
		$this->load->view(default_frontend_dir.'all-archives', $data);

		$this->load->view(default_frontend_dir.'footer', $data);
	}


	public function article() {
		$data['my_blog'] = $this->my_blog->blog_content();
		$data['footer_links'] = $this->galleries->latest_galleries();
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$blog_title = site_name .' Archives for ' .$this->uri->segment(4).'-' .$this->uri->segment(3); 
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['archives'] = $this->all_blog_archives->all_archived_articles();
		$data['title'] = $blog_title;	
		$this->load->view(default_frontend_dir.'header', $data);
		$this->load->view(default_frontend_dir.'menu', $data);
		$this->load->view(default_frontend_dir.'all-archives', $data);
		$this->load->view(default_frontend_dir.'right-sidebar', $data);
		$this->load->view(default_frontend_dir.'footer', $data);
	}


	public function all() {
		$data['footer_links'] = $this->galleries->latest_galleries();
		$blog_title = site_name .' Archives'; //
		$data['archives'] = 0;
		$data['archived_articles'] = $this->all_blog_archives->all_archives();
		$data['grouped_categories'] = $this->all_categories->limited_grouped_categories(5);
		$data['title'] = $blog_title;	
		$this->load->view(default_frontend_dir.'header', $data);
		$this->load->view(default_frontend_dir.'menu', $data);
		$this->load->view(default_frontend_dir.'all-archives', $data);

		$this->load->view(default_frontend_dir.'footer', $data);
	}

}
