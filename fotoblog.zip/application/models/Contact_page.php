<?php 
class Contact_page extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function all_contact_pages(){
	
				$query = $this->db->query( "  SELECT * FROM blog_content 
				WHERE blog_content_type = 'contact' 
				AND blog_content_scope = 'global'  " ) ;
				
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
		}	
		
		function contact_page($content_id){
	
				$query = $this->db->query( "  SELECT * FROM `blog_content` 
				WHERE `blog_content_id`='".$content_id."' " ) ;
				
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
		}	
		
			
			
	}