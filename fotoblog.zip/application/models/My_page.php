<?php 
class My_page extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function page_title($key,$page_id){
	
				$query = $this->db->query( " SELECT ".$key." 
				FROM blog_content 
				WHERE blog_content_id='".$page_id."'  " ) ;
				if ($query){
					$row = $query->row();
					return $row->$key;
				}else{
					return false;
				}
		}
		
		function page_part($key,$part,$scope){
	
				$query = $this->db->query( " SELECT ".$key." 
				FROM blog_content 
				WHERE blog_content_type='".$part."'
				AND blog_content_scope='".$scope."'  " ) ;
				if ($query){
					$row = $query->row();
					return $row->$key;
				}else{
					return false;
				}
		}
		function about_page(){

			$query = $this->db->query( " SELECT * FROM blog_content
			WHERE blog_content_type='about'
			AND blog_content_scope='global' " ) ;
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		}

		function blog_pages(){

			$query = $this->db->query( " SELECT * FROM
			blog_content WHERE
			blog_content_scope != 'global'
			AND blog_content_type = 'page'
			ORDER BY blog_content_page ASC
			LIMIT 0 , 10 " ) ;
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		}
				
		function my_page(){

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$page_id = $this->uri->segment(4);
			$query = $this->db->query( " SELECT * FROM blog_content WHERE blog_content_id = '".$page_id."' " ) ;
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		}
				
		function all_pages(){

			$query = $this->db->query( " SELECT * FROM blog_content ORDER BY blog_content_id DESC" ) ;
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		}
				
		function selected_page($blog_content_id){

			$query = $this->db->query( " SELECT * FROM blog_content WHERE blog_content_id = '".$blog_content_id."' " ) ;
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		}				
		function one_page($blog_id){

			$query = $this->db->query( " SELECT * FROM blog_content WHERE blog_id = '".$blog_id."' " ) ;
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		}
				
		function create_page(){
			
			$blog_id = $this->input->post('blog_id');
			$blog_content_description = htmlspecialchars($this->db->escape_str($this->input->post('blog_content_description')));
			$blog_content_page = $this->input->post('blog_content_page');
			$blog_content_pagetitle = htmlspecialchars($this->db->escape_str($this->input->post('blog_content_pagetitle')));
			$date =  date('Y-m-d H:m:s');
	
			$blog_content_page = trim(strip_tags($this->input->post('blog_content_description')));
			$blog_content_page = strtolower(str_replace("'", '', $blog_content_page));
			// Strip HTML Tags
			$blog_content_page = strip_tags($blog_content_page);
			// Clean up things like &amp;
			$blog_content_page = html_entity_decode($blog_content_page);
			// Strip out any url-encoded stuff
			$blog_content_page = urldecode($blog_content_page);
			// Replace non-AlNum characters with space
			$blog_content_page = preg_replace('/[^A-Za-z0-9]/', ' ', $blog_content_page);
			// Replace Multiple spaces with single space
			$blog_content_page = preg_replace('/ +/', ' ', $blog_content_page);
			// Trim the string of leading/trailing space
			$blog_content_page = trim($blog_content_page);
			$blog_content_page = strtolower(str_replace(' ', '-', $blog_content_page));
			
			$query = $this->db->query( "INSERT INTO `blog_content` ( `blog_id`, `blog_content_description`, `blog_content_page`, `blog_content_pagetitle`,
			 `blog_content_date` )
			 VALUES ( '".$blog_id."', '".$blog_content_description."', '".$blog_content_page."', '".$blog_content_pagetitle."', '".$date."' )  " ) ;
			
			if ($query){
				return TRUE;
			}else{
				return FALSE;
			}
		}	
}