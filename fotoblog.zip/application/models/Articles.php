<?php 
class Articles extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function getBlogID() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
				return $blog;
			}else{
				return false;
			}
			
			
		}

		function getArticleID() {

			if ($this->uri->segment(4)){
				$blog = $this->uri->segment(4);
			}
			if ($this->uri->segment(3)){
				return $blog;
			}else{
				return false;
			}
			
			
		}
		function get_category($article_id){
			
			$query = $this->db->query(" SELECT blog_articles_catergory
			FROM blog_articles 
			WHERE blog_articles_id = '".$article_id."'  " );
			$row = $query->row();
			if (isset($row)) {
				$blog_articles_catergory = $row->blog_articles_catergory; 
			}else{
				$blog_articles_catergory = ''; 
			}

			return $blog_articles_catergory;
		}


		function get_my_articles($blog_id){
			
			$query = $this->db->query(" SELECT * FROM blog_users, blog_articles, blog_categories
			WHERE blog_users.blog_id = blog_articles.blog_id
			AND blog_categories.article_id =  blog_articles.blog_articles_id
			AND blog_users.blog_id ='".$blog_id."' " );
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		}
		function get_article($article_id){
			
			$query = $this->db->query(" SELECT * FROM blog_users
			INNER JOIN blog_articles ON blog_users.blog_id = blog_articles.blog_id
			LEFT JOIN blog_categories ON blog_categories.article_id =  blog_articles.blog_articles_id
			WHERE blog_articles_id ='".$article_id."' " );
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		}		
		function all_articles(){

			$query = $this->db->query(" SELECT * FROM
			blog_users,
			blog_articles
			WHERE blog_users.blog_id = blog_articles.blog_id
			ORDER BY blog_articles.blog_articles_id DESC " );
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		}
		function get_blog_id_from_article($article_id){
			
			$query = $this->db->query(" SELECT blog_users.blog_id 
			FROM blog_users
			INNER JOIN blog_articles ON blog_articles.blog_id = blog_users.blog_id
			WHERE blog_articles.blog_articles_id = '".$article_id."' " );
			if ($query){
				$row = $query->row();
				$blog_id = $row->blog_id; 
				return $blog_id;
			}else{
				return false;
			}

		}		
		function get_article_title($result){
			
			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query(" SELECT * FROM blog_users, blog_articles 
			WHERE blog_users.blog_id = '".$blog_id."'  
			AND blog_articles.blog_articles_id = '".$article_id."' " );
			$row = $query->row();
			if($result = 'blog_title'){
				$title = $row->blog_pagetitle; 
			}else{
				$aarticle_title = $row->blog_articles_pagetitle; 
			}
			return $title;
		}
		
	function create_article(){
			
			$activationKey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand();
			$date =  date('Y-m-d H:m:s');
			$blog_pagetitle = $this->input->post('article_title');
			$blog_pagetitle = str_replace("'", " ", $blog_pagetitle);
			$blog_pagetitle = str_replace('"', " ", $blog_pagetitle);
			$blog_pagetitle = str_replace(" ", "-", $blog_pagetitle);
			$blog_pagetitle = str_replace("_", "-", $blog_pagetitle);
			if  ($this->session->set_userdata('feature_image')){
				$blog_articles_image=$this->session->set_userdata('feature_image');
			}else{
				$blog_articles_image=NULL;
			}

			$data = array(
				 'blog_id' => $this->input->post('blog_id'), 
				 'blog_articles_catergory' => $this->input->post('article_catergory'), 
				 'blog_articles_shortdesc' => $this->input->post('article_shortdescription'), 
				 'blog_articles_description' => $this->input->post('article_description'), 
				 'blog_articles_page' => $blog_pagetitle, 
				 'blog_articles_pagetitle' => $this->input->post('article_title'), 
				 'blog_articles_image' => $blog_articles_image, 
				 'blog_article_date' => $date, 
				 'blog_articles_level' => 'Yet to be Administered' 
			);

			$this->db->insert('blog_articles', $data);
			
			return $this->db->insert_id();
			
		}	
		
	function update_featured($featured_image){

			$query = $this->db->query( " UPDATE `blog_articles`
			SET `blog_articles_image` = '".$featured_image."' 
			WHERE (`blog_articles_id` = '".$this->input->post('blog_articles_id')."') " );
			if ($query){
				return true;
			}else{
				return false;
			}
			
		}		
}