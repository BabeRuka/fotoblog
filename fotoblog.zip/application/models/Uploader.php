<?php 
class Uploader extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function create_thumb($width, $height) {
			$config['image_library'] = 'gd2';
			$config['source_image'] = $this->upload->data('full_path');
			$config['create_thumb'] = TRUE;
			$config['maintain_ratio'] = TRUE;
			$config['width']         = $width;
			$config['height']       = $height;
			$config['thumb_marker'] = '_'.$width.'_'.$height.'';
			$this->load->library('image_lib', $config);
			$this->image_lib->resize();
			if ( ! $this->image_lib->resize()) {
				$msg = $this->image_lib->display_errors();
			}else{
				$msg = 'SUCCESS';
			}
			
			return $msg;
		}
		function create_image_info($file_type){
			switch ($file_type) {
				case IMAGETYPE_GIF:
					$image = imagecreatefromgif($_FILES['userfile']['tmp_name']) ;
					break;
				case IMAGETYPE_JPEG:
					$image = imagecreatefromjpeg($_FILES['userfile']['tmp_name']) ;
					break;
				case IMAGETYPE_PNG:
					$image = imagecreatefrompng($_FILES['userfile']['tmp_name']) ;
					break;
			}
			return $image;
		}
		
		function create_image($file_ext){
			 switch ($file_ext) {
				
				case IMAGETYPE_GIF:
					 $image = imagegif($thumb, $filename);
				break;
				
				case IMAGETYPE_JPEG:
					 $image = imagejpeg($thumb, $filename, 100);
				break;
				
				case IMAGETYPE_PNG:
					 $image = imagepng($thumb, $filename);
				break;
			}
			return $image;
		}
		function watermark_image($source_image, $watermark_text){
		
			$config['source_image'] = $source_image;
			$config['wm_text'] = $watermark_text;
			$config['wm_type'] = 'text';
			$config['wm_font_path'] = './system/fonts/texb.ttf';
			$config['wm_font_size'] = '16';
			$config['wm_font_color'] = 'ffffff';
			$config['wm_vrt_alignment'] = 'center';
			$config['wm_hor_alignment'] = 'center';
			$config['wm_padding'] = '20';
			
			$this->image_lib->initialize($config);
			
			$this->image_lib->watermark();
			
		}
		public function bulk_photo_uploader($path, $gallery_name, $file_name, $file_number, $tmp_name, $file_type, $target_file) { 
			$file_name = $gallery_name.'_'.$file_name.'_00'.$file_number;
			$imagename = $file_name.'.'.$file_type.'';
			$upload = 0;

			switch ($file_type) {
				case 'gif':
					$image = imagecreatefromgif($tmp_name);
					imagegif($image, $path . '/' . $imagename);
					$upload = 1;
				break;
				case 'jpg':
					$image = imagecreatefromjpeg($tmp_name);
					imagejpeg($image, $path . '/' . $imagename, 100);
					$upload = 1;
				break;
				case 'jpeg':
					$image = imagecreatefromjpeg($tmp_name);
					imagejpeg($image, $path . '/' . $imagename, 100);
					$upload = 1;
				break;
				case 'png':
					$image = imagecreatefrompng($tmp_name);
					imagepng($image, $path . '/' . $imagename);
					$upload = 1;
				break;
			}
			if ($upload == 1){
				$result = $imagename; 
			}else{
				$result = 'error'; 
			}
			imagedestroy($image);
			
			return $result; 
		}

		public function bulk_upload($image_name, $tmp_name) {
				 
				$image_path  = 'assets\images\settings';
				list($width, $height, $type, $attr) = getimagesize($tmp_name);
				switch ($type) {
					case IMAGETYPE_GIF:
						$image = imagecreatefromgif($tmp_name) ;
						imagegif($image, $image_path . '/' . $image_name);
					break;
					case IMAGETYPE_JPEG:
						$image = imagecreatefromjpeg($tmp_name) ;
						imagejpeg($image, $image_path . '/' . $image_name, 100);
					break;
					case IMAGETYPE_PNG:
						$image = imagecreatefrompng($tmp_name) ;
						imagepng($image, $image_path . '/' . $image_name);
					break;
					default:
						$image_name=FALSE;
				}
				imagedestroy($image);	
				return $image_name;	 
						
		 }
		function bulk_crop_this_image($file_path, $thumb_width, $thumb_height,$file_name){
				$tmp_name = $file_path.$file_name;
				list($width, $height, $file_type, $attr) = getimagesize($tmp_name);
				
				$image_split = explode('.',$file_name);
				$raw_name = $image_split[0];
				$file_type  = $image_split[1];

				$imagename = $raw_name.'_cropped_'.$thumb_width.'_'.$thumb_height.'.'.$file_type;
				
				$image = imagecreatefromjpeg($file_path.$file_name); 				
				$original_aspect = $width / $height;
				$thumb_aspect = $thumb_width / $thumb_height;
				
				if ( $original_aspect >= $thumb_aspect ) {
				   // If image is wider than thumbnail (in aspect ratio sense)
				   $new_height = $thumb_height;
				   $new_width = $width / ($height / $thumb_height);
				} else {
				   // If the thumbnail is wider than the image
				   $new_width = $thumb_width;
				   $new_height = $height / ($width / $thumb_width);
				}
				$resized_image = imagecreatetruecolor( $thumb_width, $thumb_height );
				
				// Resize and crop
				imagecopyresampled($resized_image, $image,
								   0 - ($new_width - $thumb_width) / 2,  0 - ($new_height - $thumb_height) / 2, 0, 0,
								   $new_width, $new_height,
								   $width, $height);
				switch ($file_type) {
					case 'gif':
						imagegif($resized_image, $file_path.$imagename); 
					break;
					case 'jpg':
						imagejpeg($resized_image, $file_path.$imagename, 100);
					break;
					case 'jpeg':
						$image = imagecreatefromjpeg($tmp_name);
						imagejpeg($image, $path . '/' . $imagename, 100);
						$upload = 1;
					break;
					case 'png':
						imagepng($resized_image, $file_path.$imagename); 
					break;
					default:
						$imagename=FALSE;
				}
							
			return $imagename; 
				
		}


		function crop_this_image($file_path, $raw_name, $orig_name, $source_image, $image_width, $image_height, $thumb_width, $thumb_height, $file_ext){
		
				list($width, $height, $file_type, $attr) = getimagesize($_FILES['userfile']['tmp_name']);
				// make sure the uploaded file is really a supported image
				switch ($file_type) {
					case IMAGETYPE_GIF:
						$image = imagecreatefromgif($_FILES['userfile']['tmp_name']) ;
					break;
					case IMAGETYPE_JPEG:
						$image = imagecreatefromjpeg($_FILES['userfile']['tmp_name']) ;
					break;
					case IMAGETYPE_PNG:
						$image = imagecreatefrompng($_FILES['userfile']['tmp_name']) ;
					break;
				}
				$imagename = $raw_name.'_cropped_'.$thumb_width.'_'.$thumb_height.$file_ext;
				$filename = $file_path.$imagename;
				
				$width = $image_width;
				$height = $image_height;
				
				$original_aspect = $width / $height;
				$thumb_aspect = $thumb_width / $thumb_height;
				
				if ( $original_aspect >= $thumb_aspect ) {
				   // If image is wider than thumbnail (in aspect ratio sense)
				   $new_height = $thumb_height;
				   $new_width = $width / ($height / $thumb_height);
				} else {
				   // If the thumbnail is wider than the image
				   $new_width = $thumb_width;
				   $new_height = $height / ($width / $thumb_width);
				}
				$thumb = imagecreatetruecolor( $thumb_width, $thumb_height );
				
				// Resize and crop
				imagecopyresampled($thumb,
								   $image,
								   0 - ($new_width - $thumb_width) / 2, // Center the image horizontally
								   0 - ($new_height - $thumb_height) / 2, // Center the image vertically
								   0, 0,
								   $new_width, $new_height,
								   $width, $height);
				
				switch ($file_type) {
					case IMAGETYPE_GIF:
						imagegif($thumb, $filename);
						break;
					case IMAGETYPE_JPEG:
						imagejpeg($thumb, $filename, 100);
						break;
					case IMAGETYPE_PNG:
						imagepng($thumb, $filename);
						break;
				}
			imagedestroy($image);
			
			return $imagename; 
				
		}
		function get_my_articles($blog_id){
			
			$query = $this->db->query(" SELECT * FROM blog_users, blog_articles, blog_categories
			WHERE blog_users.blog_id = blog_articles.blog_id
			AND blog_categories.article_id =  blog_articles.blog_articles_id
			AND blog_users.blog_id ='".$blog_id."' " );
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}
		function get_article($article_id){
			
			$query = $this->db->query(" SELECT * FROM blog_users, blog_articles, blog_categories
			WHERE 	blog_users.blog_id = blog_articles.blog_id
			AND blog_categories.article_id =  blog_articles.blog_articles_id
			AND blog_articles_id ='".$article_id."' " );
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}		
		function all_articles(){

			$query = $this->db->query(" SELECT * FROM
			blog_users,
			blog_articles
			WHERE blog_users.blog_id = blog_articles.blog_id
			ORDER BY blog_articles.blog_articles_id DESC " );
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}
		function get_blog_id_from_article($article_id){
			
			$query = $this->db->query(" SELECT blog_users.blog_id 
			FROM blog_users
			INNER JOIN blog_articles ON blog_articles.blog_id = blog_users.blog_id
			WHERE blog_articles.blog_articles_id = '".$article_id."' " );
			if ($query) {
				$row = $query->row();
				$blog_id = $row->blog_id; 
				return $blog_id;
			}else{
				return FALSE;
			}
		}		
		function get_article_title($result){
			
			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query(" SELECT * FROM blog_users, blog_articles 
			WHERE blog_users.blog_id = '".$blog_id."'  
			AND blog_articles.blog_articles_id = '".$article_id."' " );
			$row = $query->row();
			if($result = 'blog_title'){
				$title = $row->blog_pagetitle; 
			}else{
				$aarticle_title = $row->blog_articles_pagetitle; 
			}
			return $title;
		}
		
	function create_article(){
			
			$activationKey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand();
			$date =  date('Y-m-d H:m:s');
			$blog_pagetitle = $this->input->post('article_title');
			$blog_pagetitle = str_replace("'", " ", $blog_pagetitle);
			$blog_pagetitle = str_replace('"', " ", $blog_pagetitle);
			$blog_pagetitle = str_replace(" ", "-", $blog_pagetitle);
			$blog_pagetitle = str_replace("_", "-", $blog_pagetitle);
			if  ($this->session->set_userdata('feature_image')){
				$blog_articles_image=$this->session->set_userdata('feature_image');
			}else{
				$blog_articles_image=NULL;
			}

			$data = array(
				 'blog_id' => $this->input->post('blog_id'), 
				 'blog_articles_catergory' => $this->input->post('article_catergory'), 
				 'blog_articles_shortdesc' => $this->input->post('article_shortdescription'), 
				 'blog_articles_description' => $this->input->post('article_description'), 
				 'blog_articles_page' => $blog_pagetitle, 
				 'blog_articles_pagetitle' => $this->input->post('article_title'), 
				 'blog_articles_image' => $blog_articles_image, 
				 'blog_article_date' => $date, 
				 'blog_articles_level' => 'Yet to be Administered' 
			);

			$this->db->insert('blog_articles', $data);
			
			return $this->db->insert_id();
			
		}	
		
	function update_featured($featured_image){

			$query = $this->db->query( " UPDATE `blog_articles`
			SET `blog_articles_image` = '".$featured_image."' 
			WHERE (`blog_articles_id` = '".$this->input->post('blog_articles_id')."') " );
			if ($query){
				return true;
			}else{
				return false;
			}
			
		}		
}