<?php 
class All_blogs extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function all_active_blog_content() {
        	$query = $this->db->query(" SELECT * 
			FROM blog_users
			INNER JOIN blog_articles ON blog_articles.blog_id = blog_users.blog_id
			WHERE blog_users.blog_level = 'Approved' 
			ORDER BY blog_articles.blog_articles_id DESC ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}


		function getAllBlogContentRows() {
		
			$query = $this->db->query(" SELECT * FROM `blog_users` 
			WHERE `blog_level`='Approved' 
			ORDER BY blog_id ASC ");
			if ($query) {
				$rowcount = $query->num_rows();	
				return $rowcount;
			}else{
				return FALSE;
			}
			
		}		
		function all_blog_content() {

        	$query = $this->db->query(" SELECT * FROM `blog_users` 
			WHERE `blog_level`='Approved' 
			ORDER BY blog_id ASC ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}
		
		function all_blog_articles(){

			$query = $this->db->query( " SELECT * FROM blog_users, blog_articles 
			WHERE blog_users.blog_id = blog_articles.blog_id 
			AND blog_users.blog_level = 'Approved' 
			AND blog_articles_level = 'Approved' 
			ORDER BY blog_articles.blog_articles_id DESC " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}
		function my_blog_title($blog_id) {
			$query = $this->db->query(" SELECT blog_pagetitle FROM blog_users WHERE blog_id = '".$blog_id."' ");
			if ($query) {
				$row = $query->row_array();
				return $row['blog_pagetitle'];
			}else{
				return FALSE;
			}
		
		}
		function my_blog_details($blog_id) {
			$query = $this->db->query(" SELECT * FROM blog_users WHERE blog_id = '".$blog_id."' ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		
		}
		
		function getCurrentCount() {
		
			$limit = $this->getLimit();
			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
				$start = $page * $limit;
				$startCount = $start - $limit;
			}else{
				$startCount = 0;
			}
			
			return $startCount;
			
		}
		function getLimit() {
			$limit = 25;
			return $limit;
			
		}		
		function getAllAssessementlimit() {
		
			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$limit = $this->getQaAssessementlimit();
			$limitQ = $page * $limit;
			return $limitQ;
			
		}
		function getAllRecordCount() {
		$limit = $this->getLimit();
		if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
				$current_count = $page * $limit;
			}else{
				$page = '1';
				$current_count = $limit;
			}
			
			$startpoint = ($page * $limit) - $limit;	
			$recordCount=min($startpoint + $limit, $this->getAllBlogContentRows());
			
			return $current_count; 
		}
		
			
		
}