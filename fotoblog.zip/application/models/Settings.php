<?php

class Settings extends CI_Model{


	function site_settings(){
			$q = $this->check_user();
			$query = $this->db->query( "SELECT  * FROM `blog_settings` 
			ORDER BY setting_type, setting_id ASC  " ) ;
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
	}

	function setting_parts($values, $part){

			$query = $this->db->query( " SELECT ".$values."
			FROM `blog_settings`
			WHERE setting_type = '".$part."' 
			AND setting_input_text='small'  " ) ;

			if ($query){
				return $query->result_array();
			}else{
				return false;
			}

	}
	function setting_part($key, $part){

			$query = $this->db->query( " SELECT setting_value
			FROM `blog_settings`
			WHERE setting_key = '".$key."' 
			AND setting_type = '".$part."' 
			AND setting_input_text IN ('small','na')  " ) ;

			if ($query){
				$row = $query->row();
				return $row->setting_value;
			}else{
				return false;
			}			
			
	}
	
}