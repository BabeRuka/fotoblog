<?php

class Slideshow extends CI_Model{

 	function total_slideshows() {
		$q = $this->check_user();
        return $this->db->count_all(" `blog_slides` ".$q." ORDER BY slide_id DESC  ");
    }	
	function one_active_slideshow_image($page, $part){
			$query = $this->db->query( "SELECT ".$part." 
			FROM `blog_slides`
			LEFT JOIN blog_slide_images ON blog_slide_images.slide_id=blog_slides.slide_id
			WHERE blog_slides.slide_type = '".$page."'
			AND blog_slides.slide_status = '1'
			ORDER BY blog_slides.slide_id DESC , slide_image_id ASC
			LIMIT 0, 1 " ) ;
			if ($query) {
				$row = $query->row();
				return $row->$part;
			}else{
				return FALSE;
			}
	}
	function active_slideshow($page, $image){
			$query = $this->db->query( "SELECT  * FROM `blog_slides`
			LEFT JOIN blog_slide_images ON blog_slide_images.slide_id=blog_slides.slide_id
			WHERE blog_slides.slide_type = '".$page."' 
			AND blog_slides.slide_status = '1'
			AND slide_images_image != '".$image."' 
			ORDER BY blog_slides.slide_id DESC , slide_image_id ASC " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
	}
	function check_user(){
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {
				$q = " WHERE blog_id != '' ";
			}else{
				$q = " WHERE blog_id = '".$this->session->userdata('blog_id')."' ";
			}
		
		return $q;
	}
	function all_slideshows($limit, $start){
			$q = $this->check_user();
			$query = $this->db->query( "SELECT  * FROM `blog_slides` 
			".$q." 
			ORDER BY slide_id DESC 
			LIMIT ".$start.", ".$limit." " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
	}
	function my_latest_slideshows($blog_id){
			$q = $this->check_user();
			$query = $this->db->query( "SELECT  * FROM `blog_slides`
			WHERE blog_id = ".$blog_id." 
			ORDER BY slide_id DESC 
			LIMIT 0, 15 " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
	}

	function latest_slideshows(){
			$q = $this->check_user();
			$query = $this->db->query( "SELECT  * FROM `blog_slides` 
			ORDER BY slide_id DESC 
			LIMIT 0, 15 " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
	}
	function this_slideshow($slide_id){

			$query = $this->db->query( "  SELECT * FROM `blog_slides` 
			WHERE slide_id = '".$slide_id."' " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
	}	
	function slideshow_photo($photo_id, $part){

			$query = $this->db->query( " SELECT ".$part."
			FROM `blog_slide_images`
			WHERE slide_image_id = '".$photo_id."'  " ) ;
			if ($query) {
				$row = $query->row();
				return $row->$part;
			}else{
				return FALSE;
			}
	}

	
	function slideshow_part($slide_id, $part){

			$query = $this->db->query( " SELECT ".$part."
			FROM `blog_slides`
			WHERE slide_id = '".$slide_id."'  " ) ;
			if ($query) {
				$row = $query->row();
				$row->$part; 
				return $row->$part;
			}else{
				return FALSE;
			}
	}
	
	function all_slideshow_images($slide_id){

			$query = $this->db->query( " SELECT * FROM blog_slides
			INNER JOIN blog_slide_images ON blog_slide_images.slide_id = blog_slides.slide_id
			WHERE blog_slides.slide_id = '".$slide_id."' " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
	}	
	function selected_slideshow_images($selected_ids){

			$query = $this->db->query( " SELECT * FROM blog_slide_images
			WHERE slide_image_id IN ( ".$selected_ids.") " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
	}	


	function all_slideshow_images_excluding_one($slide_id, $photo_id){

			$query = $this->db->query( " SELECT * FROM blog_slides
			INNER JOIN blog_slide_images ON blog_slide_images.slide_id = blog_slides.slide_id
			WHERE blog_slides.slide_id = '".$slide_id."'
			AND slide_image_id NOT IN ('".$photo_id."')  " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
	}	

	function slideshow_images($photo_id){

			$query = $this->db->query( " SELECT * FROM `blog_slide_images`
			WHERE slide_image_id = '".$photo_id."' " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
	}	
	
}