<?php 
class Reset_password extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->helper('string');
				$this->load->library('session');

        }
		function change(){
			
			$blog_passwordkey =  '';
			$date =  date('Y-m-d H:m:s');
			$password = md5($this->input->post('password'));
		
			if ($password != '') {
				$blog_id = $this->input->post('blog_id');
				$query = $this->db->query("UPDATE `blog_users` 
				SET `blog_activicationkey`='', blog_password='".$password."', blog_passwordkey_date = '".$date."' 
				WHERE (`blog_id`='".$blog_id."') ");
				if ($this->db->affected_rows() == '1') {
					$query = $this->db->query(" INSERT INTO `blog_passwords` (`blog_id`, `password`, `password_date`) 
					VALUES ('".$blog_id."', '".$password."', '".$date."') ");
					if ($query){
						
						
						
						return TRUE;
					}else{
						return FALSE;
					}
				}else{
					return FALSE;
				}
			}else{
					return FALSE;
			}
			
		}
		
		function start_reset($blog_id){
			
			$blog_passwordkey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand();
			$date =  date('Y-m-d H:m:s');
			$query = $this->db->query("UPDATE `blog_users` 
			SET `blog_passwordkey`='".$blog_passwordkey."', blog_passwordkey_date = '".$date."' 
			WHERE (`blog_id`='".$blog_id."') ");
			if ($query) {
				return TRUE;
				}else{
				return FALSE;
			}
			
		}
		function reset_password(){
			
			$blog_passwordkey =  mt_rand() . mt_rand() . mt_rand() . mt_rand() . mt_rand();
			$date =  date('Y-m-d H:m:s');
			$blog_email = $this->input->post('blog_email');
		
			if ($this->email_check($blog_email) != '') {
				$blog_id = $this->get_blog_id($blog_email);
				$query = $this->db->query("UPDATE `blog_users` 
				SET `blog_passwordkey`='".$blog_passwordkey."', blog_passwordkey_date = '".$date."' 
				WHERE (`blog_id`='".$blog_id."') ");
				if ($this->db->affected_rows() == '1') {
					return TRUE;
				}else{
					return FALSE;
				}
			}else{
					return FALSE;
			}
			
		}

		function email_check($blog_email) {
			$query = $this->db->query(" SELECT blog_email FROM blog_users WHERE blog_email = '".$blog_email."' ");
			$row = $query->row();
			if (isset($row)){
				$blog_email = $row->blog_email;
			}else{
				$blog_email = '';
			}
			return $blog_email;
		}

		function get_blog_id($blog_email) {
			$query = $this->db->query(" SELECT blog_id FROM blog_users WHERE blog_email = '".$blog_email."' ");
			$row = $query->row();
			if (isset($row)){
				$blog_id = $row->blog_id;
			}else{
				$blog_id = '';
			}
			return $blog_id;		
		}

		
		function user_details($blog_id) {
				
			$query = $this->db->query(" SELECT 
			blog_users.blog_id,
			blog_users.blog_description,
			blog_users.blog_page,
			blog_users.blog_pagetitle,
			DATE(blog_users.blog_date) AS blog_date,
			blog_users.blog_username,
			blog_users.blog_fname,
			blog_users.blog_lname,
			blog_users.blog_email,
			blog_users.blog_level,
			blog_users.blog_catergory,
			blog_users.blog_activicationkey,
			blog_users.blog_passwordkey,
			DATE(blog_users.blog_passwordkey_date) AS blog_passwordkey_date,
			blog_users.blog_logins,
			DATE(blog_users.blog_lastlogin) AS blog_lastlogin			
			FROM blog_users WHERE blog_id = '".$blog_id."' ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
				
		}		

}