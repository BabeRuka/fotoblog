<?php 
class All_tags extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
	

		function one_tag($category_id) {
			$query = $this->db->query(" SELECT * FROM 
			blog_categories 
			WHERE blog_category_id = '".$category_id."' ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}


		
		function insert_tag($blog_id,$article_id,$blog_tag_name,$blog_tag_slug) {
			
			$data = array(
				 'blog_id' => $blog_id, 
				 'article_id' => $article_id, 
				 'blog_tag_name' => $blog_tag_name, 
				 'blog_tag_slug' => $blog_tag_slug
			);

			$$query = $this->db->insert('blog_tags', $data);
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}	
		
		
	}