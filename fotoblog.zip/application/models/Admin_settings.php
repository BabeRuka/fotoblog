<?php 
class Admin_settings extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function all_settings(){
	
			$query = $this->db->query( "  SELECT * FROM `blog_settings` " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}	
		
		function some_settings($setting_type){
	
			$query = $this->db->query( "  SELECT * FROM `blog_settings` 
			WHERE `setting_type`='".$setting_type."' AND setting_id NOT IN (18,23,24) " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}	
		
		public function setting_part($setting_key, $part){
	
			$query = $this->db->query( " SELECT ".$part."
			FROM `blog_settings`
			WHERE setting_key = '".$setting_key."'  " ) ;
			if ($query) {
				$row = $query->row();
				return $row->$part;
			}else{
				return FALSE;
			}
		}
		
		function update_settings($setting_id, $setting_value) {

			$setting_date =  date('Y-m-d H:m:s');


			$query = $this->db->query(" 
			UPDATE IGNORE `blog_settings`
			SET 
			`setting_value` = '".htmlspecialchars($this->db->escape_str($setting_value))."',
			`setting_date` = '".$setting_date ."'
			WHERE (`setting_id` = '".$setting_id."');
			"); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}			
		
			
	}