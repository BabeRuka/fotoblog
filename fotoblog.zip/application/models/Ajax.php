<?php 
class Ajax extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }

		function get_blog_part($blog_id, $part){ 
			
			$query = $this->db->query(" SELECT ".$part." 
			FROM blog_users
			WHERE blog_id = '".$blog_id."' " );
			if ($query) {
				$row = $query->row();
				return $row->$part;
			}else{
				return FALSE;
			}
		}		
}