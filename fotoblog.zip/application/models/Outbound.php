<?php 
class Outbound extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		//getContentID
		function getContentID() {

			if ($this->uri->segment(4)){
				$blog = $this->uri->segment(4);
			}else{
				$blog=false;	
			}
			
			return $blog;
		}
		function getGalleryID() {

			if ($this->uri->segment(4)){
				$blog = $this->uri->segment(4);
			}else{
				$blog=false;	
			}
			
			return $blog;
		}

		function getPhotoID() {

			if ($this->uri->segment(5)){
				$blog = $this->uri->segment(5);
			}else{
				$blog=false;	
			}
			
			return $blog;
		}

		function getGallery() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
			}else{
				$blog=false;	
			}
			
			return $blog;
		}

		function getBlogID() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
			}else{
				$blog=false;	
			}
			
			return $blog;
		}

		function getArticleID() {

			if ($this->uri->segment(4)){
				$blog = $this->uri->segment(4);
			}else{
				$blog=false;	
			}
			
			return $blog;
		}
		
		function article_title($article_id){
			
			$query = $this->db->query("SELECT blog_articles_pagetitle
			FROM blog_articles 
			WHERE blog_articles_id = '".$article_id."' " );
			$rowcount = $query->num_rows();	
			$row = $query->row();
			if ($row){
				$article_title = $row->blog_articles_pagetitle; 
			}else{
				$article_title = '';
			}
			return $article_title;
		}		
		function track_article(){
			
			$outbound_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query("SELECT blog_article_hits 
			FROM blog_articles 
			WHERE blog_articles_id = '".$outbound_id."' " );
			$rowcount = $query->num_rows();	
			$row = $query->row();
			if ($row){
				$hits = $row->blog_article_hits + 1; 

				$query = $this->db->query("UPDATE blog_articles 
				SET blog_article_hits = '".$hits."' 
				WHERE blog_articles_id = '".$outbound_id."' "); 
				$result = TRUE;
			}else{
				$result = 'FALSE';
			}
			return $result;
		}

		function track_gallery(){
			
			$outbound_id = $this->getGalleryID();

			$query = $this->db->query("SELECT blog_gal_hits 
			FROM blog_gals 
			WHERE blog_gal_id = '".$outbound_id."' " );
			$rowcount = $query->num_rows();	
			$row = $query->row();
			if ($row){
				$hits = $row->blog_gal_hits + 1; 

				$query = $this->db->query("UPDATE blog_gals 
				SET blog_gal_hits = '".$hits."' 
				WHERE blog_gal_id = '".$outbound_id."' "); 
				$result = TRUE;
			}else{
				$result = 'FALSE';
			}
			return $result;
		}
		
		function track_photo(){
			
			$outbound_id = $this->getPhotoID();

			$query = $this->db->query("SELECT blog_tbn_hits 
			FROM blog_gals_images 
			WHERE blog_tbn_id = '".$outbound_id."' " );
			$rowcount = $query->num_rows();	
			$row = $query->row();
			if ($row){
				$hits = $row->blog_tbn_hits + 1; 

				$query = $this->db->query("UPDATE blog_gals_images 
				SET blog_tbn_hits = '".$hits."' 
				WHERE blog_tbn_id = '".$outbound_id."' "); 
				$result = TRUE;
			}else{
				$result = 'FALSE';
			}
			return $result;
		}
		
		function track_page(){
			
			$outbound_id = $this->getContentID();

			$query = $this->db->query("SELECT blog_content_hits 
			FROM blog_content 
			WHERE blog_content_id = '".$outbound_id."' " );
			$rowcount = $query->num_rows();	
			$row = $query->row();
			if ($row){
				$hits = $row->blog_content_hits + 1; 

				$query = $this->db->query("UPDATE blog_content 
				SET blog_content_hits = '".$hits."' 
				WHERE blog_content_id = '".$outbound_id."' "); 
				$result = TRUE;
			}else{
				$result = 'FALSE';
			}
			return $result;
		}
		
}