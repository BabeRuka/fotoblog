<?php 
class Admin_dashboard extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		//gallery functions 
		function clean_url($input){
		
			$input = trim(strip_tags(strtolower($input)));
			$input = strtolower(str_replace("'", '', $input));
			// Strip HTML Tags
			$input = strip_tags($input);
			// Clean up things like &amp;
			$input = html_entity_decode($input);
			// Strip out any url-encoded stuff
			$input = urldecode($input);
			// Replace non-AlNum characters with space
			$input = preg_replace('/[^A-Za-z0-9]/', ' ', $input);
			// Replace Multiple spaces with single space
			$input = preg_replace('/ +/', ' ', $input);
			// Trim the string of leading/trailing space
			$input = trim($input);
			$input = strtolower(str_replace(' ', '-', $input));	
			
			return $input;	
			
		}

		function check_user($joiner){
				if ($this->session->userdata('blog_catergory') == 'Super Administrator') {
					$q = " ".$joiner." blog_id IS NOT NULL ";
				}else{
					$q = " ".$joiner." blog_id = '".$this->session->userdata('blog_id')."' ";
				}
			
			return $q;
		}


		function admin_details($blog_id) {
				
			$query = $this->db->query(" SELECT * FROM blog_users WHERE blog_id = '".$blog_id."' ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
				
		}		
		function total_logins() {
			$q = $this->check_user('AND');
			$query = $this->db->query(" SELECT count(track_id) AS logins
			FROM `blog_tracking` 
			WHERE  MONTH(track_date) = '".date('m')."'
			AND YEAR(track_date) = '".date('Y')."' 
			AND track_action = 'Login User'
			".$q." ");
			$row = $query->row();

			if($query){
				$logins = $row->logins; 
			}else{
				$logins = ''; 
			}
			return $logins;
				
		}		
		
		function mysql_version(){
			$query = $this->db->query(" SELECT VERSION() as version " );
			$row = $query->row();
			if($query){
				$version = $row->version; 
			}else{
				$version = ''; 
			}
			return $version;
		}			


		function total_galleries(){
			$q = $this->check_user('WHERE');
			$query = $this->db->query(" SELECT count(blog_gal_id) AS galleries 
			FROM `blog_gals` 
			".$q." " );
			$row = $query->row();
			if($query){
				$galleries = $row->galleries; 
			}else{
				$galleries = ''; 
			}
			return $galleries;
		}			
		function total_comments(){
			$q = $this->check_user('WHERE');
			$query = $this->db->query(" SELECT count(blog_comment_id) AS comments 
			FROM blog_comments
			".$q." " );
			$row = $query->row();
			if($query){
				$comments = $row->comments; 
			}else{
				$comments = ''; 
			}
			return $comments;
		}			
		function total_pages(){
			$q = $this->check_user('WHERE');
			$query = $this->db->query(" SELECT count(blog_content_id) AS pages 
			FROM blog_content
			".$q." " );
			$row = $query->row();
			if($query){
				$pages = $row->pages; 
			}else{
				$pages = ''; 
			}
			return $pages;
		}			
		function total_articles(){
			$q = $this->check_user('WHERE');
			$query = $this->db->query(" SELECT count(blog_articles_id) AS articles 
			FROM blog_articles
			".$q." " );
			$row = $query->row();
			if($query){
				$articles = $row->articles; 
			}else{
				$articles = ''; 
			}
			return $articles;
		}			
		function total_gallery_images(){
			$q = $this->check_user('WHERE');
			
			$query = $this->db->query(" SELECT count(blog_tbn_id) AS galleries 
			FROM `blog_gals_images` 
			INNER JOIN blog_gals ON blog_gals.blog_gal_id=blog_gals_images.blog_gal_id
			 ".$q." " );
			$row = $query->row();
			if($query){
				$galleries = $row->galleries; 
			}else{
				$blog_id = ''; 
			}
			return $galleries;
		}	
		
		function create_gallery($image, $image_tbn) {
			
			
			$blog_gal_name = htmlspecialchars($this->input->post('gall', true));
			$blog_gal_description = htmlspecialchars($this->input->post('desc', true));
			$blog_id  = $this->session->userdata('blog_id');
			$blog_gal_date =  date('Y-m-d H:m:s');
			//clean your url
			$blog_gal_pagename = trim(strip_tags(strtolower($this->input->post('gall'))));
			$blog_gal_pagename = $this->clean_url($blog_gal_pagename); 
			
			$query = $this->db->query(" 
			INSERT INTO `blog_gals` (blog_id, `blog_gal_name`, blog_gal_pagename, `blog_gal_image`, blog_gal_image_tbn, `blog_gal_description`, blog_gal_date) 
			VALUES ('".$blog_id."', '".$blog_gal_name."', '".$blog_gal_pagename."', '".$image."', '".$image_tbn."', '".$blog_gal_description."', '".$blog_gal_date."') "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		
		

		function update_gallery($image, $image_tbn){ 
			
			
			$blog_gal_name = htmlspecialchars($this->input->post('gall', true));
			$blog_gal_description = htmlspecialchars($this->input->post('desc', true));
			$blog_id  = $this->session->userdata('blog_id');
			$blog_gal_id  = $this->input->post('blog_gal_id');
			$blog_gal_date =  date('Y-m-d H:m:s');

			$blog_gal_pagename = trim(strip_tags(strtolower($this->input->post('gall'))));
			$blog_gal_pagename = $this->clean_url($blog_gal_pagename); 
			
			$query = $this->db->query(" 
			
			UPDATE `blog_gals`
			SET 
			 `blog_id` = '".$blog_id."',
			 `blog_gal_name` = '".$blog_gal_name."',
			 `blog_gal_pagename` = '".$blog_gal_pagename."',
			 `blog_gal_image` = '".$image."',
			 `blog_gal_image_tbn` = '".$image_tbn."',
			 `blog_gal_description` = '".$blog_gal_description."',
			 `blog_gal_date` = '".$blog_gal_date."'
			WHERE (`blog_gal_id` = '".$blog_gal_id."')
			
			"); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		
						
		function delete_gallery($gallery_id) {
			$query = $this->db->query("DELETE FROM blog_gals 
			WHERE blog_gal_id = '".$gallery_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function delete_photo($photo_id) {
			$query = $this->db->query("DELETE FROM blog_gals_images 
			WHERE blog_tbn_id = '".$photo_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		function create_gallery_photos($image, $image_tbn) {
			
			
			$blog_tbn_name = htmlspecialchars($this->input->post('photo_gall', true));
			$blog_tbn_caption = htmlspecialchars($this->input->post('photo_desc', true));
			$blog_id  = $this->input->post('blog_id');
			$blog_gal_id  = $this->input->post('blog_gal_id');
			$blog_tbn_date =  date('Y-m-d H:m:s');
			
			
			$blog_tbn_name = trim(strip_tags(strtolower($this->input->post('photo_name'))));
			$blog_tbn_name = $this->clean_url($blog_tbn_name); 
			
			$query = $this->db->query(" 
			INSERT INTO `blog_gals_images` (`blog_gal_id`, `blog_tbn_name`, `blog_tbn_caption`, `blog_tbn_image`, `blog_tbn_image_tbn`, `blog_tbn_date`, `blog_tbn_desc`) 
			VALUES ('".$blog_gal_id."', '".$blog_tbn_name."', '".$blog_tbn_caption."', '".$image."', '".$image_tbn."', '".$blog_tbn_date."', '".$blog_tbn_caption."' ) "); 
			if($query){
				$result = $this->db->insert_id();
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		
		
		function bulk_create_gallery_photos($blog_gal_id, $blog_tbn_image) {
			
			
			$blog_tbn_date =  date('Y-m-d H:m:s');
			
			$query = $this->db->query(" 
			INSERT INTO `blog_gals_images` (`blog_gal_id`, `blog_tbn_image`, `blog_tbn_date`) 
			VALUES ('".$blog_gal_id."', '".$blog_tbn_image."', '".$blog_tbn_date."') "); 
			if($query){
				$result = $this->db->insert_id();
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}			

		function bulk_update_gallery_photos($blog_tbn_id, $blog_tbn_image_tbn) {
			
			
			$blog_tbn_date =  date('Y-m-d H:m:s');
			
			$query = $this->db->query(" 
			UPDATE `blog_gals_images`
			SET `blog_tbn_image_tbn` = '".$blog_tbn_image_tbn."'
			WHERE `blog_tbn_id` = ".$blog_tbn_id." 
			"); 
			if($query){
				$result = $this->db->insert_id();
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}			

		
		function update_gallery_photos($image_tbn) {
			
			
			$blog_tbn_caption = htmlspecialchars($this->input->post('photo_name',true) );
			$blog_tbn_desc = htmlspecialchars( $this->input->post('photo_desc',true));
			$blog_tbn_id  = $this->input->post('edit_photo');
			$blog_gal_id  = $this->input->post('blog_gal_id');
			$blog_tbn_date =  date('Y-m-d H:m:s');
			
			
			$blog_tbn_name = trim(strip_tags(strtolower($blog_tbn_caption)));
			$blog_tbn_name = $this->clean_url($blog_tbn_name); 
			
			$query = $this->db->query(" 
			UPDATE IGNORE `blog_gals_images`
			SET 
			 `blog_tbn_name` = '".$blog_tbn_date ."',
			 `blog_tbn_caption` = '".htmlspecialchars($this->db->escape_str($blog_tbn_caption))."',
			 `blog_tbn_date` = '".$blog_tbn_date ."',
			 `blog_tbn_desc` = '".htmlspecialchars($this->db->escape_str($blog_tbn_desc)) ."'
			WHERE (`blog_tbn_id` = '".$image_tbn."');
			"); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}			
		//end gallery
		
		
		//start slideshow
		
		function total_slideshows(){
			
			$query = $this->db->query(" SELECT count(slide_id) AS slides FROM `blog_slides` " );
			$row = $query->row();
			if($query){
				$slides = $row->slides; 
			}else{
				$slides = ''; 
			}
			return $slides;
		}			
		function total_slideshow_images(){
			
			$query = $this->db->query(" SELECT count(slide_image_id) AS slides FROM `blog_slide_images` " );
			$row = $query->row();
			if($query){
				$slides = $row->slides; 
			}else{
				$slides = ''; 
			}
			return $slides;
		}	
		
		
		
		function create_slideshow($image, $image_tbn) {
			
			
			$slide_name = htmlspecialchars($this->input->post('gall', true));
			$slide_description = htmlspecialchars($this->input->post('desc', true));
			$blog_id  = $this->session->userdata('blog_id');
			$slide_date =  date('Y-m-d H:m:s');
			//clean your url
			$slide_pagename = trim(strip_tags(strtolower($this->input->post('gall'))));
			$slide_pagename = $this->clean_url($slide_pagename); 
			
			$query = $this->db->query(" 
			INSERT INTO `blog_slides` (blog_id, `slide_name`, slide_pagename, `slide_status`, `slide_image`, slide_image_tbn, `slide_description`, slide_date) 
			VALUES ('".$blog_id."', '".$slide_name."', '".$slide_pagename."',  '".(($this->input->post('slide_status')!=='') ? $this->input->post('slide_status') : '0')."', '".$image."', '".$image_tbn."', '".$slide_description."', '".$slide_date."') "); 
			if($query){
				$result = TRUE; 
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		
		

		function update_slideshow($image, $image_tbn){ 
			
			
			$slide_name = htmlspecialchars($this->input->post('gall', true));
			$slide_description = htmlspecialchars($this->input->post('desc', true));
			$blog_id  = $this->session->userdata('blog_id');
			$slide_id  = $this->input->post('slide_id');
			$slide_date =  date('Y-m-d H:m:s');
			$slide_status = $this->input->post('slide_status');
			$slide_type  = strtolower($this->input->post('slide_type'));

			$slide_pagename = trim(strip_tags(strtolower($this->input->post('gall'))));
			$slide_pagename = $this->clean_url($slide_pagename); 
			
			$query = $this->db->query(" 
			
			UPDATE `blog_slides`
			SET 
			 `blog_id` = '".$blog_id."',
			 `slide_name` = '".$slide_name."',
			 `slide_pagename` = '".$slide_pagename."',
			 `slide_image` = '".$image."',
			 `slide_image_tbn` = '".$image_tbn."',
			 `slide_description` = '".$slide_description."',
			 `slide_type` = '".$slide_type."',
			 `slide_status` = '".$slide_status."',
			 `slide_date` = '".$slide_date."'
			WHERE (`slide_id` = '".$slide_id."')
			
			"); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		
						
		function delete_slideshow($slide_id) {
			$query = $this->db->query("DELETE FROM blog_slides 
			WHERE slide_id = '".$slide_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function delete_slide_photo($photo_id) {
			$query = $this->db->query("DELETE FROM blog_slide_images 
			WHERE slide_image_id = '".$photo_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		function create_slideshow_photos($image, $image_tbn) {
			
			
			//$slide_image_name = htmlspecialchars($this->input->post('photo_gall', true));
			$slide_image_caption = htmlspecialchars($this->input->post('photo_desc', true));
			$blog_id  = $this->input->post('blog_id');
			$slide_id  = $this->input->post('slide_id');
			$slide_image_date =  date('Y-m-d H:m:s');
			
			
			$slide_image_name = $this->input->post('photo_name');
			$slide_images_image_pagename = trim(strip_tags(strtolower($slide_image_name)));
			$slide_images_image_pagename = $this->clean_url($slide_images_image_pagename); 
			
			$query = $this->db->query(" 
			INSERT INTO `blog_slide_images` (`slide_id`, `slide_image_name`, slide_images_image_pagename, `slide_image_caption`, `slide_images_image`, `slide_images_image_tbn`, `slide_image_date` ) 
			VALUES ('".$slide_id."', '".$slide_image_name."', '".$slide_images_image_pagename."', '".$slide_image_caption."', '".$image."', '".$image_tbn."', '".$slide_image_date."' ) "); 
			if($query){
				$result = $this->db->insert_id();
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		
		
		function bulk_create_slideshow_photos($slide_id, $slide_images_image) {
			
			
			$slide_image_date =  date('Y-m-d H:m:s');
			
			$query = $this->db->query(" 
			INSERT INTO `blog_slide_images` (`slide_id`, `slide_images_image`, `slide_image_date`) 
			VALUES ('".$slide_id."', '".$slide_images_image."', '".$slide_image_date."') "); 
			if($query){
				$result = $this->db->insert_id();
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}			

		function bulk_update_slideshow_photos($slide_image_id, $slide_images_image_tbn) {
			
			
			$slide_image_date =  date('Y-m-d H:m:s');
			
			$query = $this->db->query(" 
			UPDATE `blog_slide_images`
			SET `slide_images_image_tbn` = '".$slide_images_image_tbn."'
			WHERE `slide_image_id` = ".$slide_image_id." 
			"); 
			if($query){
				$result = $this->db->insert_id();
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}			

		
		function update_slideshow_photos($image_tbn) {
			
			
			$slide_image_caption = htmlspecialchars($this->input->post('photo_name',true) );
			$blog_tbn_desc = htmlspecialchars( $this->input->post('photo_desc',true));
			$slide_image_id  = $this->input->post('edit_photo');
			$slide_id  = $this->input->post('slide_id');
			$slide_image_date =  date('Y-m-d H:m:s');
			/*if ($this->input->post('slide_status') == 'Active'){
				$slide_status = '1';
			}else{
				$slide_status = '0';
			}*/
			
			$slide_image_name = trim(strip_tags(strtolower($slide_image_caption)));
			$slide_image_name = $this->clean_url($slide_image_name); 
			
			$query = $this->db->query(" 
			UPDATE IGNORE `blog_slide_images`
			SET 
			 `slide_image_name` = '".$slide_image_name ."',
			 `slide_image_caption` = '".htmlspecialchars($this->db->escape_str($slide_image_caption))."',
			 `slide_image_date` = '".$slide_image_date ."' 
			WHERE (`slide_image_id` = '".$image_tbn."');
			"); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		//end slideshow
				
		function all_admin_details() {
				
			$query = $this->db->query(" SELECT * FROM blog_users ");
			
			return $query->result_array();
				
		}		
		function manage_blog_details($blog_id,$blog_catergory,$blog_level) {
			
			$query = $this->db->query("UPDATE blog_users 
			SET blog_level = '".$blog_level."', blog_catergory = '".$blog_catergory."'
			WHERE blog_id = '".$blog_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function update_profile_picture($blog_id, $profile_pic) {
			$query = $this->db->query(" UPDATE `blog_users` SET `blog_profile_pic` = '".$profile_pic."'
			WHERE (`blog_id` = '".$profile_pic."') "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		function edit_page_details($content_id) {
			$blog_content_pagetitle = htmlspecialchars($this->input->post('blog_content_pagetitle', true));
			$blog_content_description = '"'.htmlspecialchars($this->input->post('blog_content_description', true)).'"';
			$blog_pagetitle  = $this->input->post('blog_pagetitle');
			$blog_content_type  = $this->input->post('blog_content_type');
			$blog_content_id  = $this->input->post('blog_content_id');
			$blog_id  = $this->input->post('blog_id');
			$date =  date('Y-m-d H:m:s');
			if($this->input->post('blog_id') == '0'){
				$blog_content_scope = 'global';
			}else{
				$blog_content_scope = 'private';
			}
			$blog_content_page = trim(strip_tags($this->input->post('blog_content_pagetitle')));
			$blog_content_page = $this->clean_url($blog_content_page); 

			$query = $this->db->query(" UPDATE `blog_content` 
			SET `blog_content_description`=".$blog_content_description.", 
			`blog_id`= ".$this->input->post('blog_id').", 
			`blog_content_page`='".$blog_content_page."', 
			`blog_content_pagetitle`='".$blog_content_pagetitle."', 
			`blog_content_scope`='".$blog_content_scope."', 
			`blog_content_type`='".$blog_content_type."', 
			`blog_content_date`='".$date."'
			WHERE (`blog_content_id`= '".$blog_content_id."' ) "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		function edit_blog_details($blog_id) {
			$blog_catergory= $this->input->post('blog_catergory');
			$blog_level= $this->input->post('blog_level');
			$description = htmlspecialchars($this->db->escape_str($this->input->post('blog_description',true)));
			$blog_pagetitle  = htmlspecialchars($this->db->escape_str($this->input->post('blog_pagetitle', true)));
			$query = $this->db->query("UPDATE blog_users SET
			blog_page  = '".$this->input->post('blog_page')."',   
			blog_pagetitle  = '".$blog_pagetitle."',   
			blog_username  = '".$this->input->post('blog_username')."',   
			blog_fname  = '".$this->input->post('blog_fname')."',   
			blog_lname  = '".$this->input->post('blog_lname')."',   
			blog_email  = '".$this->input->post('blog_email')."',   
			blog_description  =   '".$description."'
			WHERE blog_id = '".$blog_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function delete_blog($blog_id) {
			$query = $this->db->query("DELETE FROM blog_users WHERE blog_id = '".$blog_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		function delete_page($page_id) {
			$query = $this->db->query("DELETE FROM blog_content WHERE blog_content_id = '".$page_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		function update_category($article_id, $category) {
			
			$query = $this->db->query("UPDATE blog_articles 
			SET blog_articles_catergory  = '".strtolower($this->input->post('blog_category_name'))."' 
			WHERE blog_articles_id = '".$article_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		
	
		function edit_article_details($article_id) {
			$modified_date =  date('Y-m-d H:m:s');
			$category_id = $this->input->post('blog_category_id'); 
			$category_name = $this->input->post('blog_category_name');
			//update the category 
			
			$blog_articles_page = $this->input->post('blog_articles_pagetitle');
			$blog_articles_page = str_replace("'", " ", $blog_articles_page);
			$blog_articles_page = str_replace('"', " ", $blog_articles_page);
			$blog_articles_page = str_replace(" ", "-", $blog_articles_page);
			$blog_articles_page = str_replace("_", "-", $blog_articles_page);
			
			//$update_category = $this->edit_category_name($category_id, $category_name);
			$blog_articles_level = $this->input->post('blog_articles_level');
			$blog_articles_shortdesc = htmlspecialchars($this->db->escape_str($this->input->post('blog_articles_shortdesc',true)));
			$blog_articles_description = htmlspecialchars($this->db->escape_str($this->input->post('blog_articles_description',true)));
			$blog_articles_pagetitle  = htmlspecialchars($this->input->post('blog_articles_pagetitle'));
			//update the details
			$query = $this->db->query("UPDATE blog_articles SET
			blog_articles_page  = '".strtolower($blog_articles_page)."',   
			blog_articles_pagetitle  = '".$blog_articles_pagetitle."',   
			blog_articles_level  = '".$this->input->post('blog_articles_level')."',    
			blog_articles_description  =   '".$blog_articles_description."',
			blog_articles_shortdesc  =   '".$blog_articles_shortdesc."',
			blog_article_modified_date  =   '".$modified_date."'
			WHERE blog_articles_id = '".$article_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		

		function edit_comments($comment_id) {

			//update the details
			$query = $this->db->query("UPDATE blog_comments SET
			blog_comment_status  = '".$this->input->post('blog_comment_status')."'   
			WHERE blog_comment_id = '".$this->input->post('blog_comment_id')."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}	
			
		function edit_category_name($category_id, $category_name) {

			$query = $this->db->query("UPDATE blog_categories SET
			blog_category_name  = '".$category_name."'  
			WHERE blog_category_id = '".$category_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}

		function edit_category($category_id, $category_name, $category_slug) {

			$query = $this->db->query("UPDATE blog_categories SET
			blog_category_name  = '".$category_name."',  
			blog_category_slug  = '".$category_slug."'  
			WHERE blog_category_id = '".$category_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function delete_article($article_id) {
			$query = $this->db->query("DELETE FROM blog_articles 
			WHERE blog_articles_id = '".$article_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function delete_comment($comment_id) {
			$query = $this->db->query("DELETE FROM blog_comments 
			WHERE blog_comment_id = '".$comment_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}
		
		function delete_category($category_id) {
			$query = $this->db->query("DELETE FROM blog_categories 
			WHERE blog_category_id = '".$category_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}		
			
	}