<?php 
class Article extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function getBlogID() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
			}else{
				$blog = false;
			}
			
			return $blog;
		}

		function getArticleID() {

			if ($this->uri->segment(4)){
				$blog = $this->uri->segment(4);
			}else{
				$blog = false;
			}
			
			return $blog;
		}
		function get_article(){
			
			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query(" SELECT * FROM blog_users, blog_articles 
			WHERE blog_users.blog_id = '".$blog_id."'  
			AND blog_articles.blog_articles_id = '".$article_id."' " );
			if($query){
				return $query->result_array();
			}else{
				return FALSE;	
			}
		}
		function get_some_of_my_articles($blog_id, $article_id){
			
			$query = $this->db->query(" SELECT * FROM blog_articles 
			WHERE blog_id ='".$blog_id."' 
			AND blog_articles_id != '".$article_id."'
			ORDER BY blog_articles_id DESC
			LIMIT 5 " );
			if($query){
				return $query->result_array();
			}else{
				return FALSE;	
			}
		}
		
		function get_all_articles(){
			
			$query = $this->db->query(" SELECT
			blog_articles.blog_articles_id,
			blog_articles.blog_content_id,
			blog_articles.blog_articles_catergory,
			blog_articles.blog_articles_quote,
			blog_articles.blog_articles_shortdesc,
			blog_articles.blog_articles_description,
			blog_articles.blog_articles_page,
			blog_articles.blog_articles_pagetitle,
			blog_articles.blog_article_date,
			blog_articles.blog_articles_image,
			blog_articles.blog_article_hits,
			blog_articles.blog_articles_level,
			blog_users.blog_fname,
			blog_users.blog_lname,
			blog_users.blog_id
			FROM
			blog_users
			INNER JOIN blog_articles ON blog_articles.blog_id = blog_users.blog_id
			ORDER BY blog_articles.blog_articles_id DESC " );
			if($query){
				return $query->result_array();
			}else{
				return FALSE;	
			}
		}

		function get_my_articles($blog_id){
			
			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query(" SELECT
			blog_articles.blog_articles_id,
			blog_articles.blog_content_id,
			blog_articles.blog_articles_catergory,
			blog_articles.blog_articles_quote,
			blog_articles.blog_articles_shortdesc,
			blog_articles.blog_articles_description,
			blog_articles.blog_articles_page,
			blog_articles.blog_articles_pagetitle,
			blog_articles.blog_article_date,
			blog_articles.blog_articles_image,
			blog_articles.blog_article_hits,
			blog_articles.blog_articles_level,
			blog_users.blog_fname,
			blog_users.blog_lname,
			blog_users.blog_id
			FROM
			blog_users
			INNER JOIN blog_articles ON blog_articles.blog_id = blog_users.blog_id 
			WHERE blog_users.blog_id = '".$blog_id."'  
			ORDER BY blog_articles.blog_articles_id DESC " );
			if($query){
				return $query->result_array();
			}else{
				return FALSE;	
			}
		}
		function get_blog_id($article_id){
			
			$query = $this->db->query(" SELECT blog_articles.blog_id
			FROM `blog_articles` 
			WHERE blog_articles.blog_articles_id = '".$article_id."' " );
			$row = $query->row();
			if($query){
				$blog_id = $row->blog_id; 
			}else{
				$blog_id = ''; 
			}
			return $blog_id;
		}	
		
		function article_title(){
			
			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query(" SELECT blog_articles_pagetitle FROM blog_users, blog_articles 
			WHERE blog_users.blog_id = '".$blog_id."'  
			AND blog_articles.blog_articles_id = '".$article_id."' " );
			if($query){
				$row = $query->row();
				$title = $row->blog_articles_pagetitle; 
				return $title;
			}else{
				return FALSE;	
			}
		}	
		function get_article_title(){
			
			$article_id = $this->getArticleID();
			$blog_id = $this->getBlogID();
	
			$query = $this->db->query(" SELECT * FROM blog_users, blog_articles 
			WHERE blog_users.blog_id = '".$blog_id."'  
			AND blog_articles.blog_articles_id = '".$article_id."' " );
			$row = $query->row();
			if($result = 'blog_title'){
				$title = $row->blog_pagetitle; 
			}else{
				$aarticle_title = $row->blog_articles_pagetitle; 
			}
			return $title;
		}	
}