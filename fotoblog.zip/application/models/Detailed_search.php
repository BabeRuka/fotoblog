<?php 
class Detailed_search extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function keyword(){
			return $this->db->escape_like_str($this->input->post('description'));	
		}
		function detailed_search_galleries() {
			
			$description = $this->keyword();	 
			
        	$query = $this->db->query(" 
			  SELECT
			  blog_gals.*, blog_gal_id, blog_gal_image, blog_gal_image_tbn,  
			  IF(
				blog_gal_name LIKE '%".$description."%',
				blog_gal_name,
				''
			  ) AS blog_gal_name,
			  IF(
				blog_gal_pagename LIKE '%".$description."%',
				blog_gal_pagename,
				''
			  ) AS blog_gal_pagename,
			  IF(
				blog_gal_image LIKE '%".$description."%',
				blog_gal_image,
				''
			  ) AS gal_image,
			  IF(
				blog_gal_image_tbn LIKE '%".$description."%',
				blog_gal_image_tbn,
				''
			  ) AS gal_image_tbn,
			  IF(
				blog_gal_description LIKE '%".$description."%',
				blog_gal_description,
				''
			  ) AS blog_gal_description
			FROM
			  blog_gals
			WHERE blog_gal_name LIKE '%".$description."%'
			  OR blog_gal_pagename LIKE '%".$description."%'
			  OR blog_gal_image LIKE '%".$description."%'
			  OR blog_gal_image_tbn LIKE '%".$description."%'
			  OR blog_gal_description LIKE '%".$description."%'
			LIMIT 50;

 
			");
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
		}				
		function detailed_search_blogs() {
			
			$description = $this->keyword();	 
			
        	$query = $this->db->query(" 
			SELECT * FROM blog_users 
			WHERE CAST( `blog_users`.`blog_description` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%'
			OR CAST( `blog_users`.`blog_page` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_users`.`blog_pagetitle` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_users`.`blog_fname` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_users`.`blog_lname` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_users`.`blog_email` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			");
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
		}
		
		function detailed_search_articles() {
			$description = $this->keyword();	 
			
        	$query = $this->db->query(" 
			SELECT * FROM blog_users
			INNER JOIN blog_articles ON blog_articles.blog_id = blog_users.blog_id 
			WHERE CAST( `blog_users`.`blog_description` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%'
			OR CAST( `blog_users`.`blog_page` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_users`.`blog_pagetitle` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_users`.`blog_fname` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_users`.`blog_lname` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_users`.`blog_email` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_articles`.`blog_articles_catergory` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_articles`.`blog_articles_quote` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_articles`.`blog_articles_shortdesc` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_articles`.`blog_articles_description` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_articles`.`blog_articles_page` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_articles`.`blog_articles_pagetitle` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%' 
			OR CAST( `blog_articles`.`blog_articles_image` AS CHAR CHARACTER SET utf8 ) COLLATE utf8_general_ci 
			LIKE '%".$description."%'
			");
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
		}
		
		function detailed_search_categories() {

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$blog_id=$this->getBlogID();
			$limit = $this->getLimit();
			$startpoint = ($page * $limit) - $limit;
			$limitQ = 'LIMIT '.$startpoint.', '.$limit.'';
        	$query = $this->db->query(" SELECT * FROM blog_users, blog_articles 
			WHERE blog_users.blog_id = blog_articles.blog_id 
			AND blog_users.blog_id = '".$blog_id."' 
			AND blog_users.blog_level = 'Approved' 
			ORDER BY blog_articles.blog_articles_id DESC
			-- ".$limitQ." ");
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
		}
						
		
		function detailed_search_pages() {

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$blog_id=$this->getBlogID();
			$limit = $this->getLimit();
			$startpoint = ($page * $limit) - $limit;
			$limitQ = 'LIMIT '.$startpoint.', '.$limit.'';
        	$query = $this->db->query(" SELECT * FROM blog_users, blog_articles 
			WHERE blog_users.blog_id = blog_articles.blog_id 
			AND blog_users.blog_id = '".$blog_id."' 
			AND blog_users.blog_level = 'Approved' 
			ORDER BY blog_articles.blog_articles_id DESC
			-- ".$limitQ." ");
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
		}
	
	}