<?php 
class All_categories extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }

		function match_category($blog_id, $article_id, $category_name){
			
			$query = $this->db->query(" SELECT `blog_category_id` 
			FROM blog_categories 
			WHERE article_id = '".$article_id."'
			AND blog_id = '".$blog_id."' 
			AND blog_category_name = '".$category_name."' " ); 
			$row = $query->row();
			if (isset($row)) {
				$blog_category_id = $row->blog_category_id; 
			}else{
				$blog_category_id = ''; 
			}
			return $blog_category_id;
		}

		function update_category($category_id, $blog_id, $article_id, $category_name, $category_slug) {
			
			$query = $this->db->query(" UPDATE `blog_categories`
			SET `blog_id` = '".$blog_id."',
			`article_id` = '".$article_id."',
			`blog_category_name` = '".$category_name."',
			`blog_category_slug` = '".$category_slug."'
			WHERE (`blog_category_id` = '".$category_id."') "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}	

		function all_my_categories($blog_id) {

        	$query = $this->db->query(" SELECT
			blog_fname, blog_lname,blog_categories.* 
			FROM blog_categories
			INNER JOIN blog_users ON blog_users.blog_id = blog_categories.blog_id
			WHERE blog_categories.blog_id = '".$blog_id."'  ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		
		}

		function all_article_categories($article_id) {

        	$query = $this->db->query(" SELECT * FROM blog_categories
			WHERE article_id = '".$article_id."'  ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		
		}
		
		
		function all_categories() {

        	$query = $this->db->query(" SELECT
			blog_fname, blog_lname,blog_categories.* 
			FROM blog_categories
			INNER JOIN blog_users ON blog_users.blog_id = blog_categories.blog_id
			ORDER BY blog_id ASC  ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}		
		function grouped_categories($q) {

        	$query = $this->db->query("    
			
			SELECT blog_categories.blog_category_name, blog_categories.blog_category_slug, blog_categories.blog_category_id  
			FROM blog_categories
			".$q."  
			GROUP BY blog_category_name ORDER BY COUNT(blog_category_name) DESC LIMIT 25			
			
			");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}
		function all_blog_grouped_categories() {

        	$query = $this->db->query(" SELECT
			COUNT(blog_articles_id) AS TotalArticles,
			blog_categories.blog_category_name,
			blog_categories.blog_category_slug,
			blog_categories.blog_category_id
			FROM blog_articles
			INNER JOIN blog_categories ON blog_articles.blog_articles_id = blog_categories.article_id
			GROUP BY blog_category_name 
			ORDER BY COUNT(blog_articles_id) DESC
			LIMIT 5");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}
	
			function all_blog_grouped_categories_for_user($blog_id) {

        	$query = $this->db->query(" SELECT
			COUNT(blog_articles_id) AS TotalArticles,
			blog_categories.blog_category_name,
			blog_categories.blog_category_slug,
			blog_categories.blog_category_id
			FROM blog_articles
			INNER JOIN blog_categories ON blog_articles.blog_articles_id = blog_categories.article_id
			WHERE blog_categories.blog_id = '".$blog_id."'
			GROUP BY blog_category_name ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}
	
		function all_grouped_categories() {

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			if ( $this->uri->segment(3) == 'all' ) {
				$q=''; 
			}else if( $this->uri->segment(3) == '0'  ){
				$q = '';
			}else{
				if ($this->uri->segment(3)){
					$q="AND blog_articles.blog_id = '".$this->uri->segment(3)."' "; 
				}else{
					$q="AND blog_articles.blog_id != '' "; 
				}
			}
			if ($this->uri->segment(4) ) {
				$qc = "AND blog_category_slug LIKE '%".$this->uri->segment(4)."%'";
			}else{
				$qc = '';
			}

        	$query = $this->db->query(" SELECT
			COUNT(blog_articles_id) AS TotalArticles,
			blog_categories.blog_category_name,
			blog_categories.blog_category_slug
			FROM blog_articles
			INNER JOIN blog_categories ON blog_articles.blog_articles_id = blog_categories.article_id
			".$q."
			GROUP BY blog_category_name ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}
	
		function limited_grouped_categories($limit) {

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			if ( $this->uri->segment(3) == 'all' ) {
				$q=''; 
			}else if( $this->uri->segment(3) == '0'  ){
				$q = '';
			}else{
				if ($this->uri->segment(3)){
					$q="AND blog_articles.blog_id = '".$this->uri->segment(3)."' "; 
				}else{
					$q="AND blog_articles.blog_id != '' "; 
				}
			}
			if ($this->uri->segment(4) ) {
				$qc = "AND blog_category_slug LIKE '%".$this->uri->segment(4)."%'";
			}else{
				$qc = '';
			}

        	$query = $this->db->query(" SELECT
			COUNT(blog_articles_id) AS TotalArticles,
			blog_categories.blog_category_name,
			blog_categories.blog_category_slug
			FROM blog_articles
			INNER JOIN blog_categories ON blog_articles.blog_articles_id = blog_categories.article_id
			".$q."
			GROUP BY blog_category_name LIMIT ".$limit."");
		
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}		
		function all_category_articles(){

			if ( $this->uri->segment(3) == 'all' ) {
				$q=" AND blog_users.blog_id IN ( SELECT blog_id FROM blog_users) "; 
			}else if( $this->uri->segment(3) == '0'  ){
				$q=" AND blog_users.blog_id IN ( SELECT blog_id FROM blog_users) "; 
			}else{
				$q="AND blog_users.blog_id = '".$this->uri->segment(3)."' "; 
			}
			if ($this->uri->segment(4) ) {
				$qc = "AND blog_category_name LIKE '%".$this->uri->segment(4)."%'";
			}else{
				$qc = '';
			}
			if ($this->uri->segment(4) ) {
				$qc = "AND blog_category_name LIKE '%".urldecode($this->uri->segment(4))."%'";
			}else{
				$qc = '';
			}

			$query = $this->db->query( " SELECT *
			FROM blog_categories 
			INNER JOIN blog_articles ON blog_articles.blog_articles_id = blog_categories.article_id
			INNER JOIN blog_users ON  blog_users.blog_id = blog_articles.blog_id
			WHERE blog_users.blog_level = 'Approved'
			AND blog_articles_level = 'Approved'
			".$qc."
			ORDER BY blog_articles.blog_articles_id DESC " ) ;
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}		
		function getLimit(){
			$limit='25';
			return $limit; 	
		}



		function one_category($category_id) {
			$query = $this->db->query(" SELECT * FROM 
			blog_categories 
			WHERE blog_category_id = '".$category_id."' ");
			if ($query) {
				return $query->result_array();
			}else{
				return FALSE;
			}
		}


		
		function insert_category($blog_id,$article_id,$blog_category_name,$blog_category_slug) {
			
			$data = array(
				 'blog_id' => $blog_id, 
				 'article_id' => $article_id, 
				 'blog_category_name' => $blog_category_name, 
				 'blog_category_slug' => $blog_category_slug
			);
			if ($this->db->insert('blog_categories', $data)){ 			
				return TRUE;	
			}else{
				return FALSE;	
			}
		}	
		
		/*function insert_category($blog_id,$article_id,$category_name,$category_slug) {
			
			$data = array(
				 'blog_id' => $blog_id, 
				 'article_id' => $article_id, 
				 'blog_category_name' => $blog_tag_name, 
				 'blog_category_slug' => $blog_tag_slug
			);

			$$query = $this->db->insert('blog_tags', $data);
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;	
		}*/	

	}