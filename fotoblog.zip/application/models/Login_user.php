<?php 
class Login_user extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->helper('string');
				$this->load->library('session');
				$this->load->library('unit_test');
        }

		function login(){
			
			$date =  date('Y-m-d H:m:s');
			$blog_password = md5($this->input->post('blog_password'));
			$blog_email = $this->input->post('blog_email');

			$query = $this->db->query(" SELECT * FROM blog_users 
			WHERE blog_email = '".$blog_email."'
			AND blog_password = '".$blog_password."' ");
			$row = $query->row();
			if (isset($row)){
				$isloggedIn = '1';
				$data = array(
						'user_active' => 1,
						'user_logged_out' => 1,
						'blog_id' => $row->blog_id,
						'blog_username' => $row->blog_username,
						'blog_page' => $row->blog_page,
						'blog_pagetitle' => $row->blog_pagetitle,
						'blog_date' => $row->blog_date,
						'blog_fname' => $row->blog_fname,
						'blog_lname' => $row->blog_lname,
						'blog_email' => $row->blog_email,
						'profile_pic' => $row->blog_profile_pic,
						'blog_lastlogin' => $date,
						'blog_logins' => $row->blog_logins,
						'blog_start_session' => time(),
						'blog_catergory' => $row->blog_catergory
				);	
				$set_userdata = $this->session->set_userdata($data);	
				$update_login_date=$this->update_login_date($row->blog_id, $date);		
			}else{
				$isloggedIn = '0';
			}

			return $isloggedIn;
			
		}

		function username_check($str) {
			$query = $this->db->query(" SELECT * FROM blog_users WHERE blog_username = '".$str."' ");
			$row = $query->row();
			if (isset($row)){
				$blog_username = $row->blog_username;
			}else{
				$blog_username = '';
			}
			return $blog_username;
		}

		function email_check($str) {
			$query = $this->db->query(" SELECT * FROM blog_users WHERE blog_email = '".$str."' ");
			$row = $query->row();
			if (isset($row)){
				$blog_email = $row->blog_email;
			}else{
				$blog_email = '';
			}
			return $blog_email;		
		}

		function password_check($str) {
			$query = $this->db->query(" SELECT * FROM blog_users WHERE blog_password = '".md5($str)."' ");
			$row = $query->row();
			if (isset($row)){
				$blog_password = '1';
			}else{
				$blog_password = '0';
			}
			return $blog_password;		
		}
		function update_login_date($blog_id,$date){
			
			$blog_lastlogin=$this->session->userdata('blog_lastlogin');
			$blog_logins=$this->session->userdata('blog_logins') + 1;
			$query = $this->db->query("UPDATE blog_users 
			SET blog_logins = '".$blog_logins."', blog_lastlogin = '".$date."'
			WHERE blog_id = '".$blog_id."' "); 
			if($query){
				$result = TRUE;
			}else{
				$result = FALSE;	
			}
			
			return $result;
		}
		
		function track(){
			
			$date =  date('Y-m-d H:m:s');
			$track_session = time();
			$blog_id = $this->session->userdata('blog_id');
			$track_action = 'Login User';
			$track_ip =  $this->input->ip_address(); 
			$track_details= json_encode(array($_SERVER));
			$track_date = $date;
			$user = ''.$this->session->userdata('blog_fname').' '.$this->session->userdata('blog_lname').'';
			$data = array(
			 'blog_id' => $blog_id, 
			 'track_action' => $track_action, 
			 'track_ip' => $track_ip, 
			 'track_session' => $track_session,
			 'track_details' => ''.$track_details.'',
			 'track_date' => $track_date
 			);

			$this->db->insert('blog_tracking', $data);
			
			return ''.$user.' was susccessfully tracked by the system';
	}
		
}