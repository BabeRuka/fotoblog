<?php

class Galleries extends CI_Model{

 	function total_galleries() {
		$q = $this->check_user();
        return $this->db->count_all(" `blog_gals` ".$q." ORDER BY blog_gal_id DESC  ");
    }	
	function check_user(){
			if ($this->session->userdata('blog_catergory') == 'Super Administrator') {
				$q = " WHERE blog_id != '' ";
			}else{
				$q = " WHERE blog_id = '".$this->session->userdata('blog_id')."' ";
			}
		
		return $q;
	}
	function all_galleries($limit, $start){
			if ($this->session->userdata('blog_catergory') != 'Super Administrator') {
				$user = "AND blog_gals.blog_id='".$this->session->userdata('blog_id')."' ";	
			}else{
				$user = "AND blog_gal_id != '' ";	
			}
			$q = $this->check_user();
			$query = $this->db->query( "SELECT  * FROM `blog_gals` 
			".$q." 
			".$user." 
			ORDER BY blog_gal_id DESC 
			LIMIT ".$start.", ".$limit." " ) ;
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
	}
	function admin_galleries(){
			if ($this->session->userdata('blog_catergory') != 'Super Administrator') {
				$user = "WHERE blog_gals.blog_id='".$this->session->userdata('blog_id')."' ";	
			}else{
				$user = "WHERE blog_gal_id != '' ";	
			}
			$q = $this->check_user();
			$query = $this->db->query( "SELECT  * FROM `blog_gals`
			".$user." 
			ORDER BY blog_gal_id DESC 
			LIMIT 0, 15 " ) ;
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
	}

	function my_latest_galleries($blog_id){
			$q = $this->check_user();
			$query = $this->db->query( "SELECT  * FROM `blog_gals`
			WHERE blog_id = ".$blog_id." 
			ORDER BY blog_gal_id DESC 
			LIMIT 0, 15 " ) ;
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
	}

	function latest_galleries(){
			$q = $this->check_user();
			$query = $this->db->query( "SELECT  * FROM `blog_gals` 
			ORDER BY blog_gal_id DESC 
			LIMIT 0, 15 " ) ;
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
	}

	function latest_photos(){
			$query = $this->db->query( "SELECT  * FROM `blog_gals_images` 
			INNER JOIN `blog_gals`ON `blog_gals`.blog_gal_id=`blog_gals_images`.blog_gal_id
			ORDER BY blog_tbn_id DESC 
			LIMIT 0, 15 " ) ;
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
	}

	function this_gallery($gallery_id){

			$query = $this->db->query( "  SELECT * FROM `blog_gals` 
			WHERE blog_gal_id = '".$gallery_id."' " ) ;
			
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
		
	}	
	function gallery_photo($photo_id, $part){

			$query = $this->db->query( " SELECT ".$part."
			FROM `blog_gals_images`
			WHERE blog_tbn_id = '".$photo_id."'  " ) ;
			if ($query){
				$row = $query->row();
				return $row->$part;
			}else{
				return false;
			}
		
	}

	
	function gallery_part($gallery_id, $part){

			$query = $this->db->query( " SELECT ".$part."
			FROM `blog_gals`
			WHERE blog_gal_id = '".$gallery_id."'  " ) ;
			$row = $query->row();
			$row->$part; 
			if ($query){
				return $row->$part;
			}else{
				return false;
			}
	}
	
	function all_gallery_images($gallery_id){

			$query = $this->db->query( " SELECT * FROM blog_gals
			INNER JOIN blog_gals_images ON blog_gals_images.blog_gal_id = blog_gals.blog_gal_id
			WHERE blog_gals.blog_gal_id = '".$gallery_id."' " ) ;
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
	}	
	function selected_gallery_images($selected_ids){

			$query = $this->db->query( " SELECT * FROM blog_gals_images
			WHERE blog_tbn_id IN ( ".$selected_ids.") " ) ;
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
	}	


	function all_gallery_images_excluding_one($gallery_id, $photo_id){

			$query = $this->db->query( " SELECT * FROM blog_gals
			INNER JOIN blog_gals_images ON blog_gals_images.blog_gal_id = blog_gals.blog_gal_id
			WHERE blog_gals.blog_gal_id = '".$gallery_id."'
			AND blog_tbn_id NOT IN ('".$photo_id."')  " ) ;
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
	}	

	function gallery_images($photo_id){

			$query = $this->db->query( " SELECT * FROM `blog_gals_images`
			WHERE blog_tbn_id = '".$photo_id."' " ) ;
			if ($query){
				return $query->result_array();
			}else{
				return false;
			}
	}	
	
}