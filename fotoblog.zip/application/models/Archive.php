<?php 
class Archive extends CI_Model {

        public function __construct() {
                $this->load->database();
				$this->load->helper('array');
				$this->load->library('session');
				$this->load->library('unit_test');
        }
		function getBlogID() {

			if ($this->uri->segment(3)){
				$blog = $this->uri->segment(3);
			}else{
				$blog = $this->uri->segment(4);
			}
			
			return $blog;
		}
		function getMonth() {

			if ($this->uri->segment(5)){
				$month = $this->uri->segment(5);
			}
			
			return $month;
		}
		function getYear() {

			if ($this->uri->segment(4)){
				$year = $this->uri->segment(4);
			}else{
				$year = false;
			}
			
			return $year;
		}

		function all_archives() {

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$limit = $this->getLimit();
			$startpoint = ($page * $limit) - $limit;
			$limitQ = 'LIMIT '.$startpoint.', '.$limit.'';
        	$query = $this->db->query(" SELECT
			MONTH(blog_article_date) AS MonthPublished,
			YEAR(blog_article_date) AS YearPublished,
			CONCAT_WS('-',YEAR(blog_article_date), MONTH(blog_article_date)) AS FullDate,
  			COUNT(blog_articles_id) AS ArticlesPublished
			FROM blog_users, blog_articles
			WHERE blog_users.blog_id = blog_articles.blog_id
			AND blog_users.blog_level = 'Approved'
			AND blog_articles_level = 'Approved'
			AND blog_users.blog_id = 2
			GROUP BY MONTH (blog_article_date), YEAR (blog_article_date)
			ORDER BY YEAR(blog_article_date) DESC, MONTH(blog_article_date) DESC
			LIMIT 0, 25");
			if($query){
				return $query->result_array();
			}else{
				return FALSE;	
			}
			
		}
		
		function my_archives(){

			$blog_id = $this->getBlogID();		

			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$limit = $this->getLimit();
			$startpoint = ($page * $limit) - $limit;
			$limitQ = 'LIMIT '.$startpoint.', '.$limit.'';
			$query = $this->db->query( " SELECT
			MONTH(blog_article_date) AS MonthPublished,
			YEAR(blog_article_date) AS YearPublished,
			CONCAT_WS('-',YEAR(blog_article_date), MONTH(blog_article_date)) AS FullDate,
  			COUNT(blog_articles_id) AS ArticlesPublished
			FROM blog_users, blog_articles
			WHERE blog_users.blog_id = blog_articles.blog_id
			AND blog_users.blog_level = 'Approved'
			AND blog_articles_level = 'Approved'
			AND blog_users.blog_id = '".$blog_id."' 
			GROUP BY MONTH (blog_article_date), YEAR (blog_article_date)
			ORDER BY YEAR(blog_article_date) DESC, MONTH(blog_article_date) DESC
			LIMIT 0, 25 " ) ;
			
			return $query->result_array();
		}
		
		function all_my_archived_articles(){

			$blog_id = $this->getBlogID();		
			$getMonth = $this->getMonth(); 
			$getYear = $this->getYear(); 
			if ($this->uri->segment(4)){
				$page = $this->uri->segment(4);
			}else{
				$page = 1;
			}
			$limit = $this->getLimit();
			$startpoint = ($page * $limit) - $limit;
			$limitQ = 'LIMIT '.$startpoint.', '.$limit.'';
			$query = $this->db->query( " SELECT * FROM
				blog_users,
				blog_articles
			WHERE
				blog_users.blog_id = blog_articles.blog_id
			AND blog_users.blog_level = 'Approved'
			AND blog_articles_level = 'Approved'
			AND blog_users.blog_id = '".$blog_id."'
			AND MONTH(blog_article_date) = '".$getMonth."'
			AND YEAR(blog_article_date) = '".$getYear."'
			ORDER BY blog_articles.blog_articles_id DESC " ) ;
			if($query){
				return $query->result_array();
			}else{
				return FALSE;	
			}
		}		
		function getLimit(){
			$limit='25';
			return $limit; 	
		}


		
}